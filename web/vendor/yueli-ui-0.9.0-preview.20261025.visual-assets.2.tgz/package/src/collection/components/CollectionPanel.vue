<script
  setup
  lang="ts"
  generic="TItem, TKey extends CollectionKey = CollectionKey"
>
import type { ButtonProps } from "@nuxt/ui";
import { computed, useSlots } from "vue";
import { isCollectionEditGesture } from "../edit-interaction";
import type {
  CollectionControl,
  CollectionControlValue,
  CollectionPanelLayout,
  CollectionPanelMessages,
  CollectionPanelState,
} from "../panel";
import type { CollectionKey } from "../workflow";
import type { CollectionPaginationLayout } from "../pagination";
import CollectionPagination from "./CollectionPagination.vue";
import CollectionPaginationBar from "./CollectionPaginationBar.vue";
import CollectionFrame from "./CollectionFrame.vue";
import CollectionSelectionBar from "./CollectionSelectionBar.vue";
import CollectionTableToolbar from "./CollectionTableToolbar.vue";
import CollectionHeaderTools from "./CollectionHeaderTools.vue";
import type { CollectionFilterPresentation } from "./CollectionFilterSurface.vue";
import type {
  CollectionMultiSelectControl,
  CollectionFilterApply,
} from "../multi-select";

defineOptions({ inheritAttrs: false });

const props = withDefaults(
  defineProps<{
    label?: string;
    size?: ButtonProps["size"];
    labelledby?: string;
    items: readonly TItem[];
    itemKey: (item: TItem) => TKey;
    itemLabel: (item: TItem) => string;
    controls?: readonly CollectionControl[];
    multiControls?: readonly CollectionMultiSelectControl[];
    filterPresentation?: CollectionFilterPresentation;
    messages: CollectionPanelMessages;
    state?: CollectionPanelState;
    errorMessage?: string;
    total: number;
    page: number;
    pageSize: number;
    pageSizes?: readonly number[];
    activeFilterCount?: number;
    selectable?: boolean;
    isItemSelectable?: (item: TItem) => boolean;
    selectionCount?: number;
    selectionMode?: "keys" | "query";
    pageSelected?: boolean;
    pageIndeterminate?: boolean;
    canSelectAllResults?: boolean;
    isSelected?: (key: TKey) => boolean;
    layout?: CollectionPanelLayout;
    externalControls?: boolean;
    selectionReplacesNavigation?: boolean;
    compactPagination?: boolean;
    paginationLayout?: CollectionPaginationLayout;
    compactGrid?: boolean;
  }>(),
  {
    controls: () => [],
    state: "ready",
    errorMessage: "",
    pageSizes: () => [10, 20, 40],
    activeFilterCount: 0,
    selectable: false,
    selectionCount: 0,
    selectionMode: "keys",
    pageSelected: false,
    pageIndeterminate: false,
    canSelectAllResults: false,
    layout: "rows",
    selectionReplacesNavigation: false,
    compactPagination: true,
    compactGrid: true,
  },
);

const search = defineModel<string>("search", { default: "" });
const filtersOpen = defineModel<boolean>("filtersOpen", { default: false });
const slots = useSlots();
const emit = defineEmits<{
  search: [value: string];
  controlChange: [id: string, value: CollectionControlValue];
  filterApply: [snapshot: CollectionFilterApply];
  clearFilters: [];
  retry: [];
  togglePage: [selected: boolean];
  toggleItem: [key: TKey, selected: boolean];
  selectAllResults: [];
  clearSelection: [];
  pageChange: [page: number];
  pageSizeChange: [pageSize: number];
  editItem: [item: TItem];
}>();

const firstVisible = computed(() =>
  props.total === 0 ? 0 : (props.page - 1) * props.pageSize + 1,
);
const lastVisible = computed(() =>
  Math.min(props.total, props.page * props.pageSize),
);
const pageSizeItems = computed(() =>
  props.pageSizes.map((value) => ({
    label: props.messages.pageSizeOption(value),
    value,
  })),
);
const pageSelection = computed(() =>
  props.pageSelected ? true : props.pageIndeterminate ? "indeterminate" : false,
);
const selectionActive = computed(
  () => props.selectable && props.selectionCount > 0,
);
const contextualSelectionEnabled = computed(
  () =>
    props.externalControls &&
    props.selectionReplacesNavigation &&
    Boolean(slots.navigation),
);
const filterControls = computed(() =>
  props.controls.filter(
    (control) =>
      control.kind === "select" && !/sort|direction/i.test(control.id),
  ),
);
const sortControls = computed(() =>
  props.controls.filter(
    (control) =>
      control.kind === "direction" || /sort|direction/i.test(control.id),
  ),
);
function changeControl(id: string, value: CollectionControlValue) {
  emit("controlChange", id, value);
}

function selectableItem(item: TItem) {
  return props.isItemSelectable?.(item) ?? true;
}

function selected(item: TItem, key: TKey) {
  return selectableItem(item) && (props.isSelected?.(key) ?? false);
}

function setSelected(item: TItem, key: TKey, next: boolean) {
  if (!selectableItem(item)) return;
  emit("toggleItem", key, next);
}

function toggle(item: TItem, key: TKey) {
  if (!selectableItem(item)) return;
  emit("toggleItem", key, !selected(item, key));
}
</script>

<template>
  <UTheme
    :props="{
      button: { size },
      input: { size },
      select: { size },
      selectMenu: { size },
      pagination: { size },
    }"
  >
    <CollectionFrame
      v-bind="$attrs"
      :label="label"
      :labelledby="labelledby"
      :data-selection-active="selectionActive ? 'true' : undefined"
    >
      <template v-if="$slots.navigation" #navigation>
        <div
          v-if="contextualSelectionEnabled"
          data-collection-contextual-toolbar
          class="relative"
        >
          <div
            data-collection-contextual-default
            :aria-hidden="selectionActive ? 'true' : undefined"
            :class="
              selectionActive ? 'invisible pointer-events-none select-none' : ''
            "
          >
            <slot name="navigation" />
          </div>

          <CollectionTableToolbar
            v-if="selectionActive"
            class="absolute inset-0 h-full"
            external-controls
            :label="`${label || messages.searchPlaceholder} 批量操作`"
            :search-placeholder="messages.searchPlaceholder"
            :filter-label="messages.filtersAction"
            :selection-count="selectionCount"
          >
            <template #selection>
              <CollectionSelectionBar
                :count="selectionCount"
                :mode="selectionMode"
                :messages="messages"
                :can-select-all-results="canSelectAllResults"
                @select-all-results="emit('selectAllResults')"
                @clear-selection="emit('clearSelection')"
              >
                <slot name="bulk-actions" />
              </CollectionSelectionBar>
            </template>
          </CollectionTableToolbar>
        </div>

        <slot v-else name="navigation" />
      </template>
      <template #toolbar>
        <CollectionHeaderTools
          :external-controls="externalControls"
          v-model:search="search"
          v-model:filters-open="filtersOpen"
          :label="`${label || messages.searchPlaceholder} 工具栏`"
          :search-placeholder="messages.searchPlaceholder"
          :controls="filterControls"
          :multi-controls="multiControls"
          :filter-presentation="filterPresentation"
          :sort-controls="sortControls"
          :filter-count="activeFilterCount"
          :filter-label="messages.filtersAction"
          :selection-count="
            selectable && !contextualSelectionEnabled ? selectionCount : 0
          "
          @search="emit('search', $event)"
          @control-change="changeControl"
          @filter-apply="emit('filterApply', $event)"
        >
          <template v-if="$slots.view" #view><slot name="view" /></template>
          <template #active-filters>
            <slot name="active-filters">
              <div class="flex items-center gap-2 text-xs">
                <span class="text-muted">{{
                  messages.activeFilters(activeFilterCount)
                }}</span>
                <UButton
                  :label="messages.clearFilters"
                  color="neutral"
                  variant="link"
                  @click="emit('clearFilters')"
                />
              </div>
            </slot>
          </template>

          <template #selection>
            <CollectionSelectionBar
              :count="selectionCount"
              :mode="selectionMode"
              :messages="messages"
              :can-select-all-results="canSelectAllResults"
              @select-all-results="emit('selectAllResults')"
              @clear-selection="emit('clearSelection')"
            >
              <slot name="bulk-actions" />
            </CollectionSelectionBar>
          </template>
        </CollectionHeaderTools>
      </template>

      <template
        v-if="selectable || (layout !== 'grid' && $slots.columns)"
        #columns
      >
        <div
          class="flex w-full min-w-0 items-center gap-0 text-xs font-medium leading-5 text-muted"
        >
          <div v-if="selectable" class="w-9 shrink-0">
            <UCheckbox
              :model-value="pageSelection"
              :aria-label="messages.selectPage"
              @update:model-value="emit('togglePage', $event === true)"
            />
          </div>
          <div class="min-w-0 flex-1">
            <span v-if="layout === 'grid'">{{ messages.selectPage }}</span>
            <slot v-else name="columns" />
          </div>
        </div>
      </template>

      <div v-if="state === 'loading'" aria-busy="true" aria-live="polite">
        <slot name="loading">
          <div
            v-for="index in 5"
            :key="index"
            class="flex items-center gap-3 border-b border-default px-3 py-4 last:border-0 sm:px-4"
          >
            <USkeleton v-if="selectable" class="size-4 shrink-0 rounded" />
            <div class="min-w-0 flex-1 space-y-2">
              <USkeleton class="h-4 w-1/3 rounded" />
              <USkeleton class="h-3 w-2/3 rounded" />
            </div>
          </div>
        </slot>
      </div>

      <div
        v-else-if="state === 'error'"
        class="grid min-h-56 place-items-center px-6 py-12 text-center"
        role="alert"
      >
        <slot name="error">
          <div>
            <span
              class="mx-auto grid size-10 place-items-center rounded-full bg-error/10 text-error"
            >
              <UIcon name="i-tabler-alert-circle" class="size-5" />
            </span>
            <p class="mt-3 text-sm font-medium text-highlighted">
              {{ messages.errorTitle }}
            </p>
            <p
              v-if="errorMessage"
              class="mt-1 max-w-md text-xs leading-5 text-muted"
            >
              {{ errorMessage }}
            </p>
            <UButton
              class="mt-4"
              :label="messages.retry"
              color="neutral"
              variant="outline"
              @click="emit('retry')"
            />
          </div>
        </slot>
      </div>

      <div
        v-else-if="items.length === 0"
        class="grid min-h-56 place-items-center px-6 py-12 text-center"
      >
        <slot name="empty">
          <div>
            <span
              class="mx-auto grid size-10 place-items-center rounded-full bg-muted text-muted"
            >
              <UIcon name="i-tabler-search-off" class="size-5" />
            </span>
            <p class="mt-3 text-sm font-medium text-highlighted">
              {{ messages.emptyTitle }}
            </p>
            <p class="mt-1 text-xs text-muted">
              {{ messages.emptyDescription }}
            </p>
          </div>
        </slot>
      </div>

      <div
        v-else-if="layout === 'grid'"
        class="grid gap-3 p-3 sm:p-4 @sm/collection:grid-cols-2 @3xl/collection:grid-cols-3"
        :data-compact-grid="compactGrid"
        data-collection-grid
      >
        <article
          v-for="item in items"
          :key="itemKey(item)"
          @dblclick="
            selectionCount === 0 &&
            isCollectionEditGesture($event) &&
            emit('editItem', item)
          "
          class="relative min-w-0 rounded-lg border bg-default p-4 transition-colors"
          :class="[
            selected(item, itemKey(item))
              ? 'border-primary/50 bg-primary/5 ring-1 ring-primary/20'
              : 'border-default',
          ]"
        >
          <UCheckbox
            v-if="selectable"
            :model-value="selected(item, itemKey(item))"
            :disabled="!selectableItem(item)"
            :aria-label="messages.selectItem(itemLabel(item))"
            :class="
              compactGrid
                ? 'absolute left-2 top-2 z-10'
                : 'absolute left-4 top-4 z-10 rounded-md bg-default/90 p-1 shadow-sm backdrop-blur'
            "
            @update:model-value="
              setSelected(item, itemKey(item), $event === true)
            "
          />
          <slot
            name="item"
            :item="item"
            :key="itemKey(item)"
            :selected="selected(item, itemKey(item))"
            :toggle="() => toggle(item, itemKey(item))"
            :selection-active="selectionCount > 0"
          />
        </article>
      </div>

      <div v-else class="divide-y divide-default">
        <article
          v-for="item in items"
          :key="itemKey(item)"
          @dblclick="
            selectionCount === 0 &&
            isCollectionEditGesture($event) &&
            emit('editItem', item)
          "
          class="flex min-w-0 items-center px-3 py-3 transition-colors sm:px-4"
          :class="
            selected(item, itemKey(item))
              ? 'bg-primary/5 hover:bg-primary/5'
              : 'hover:bg-elevated/40'
          "
        >
          <div v-if="selectable" class="w-9 shrink-0">
            <UCheckbox
              :model-value="selected(item, itemKey(item))"
              :disabled="!selectableItem(item)"
              :aria-label="messages.selectItem(itemLabel(item))"
              @update:model-value="
                setSelected(item, itemKey(item), $event === true)
              "
            />
          </div>
          <div class="min-w-0 flex-1">
            <slot
              name="item"
              :item="item"
              :key="itemKey(item)"
              :selected="selected(item, itemKey(item))"
              :toggle="() => toggle(item, itemKey(item))"
              :selection-active="selectionCount > 0"
            />
          </div>
        </article>
      </div>

      <template #footer>
        <CollectionPaginationBar
          v-if="compactPagination"
          :layout="paginationLayout"
          :page="page"
          :page-size="pageSize"
          :total="total"
          :page-sizes="pageSizes"
          :page-size-label="messages.pageSize"
          :page-size-control="messages.pageSizeControl"
          :page-size-option="messages.pageSizeOption"
          :label="messages.pagination"
          @page-change="emit('pageChange', $event)"
          @page-size-change="emit('pageSizeChange', $event)"
        />
        <div
          v-else
          class="flex flex-col gap-3 text-xs sm:flex-row sm:items-center sm:justify-between"
        >
          <p class="text-muted">
            {{ messages.showing(firstVisible, lastVisible, total) }}
          </p>
          <div
            class="flex min-w-0 flex-1 flex-col items-stretch gap-2 sm:flex-row sm:items-center"
            data-pagination-controls
          >
            <CollectionPagination
              :layout="paginationLayout"
              :model-value="page"
              :total-pages="Math.ceil(total / pageSize)"
              :aria-label="messages.pagination || messages.pageSize"
              data-pagination-pages
              @update:model-value="emit('pageChange', $event)"
            />
            <div class="flex items-center gap-2" data-pagination-size>
              <span class="text-muted">{{ messages.pageSize }}</span>
              <USelect
                :model-value="pageSize"
                :items="pageSizeItems"
                value-key="value"
                class="w-24"
                :aria-label="messages.pageSizeControl"
                @update:model-value="emit('pageSizeChange', Number($event))"
              />
            </div>
          </div>
        </div>
      </template>
    </CollectionFrame>
  </UTheme>
</template>

<style scoped>
[data-collection-contextual-toolbar] :deep([data-collection-table-selection]) {
  height: 100%;
  min-height: 100%;
}

[data-collection-frame][data-selection-active="true"]
  :deep([data-admin-row-actions]) {
  visibility: hidden;
  pointer-events: none;
}

[data-compact-grid="true"] {
  grid-template-columns: repeat(auto-fill, minmax(12rem, 1fr));
}
@container collection (max-width: 30rem) {
  [data-compact-grid="true"] {
    grid-template-columns: repeat(auto-fill, minmax(9rem, 1fr));
  }
}
</style>
