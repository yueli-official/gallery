<script setup lang="ts">
import type { ButtonProps } from "@nuxt/ui";
import { ref, useId, watch } from "vue";

defineOptions({ inheritAttrs: false });

const props = withDefaults(
  defineProps<{
    label: string;
    size?: ButtonProps["size"];
    searchPlaceholder: string;
    searchId?: string;
    searchable?: boolean;
    searchAction?: string;
    filterLabel: string;
    filterCount?: number;
    selectionCount?: number;
    presentation?: "default" | "header";
    externalControls?: boolean;
  }>(),
  {
    filterCount: 0,
    selectionCount: 0,
    searchable: true,
    size: "sm",
  },
);

const search = defineModel<string>("search", { default: "" });
const filtersOpen = defineModel<boolean>("filtersOpen", { default: false });
const emit = defineEmits<{ search: [value: string] }>();
const filterPanelId = `y-collection-filter-panel-${useId().replaceAll(":", "")}`;
const searchDraft = ref(search.value);
const isComposing = ref(false);
const defaultToolbar = ref<HTMLElement | null>(null);
const defaultToolbarHeight = ref<number>();
watch(defaultToolbar, (element, _previous, onCleanup) => {
  if (!element || typeof ResizeObserver === "undefined") return;
  const measure = () => {
    defaultToolbarHeight.value = element.getBoundingClientRect().height;
  };
  measure();
  const observer = new ResizeObserver(measure);
  observer.observe(element);
  onCleanup(() => observer.disconnect());
});

watch(search, (value) => {
  if (!isComposing.value && searchDraft.value !== value) {
    searchDraft.value = value;
  }
});

function updateSearchDraft(value: string) {
  searchDraft.value = value;
  if (!isComposing.value && search.value !== value) {
    search.value = value;
  }
}

function startComposition() {
  isComposing.value = true;
}

function finishComposition(event: CompositionEvent) {
  isComposing.value = false;
  const value =
    (event.target as HTMLInputElement | null)?.value ?? searchDraft.value;
  searchDraft.value = value;
  if (search.value !== value) {
    search.value = value;
  }
}

function submitSearch() {
  if (isComposing.value) return;
  const value = searchDraft.value.trim();
  if (search.value !== value) {
    search.value = value;
  }
  emit("search", value);
}
</script>

<template>
  <UTheme
    :props="{
      button: { size },
      input: { size },
      select: { size },
      selectMenu: { size },
    }"
  >
    <section
      v-bind="$attrs"
      data-collection-table-toolbar
      :data-presentation="presentation"
      :data-search-and-controls="
        searchable !== false && !!($slots.filters || $slots.utilities)
      "
      :aria-label="props.label"
    >
      <div
        v-if="props.selectionCount > 0"
        data-collection-table-selection
        :style="
          defaultToolbarHeight
            ? { minHeight: `${defaultToolbarHeight}px` }
            : undefined
        "
        class="flex min-h-12 items-center border-b border-default bg-primary/5 px-3 py-2 sm:px-4"
      >
        <div class="min-w-0 flex-1">
          <slot name="selection" :count="props.selectionCount" />
        </div>
      </div>

      <div
        v-else-if="!externalControls"
        ref="defaultToolbar"
        data-collection-table-default
        class="grid min-h-12 grid-cols-[minmax(0,1fr)_auto] items-center gap-2 border-b border-default p-3 sm:p-4"
      >
        <form
          v-if="searchable !== false"
          data-collection-table-search
          :class="[
            props.searchAction
              ? 'grid grid-cols-[minmax(0,1fr)_auto]'
              : 'block',
            'col-span-2 min-w-0 gap-2',
          ]"
          role="search"
          @submit.prevent="submitSearch"
        >
          <UInput
            :id="searchId"
            :model-value="searchDraft"
            icon="i-tabler-search"
            :placeholder="props.searchPlaceholder"
            class="w-full min-w-0"
            @update:model-value="updateSearchDraft"
            @compositionstart="startComposition"
            @compositionend="finishComposition"
          />
          <UButton
            v-if="props.searchAction"
            type="submit"
            icon="i-tabler-search"
            :label="props.searchAction"
            color="neutral"
            variant="outline"
          />
        </form>

        <div
          v-if="$slots.filters || $slots.utilities"
          data-collection-table-controls
          class="col-span-2 flex min-w-0 items-center justify-between gap-2"
        >
          <UPopover v-if="$slots.filters" v-model:open="filtersOpen">
            <UButton
              icon="i-tabler-adjustments-horizontal"
              :label="
                props.filterCount
                  ? `${props.filterLabel} · ${props.filterCount}`
                  : props.filterLabel
              "
              color="neutral"
              variant="outline"
              :aria-controls="filterPanelId"
              :aria-expanded="filtersOpen"
            />

            <template #content>
              <div
                :id="filterPanelId"
                data-collection-table-filter-panel
                class="p-3"
              >
                <slot name="filters" />
              </div>
            </template>
          </UPopover>

          <div
            v-if="$slots.utilities"
            data-collection-table-utilities
            class="ml-auto flex min-w-0 items-center justify-end gap-1.5"
          >
            <slot name="utilities" />
          </div>
        </div>
      </div>

      <div
        v-if="$slots['active-filters'] && props.filterCount > 0"
        data-collection-table-active-filters
        class="flex min-h-10 flex-wrap items-center gap-1.5 border-b border-default px-3 py-2 sm:px-4"
      >
        <slot name="active-filters" />
      </div>
    </section>
  </UTheme>
</template>

<style scoped>
[data-presentation="header"] [data-collection-table-default] {
  display: flex;
  flex-wrap: wrap;
  min-height: 3.375rem;
  padding: 0.75rem;
}
[data-presentation="header"] [data-collection-table-search] {
  flex: 1 1 16rem;
  max-width: 30rem;
}
[data-presentation="header"] [data-collection-table-controls] {
  flex: 0 1 auto;
  margin-left: auto;
  justify-content: flex-end;
  flex-wrap: wrap;
}
[data-presentation="header"] [data-collection-table-selection] {
  min-height: 3.375rem;
  padding-block: 0.75rem;
}
[data-collection-table-toolbar] {
  container-type: inline-size;
}

@media (min-width: 640px) {
  [data-presentation="header"] [data-collection-table-default] {
    padding-inline: 1rem;
  }
}

@container (min-width: 36rem) {
  [data-collection-table-toolbar]:not([data-presentation="header"])
    [data-collection-table-selection],
  [data-collection-table-toolbar]:not([data-presentation="header"])
    [data-collection-table-default] {
    min-height: 4rem;
  }

  [data-collection-table-default] {
    grid-template-columns: minmax(14rem, 1fr) auto;
  }

  [data-collection-table-search],
  [data-collection-table-controls] {
    grid-column: span 1 / span 1;
  }

  [data-collection-table-controls] {
    justify-content: flex-end;
  }
}

@container (max-width: 35.999rem) {
  [data-presentation="header"] [data-collection-table-default] :deep(input),
  [data-presentation="header"] [data-collection-table-default] :deep(button) {
    min-height: 2.75rem;
  }
  [data-presentation="header"] [data-collection-table-default] :deep(button) {
    min-width: 2.75rem;
  }
  [data-presentation="header"][data-search-and-controls="true"]
    [data-collection-table-selection] {
    min-height: 5.75rem;
  }
  [data-presentation="header"] [data-collection-table-search] {
    flex-basis: 100%;
    max-width: none;
  }
  [data-presentation="header"] [data-collection-table-controls] {
    flex: 1 1 100%;
  }
}
</style>
