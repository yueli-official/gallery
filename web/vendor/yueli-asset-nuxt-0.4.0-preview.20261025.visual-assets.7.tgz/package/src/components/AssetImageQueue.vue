<script setup lang="ts">
import { ref, watch, nextTick, onMounted } from 'vue'
const props=defineProps<{items:Array<{id:number;file:File;url:string}>;active:number;disabled?:boolean}>()
const emit=defineEmits<{change:[index:number]}>()
const carousel=ref<{emblaApi?:{slidesInView():number[];scrollTo(index:number,jump?:boolean):void}}>()
async function reveal(){await nextTick();const api=carousel.value?.emblaApi;if(api&&!api.slidesInView().includes(props.active))api.scrollTo(props.active,true)}
watch(()=>props.active,reveal)
onMounted(reveal)
</script>
<template>
 <div class="rounded-xl border border-default bg-elevated p-2" aria-label="图片列表" data-image-queue>
  <UCarousel ref="carousel" :items="items" :start-index="active" align="start" drag-free :watch-focus="false" :ui="{item:'basis-20',container:'ms-0',viewport:'overflow-hidden py-1'}">
   <template #default="{item,index}"><button :aria-label="`切换 ${item.file.name}`" :title="`${index+1}. ${item.file.name}`" :aria-current="active===index?'true':undefined" class="w-full rounded-lg border p-1 text-left" :class="active===index?'border-primary bg-primary/5':'border-default bg-default'" :disabled="disabled" @click="emit('change',index)"><img :src="item.url" alt="" class="h-14 w-full rounded object-cover" draggable="false"></button></template>
  </UCarousel>
 </div>
</template>
