<script setup lang="ts">
import { computed, ref, shallowRef, watch, onBeforeUnmount } from 'vue'
import AssetCropperFrame from './AssetCropperFrame.vue'
import UButton from '@nuxt/ui/components/Button.vue'
import UTooltip from '@nuxt/ui/components/Tooltip.vue'
import UAlert from '@nuxt/ui/components/Alert.vue'
import Cropper from 'cropperjs'
import { canvasImageBlob } from '../canvas-image'
import type { ImageRasterPreview } from '../image-workbench-preview'
import 'cropperjs/dist/cropper.css'
import {
  buildPictureCropperConfig,
  calculateCropCanvasSize,
  filenameForCrop,
  type AssetCropMode,
  type AssetCropOutputType,
  type AssetCropShape
} from '../image-cropper'

interface CropCoordinates {
  left: number
  top: number
  width: number
  height: number
}

interface CroppedPayload {
  file: File
  blob: Blob
  coordinates: CropCoordinates
  source: {
    width: number
    height: number
  }
  outputSize: {
    width: number
    height: number
  }
}

const props = withDefaults(defineProps<{
  open?: boolean
  file?: File | null
  title?: string
  shape?: AssetCropShape
  mode?: AssetCropMode
  aspectRatio?: number
  outputWidth?: number
  outputHeight?: number
  outputType?: AssetCropOutputType
  quality?: number
  minSourceWidth?: number
  minSourceHeight?: number
  maxSourceWidth?: number
  maxSourceHeight?: number
  minCropWidth?: number
  minCropHeight?: number
  maxCropWidth?: number
  maxCropHeight?: number
  confirmLabel?: string
  embedded?: boolean
  maximalCrop?: boolean
  initialCrop?: Cropper.Data
  previewUrl?: string
  browserOrientation?: boolean
  rasterPreview?: ImageRasterPreview
  pendingPreview?: boolean
}>(), {
  open: false,
  file: null,
  title: '裁剪图片',
  shape: 'rect',
  mode: 'fixed',
  aspectRatio: 3 / 2,
  outputWidth: undefined,
  outputHeight: undefined,
  outputType: 'image/webp',
  quality: 0.9,
  minSourceWidth: undefined,
  minSourceHeight: undefined,
  maxSourceWidth: undefined,
  maxSourceHeight: undefined,
  minCropWidth: undefined,
  minCropHeight: undefined,
  maxCropWidth: undefined,
  maxCropHeight: undefined,
  confirmLabel: '使用裁剪图',
  embedded: false,
  maximalCrop: false
})

const emit = defineEmits<{
  'update:open': [value: boolean]
  cropped: [payload: CroppedPayload]
  cancel: []
  error: [message: string]
}>()

const imageElement = ref<HTMLImageElement | null>(null)
const imageUrl = ref('')
const sourceSize = ref<{ width: number, height: number } | null>(null)
const localError = ref('')
const processing = ref(false)
const loading = ref(false)
const cropperReady = ref(false)
const cropperInstance = shallowRef<Cropper | null>(null)
const zoomPercent = ref(100)
const currentCrop = ref<CropCoordinates | null>(null)

const ZOOM_MIN = 100
const ZOOM_MAX = 400
const ZOOM_STEP = 10

const localOpen = computed({
  get: () => props.open,
  set: value => emit('update:open', value)
})

const cropperConfig = computed(() => buildPictureCropperConfig({
  shape: props.shape,
  mode: props.mode,
  aspectRatio: props.aspectRatio,
  outputWidth: props.outputWidth,
  outputHeight: props.outputHeight,
  minCropWidth: props.minCropWidth,
  minCropHeight: props.minCropHeight
}))

const cropperKey = computed(() => [
  props.shape,
  props.mode,
  props.aspectRatio || 0
].join(':'))

const canConfirm = computed(() => Boolean(
  imageUrl.value &&
  getCropper() &&
  cropperReady.value &&
  !localError.value &&
  !loading.value &&
  !processing.value
))
const currentOutputSize = computed(() => currentCrop.value ? outputCanvasSize(currentCrop.value) : null)

let objectUrl = ''
let currentFile: File | null = null
let sourceImage: HTMLImageElement | null = null
let initializedCropperKey = ''
let loadToken = 0
let baseCanvasRatio = 1

function destroyCropper() {
  cropperInstance.value?.destroy()
  cropperInstance.value = null
  initializedCropperKey = ''
  cropperReady.value = false
  zoomPercent.value = 100
  currentCrop.value = null
  baseCanvasRatio = 1
}

function cleanupObjectUrl() {
  loadToken += 1
  destroyCropper()
  imageUrl.value = ''
  currentFile = null
  sourceImage = null
  if (objectUrl) {
    URL.revokeObjectURL(objectUrl)
    objectUrl = ''
  }
}

function initializeCropper() {
  const nextKey = `${imageUrl.value}:${cropperKey.value}`
  if (initializedCropperKey === nextKey) return
  destroyCropper()
  if (!imageElement.value) return
  initializedCropperKey = nextKey
  try {
    cropperInstance.value = new Cropper(imageElement.value, {
      ...cropperConfig.value.options,
      // The embedded stage owns the background, including its preview gutters.
      background: props.embedded ? false : cropperConfig.value.options.background,
      modal: props.embedded ? false : cropperConfig.value.options.modal,
      // The workbench displays browser-decoded local images. Avoid reading and
      // cloning the whole JPEG again when native EXIF orientation is supported.
      checkOrientation: props.browserOrientation && CSS.supports('image-orientation','from-image') ? false : cropperConfig.value.options.checkOrientation,
      ready: () => {
        const cropper = getCropper()
        if (!cropper) return
        const canvas = cropper.getCanvasData()
        baseCanvasRatio = canvas.naturalWidth > 0 ? canvas.width / canvas.naturalWidth : 1
        zoomPercent.value = 100
        cropperReady.value = true
        if (props.initialCrop) cropper.setData(props.initialCrop)
        else if (props.maximalCrop) centerCrop()
      },
      zoom: (event) => {
        const nextPercent = (event.detail.ratio / baseCanvasRatio) * 100
        if (nextPercent < ZOOM_MIN - 0.5 || nextPercent > ZOOM_MAX + 0.5) {
          event.preventDefault()
          return
        }
        zoomPercent.value = Math.round(nextPercent)
      },
      crop: (event) => {
        currentCrop.value = scaledCoordinates(event.detail)
      }
    })
  } catch (error) {
    initializedCropperKey = ''
    throw error
  }
}

function validateSource(width: number, height: number) {
  if (props.minSourceWidth && width < props.minSourceWidth) return `原图宽度不能小于 ${props.minSourceWidth}px`
  if (props.minSourceHeight && height < props.minSourceHeight) return `原图高度不能小于 ${props.minSourceHeight}px`
  if (props.maxSourceWidth && width > props.maxSourceWidth) return `原图宽度不能大于 ${props.maxSourceWidth}px`
  if (props.maxSourceHeight && height > props.maxSourceHeight) return `原图高度不能大于 ${props.maxSourceHeight}px`
  return ''
}

function validateCrop(coordinates?: CropCoordinates | null) {
  if (!coordinates) return ''
  if (![coordinates.left, coordinates.top, coordinates.width, coordinates.height].every(Number.isFinite)
    || coordinates.width <= 0
    || coordinates.height <= 0) return '裁剪区域尚未准备好，请稍后重试'
  if (props.minCropWidth && coordinates.width < props.minCropWidth) return `裁剪宽度不能小于 ${props.minCropWidth}px`
  if (props.minCropHeight && coordinates.height < props.minCropHeight) return `裁剪高度不能小于 ${props.minCropHeight}px`
  if (props.maxCropWidth && coordinates.width > props.maxCropWidth) return `裁剪宽度不能大于 ${props.maxCropWidth}px`
  if (props.maxCropHeight && coordinates.height > props.maxCropHeight) return `裁剪高度不能大于 ${props.maxCropHeight}px`
  return ''
}

function prepareFile(file: File | null | undefined) {
  if (!file) {
    cleanupObjectUrl()
    sourceSize.value = null
    localError.value = ''
    loading.value = false
    return
  }

  if (currentFile === file && imageUrl.value) return

  cleanupObjectUrl()
  localError.value = ''
  loading.value = true

  const token = loadToken
  const owned = !props.previewUrl
  const nextUrl = props.previewUrl || URL.createObjectURL(file)
  const release = () => { if (owned) URL.revokeObjectURL(nextUrl) }
  const img = new Image()

  img.onload = () => {
    if (token !== loadToken) {
      release()
      return
    }

    const originalWidth=props.rasterPreview?.width||img.naturalWidth
    const originalHeight=props.rasterPreview?.height||img.naturalHeight
    const message = validateSource(originalWidth, originalHeight)
    if (message) {
      release()
      sourceSize.value = { width: img.naturalWidth, height: img.naturalHeight }
      localError.value = message
      loading.value = false
      emit('error', message)
      return
    }

    objectUrl = owned ? nextUrl : ''
    currentFile = file
    sourceImage = img
    sourceSize.value = { width: originalWidth, height: originalHeight }
    imageUrl.value = nextUrl
    loading.value = false
  }

  img.onerror = () => {
    if (token !== loadToken) {
      release()
      return
    }
    release()
    localError.value = '图片加载失败'
    loading.value = false
    emit('error', localError.value)
  }

  img.src = nextUrl
}

function getCropper() {
  return cropperInstance.value
}

function centerCrop() {
  const cropper = getCropper()
  if (!cropper || !sourceSize.value) return
  const image = cropper.getImageData()
  const rotated = Math.abs((image.rotate || 0) % 180) === 90
  const width = rotated ? image.naturalHeight : image.naturalWidth
  const height = rotated ? image.naturalWidth : image.naturalHeight
  const ratio = props.mode === 'free' ? width / height : (props.aspectRatio || width / height)
  const w = Math.min(width, height * ratio)
  const h = w / ratio
  cropper.setData({ x: (width-w)/2, y: (height-h)/2, width:w, height:h })
}

async function exportImage(): Promise<CroppedPayload> {
  const cropper = getCropper()
  if (!cropper || !props.file || !sourceSize.value || !cropperReady.value) throw new Error('图片尚未准备好')
  const coordinates = cropCoordinates(cropper)
  const invalid = validateCrop(coordinates)
  if (invalid) throw new Error(invalid)
  let original:ImageBitmap|undefined
  let canvas:HTMLCanvasElement
  try {
    if(props.rasterPreview)original=await createImageBitmap(props.file,{imageOrientation:'from-image'})
    canvas=cropCanvas(cropper,coordinates,original)
  } finally { original?.close() }
  const blob = await canvasImageBlob(canvas,props.outputType,props.quality)
  if (!blob || blob.type !== props.outputType) throw new Error('图片导出格式不受当前浏览器支持')
  return { file: new File([blob], filenameForCrop(props.file.name, props.outputType), {type:props.outputType}), blob, coordinates, source:sourceSize.value, outputSize:{width:canvas.width,height:canvas.height} }
}
defineExpose({ exportImage, getState: () => getCropper()?.getData(), getExportState: () => {const c=getCropper();if(!c)return undefined;const d=c.getData();return {...cropCoordinates(c),rotate:d.rotate||0,scaleX:d.scaleX||1,scaleY:d.scaleY||1}}, centerCrop, canConfirm })

function scaledCoordinates(data:{x:number;y:number;width:number;height:number;rotate?:number}):CropCoordinates{
  const preview=props.rasterPreview
  const rotated=Math.abs((data.rotate??getCropper()?.getData().rotate??0)%180)===90
  const sx=preview?(rotated?preview.height/preview.previewHeight:preview.width/preview.previewWidth):1
  const sy=preview?(rotated?preview.width/preview.previewWidth:preview.height/preview.previewHeight):1
  return {left:data.x*sx,top:data.y*sy,width:data.width*sx,height:data.height*sy}
}
function cropCoordinates(cropper: Cropper): CropCoordinates {
  return scaledCoordinates(cropper.getData(!props.rasterPreview))
}

function outputCanvasSize(coordinates: CropCoordinates) {
  return calculateCropCanvasSize(coordinates, {
    width: props.outputWidth,
    height: props.outputHeight
  })
}

function cropCanvas(cropper: Cropper, coordinates: CropCoordinates, original?:ImageBitmap) {
  if (!sourceImage) throw new Error('原图尚未准备好')
  const imageData = cropper.getImageData()
  const source = original || sourceImage
  const sourceWidth = original?.width || sourceImage.naturalWidth
  const sourceHeight = original?.height || sourceImage.naturalHeight
  const size = outputCanvasSize(coordinates)
  const canvas = document.createElement('canvas')
  canvas.width = size.width
  canvas.height = size.height
  const context = canvas.getContext('2d',{colorSpace:'srgb'})
  if (!context) throw new Error('当前浏览器不支持图片处理')

  if (props.outputType === 'image/jpeg') {
    context.fillStyle = '#fff'
    context.fillRect(0, 0, canvas.width, canvas.height)
  }
  context.imageSmoothingEnabled = true
  context.imageSmoothingQuality = 'high'
  const scaleX = canvas.width / coordinates.width
  const scaleY = canvas.height / coordinates.height
  const angle=((imageData.rotate||0)*Math.PI)/180
  const rotatedWidth=Math.abs(sourceWidth*Math.cos(angle))+Math.abs(sourceHeight*Math.sin(angle))
  const rotatedHeight=Math.abs(sourceWidth*Math.sin(angle))+Math.abs(sourceHeight*Math.cos(angle))
  context.save()
  context.scale(scaleX,scaleY)
  context.translate(-coordinates.left,-coordinates.top)
  context.translate(rotatedWidth/2,rotatedHeight/2)
  context.rotate(angle)
  context.scale(imageData.scaleX||1,imageData.scaleY||1)
  context.drawImage(source,-sourceWidth/2,-sourceHeight/2,sourceWidth,sourceHeight)
  context.restore()

  if (props.shape === 'circle') {
    context.globalCompositeOperation = 'destination-in'
    context.beginPath()
    context.arc(canvas.width / 2, canvas.height / 2, Math.min(canvas.width, canvas.height) / 2, 0, Math.PI * 2)
    context.fill()
  }
  return canvas
}

function resetCrop() {
  getCropper()?.reset()
  if (props.maximalCrop) centerCrop()
  zoomPercent.value = 100
}

function rotateCrop(degree: number) {
  getCropper()?.rotate(degree)
}

function flipCrop(axis: 'horizontal' | 'vertical') {
  const cropper = getCropper()
  if (!cropper) return
  const image = cropper.getImageData()
  if (axis === 'horizontal') {
    cropper.scaleX(-(image.scaleX || 1))
    return
  }
  cropper.scaleY(-(image.scaleY || 1))
}

function setZoomPercent(value: number | number[]) {
  const requested = Array.isArray(value) ? value[0] : value
  if (requested === undefined || !Number.isFinite(requested)) return
  const nextPercent = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, Math.round(requested)))
  getCropper()?.zoomTo(baseCanvasRatio * (nextPercent / 100))
}

function handleZoomInput(event: Event) {
  setZoomPercent(Number((event.target as HTMLInputElement).value))
}

function adjustZoom(direction: -1 | 1) {
  setZoomPercent(zoomPercent.value + direction * ZOOM_STEP)
}

async function confirmCrop() {
  const cropper = getCropper()
  if (!cropper || !props.file || !sourceSize.value) return

  const coordinates = cropCoordinates(cropper)
  const message = validateCrop(coordinates)
  if (message) {
    localError.value = message
    emit('error', message)
    return
  }

  processing.value = true
  try {
    emit('cropped', await exportImage())
    localOpen.value = false
  } catch (err) {
    const error = (err as Error).message || '图片裁剪失败'
    localError.value = error
    emit('error', error)
  } finally {
    processing.value = false
  }
}

function cancelCrop() {
  localOpen.value = false
  emit('cancel')
}

watch(() => [props.open, props.file] as const, ([open, file]) => {
  if (open) prepareFile(file)
  else {
    cleanupObjectUrl()
    sourceSize.value = null
    localError.value = ''
    loading.value = false
  }
}, { immediate: true })

onBeforeUnmount(cleanupObjectUrl)
</script>

<template>
  <AssetCropperFrame v-model:open="localOpen" :embedded="embedded" :title="title" :ui="{ content: 'max-w-6xl overflow-hidden' }">
    <template #body>
      <div
        class="asset-image-cropper-layout"
        :class="embedded ? 'asset-image-cropper-layout--embedded' : 'max-h-[calc(100dvh-12rem)] overflow-x-hidden overflow-y-auto'"
        data-asset-image-cropper
        :data-has-instance="Boolean(getCropper())"
        :data-ready="cropperReady"
        :data-loading="loading"
        :data-processing="processing"
        :data-can-confirm="canConfirm"
      >
        <div class="min-w-0 space-y-3">
          <div class="overflow-hidden rounded-lg border border-default bg-elevated p-2">
            <div class="asset-image-cropper-stage relative overflow-hidden rounded-md">
              <div class="asset-image-cropper-viewport"><template v-if="imageUrl || open">
                <img
                  v-if="imageUrl"
                  :key="cropperKey"
                  ref="imageElement"
                  :src="imageUrl"
                  alt=""
                  class="block max-w-full"
                  @load="initializeCropper"
                >
                <div v-else class="grid size-full place-items-center text-sm text-muted">
                  {{ loading || pendingPreview ? '正在准备预览' : '请选择图片' }}
                </div>
              </template></div>

            </div>

            <div class="asset-image-cropper-toolbar-row" data-image-controls>
              <div class="asset-image-cropper-toolbar" role="toolbar" aria-label="图片变换工具">
                <div class="asset-image-cropper-zoom-controls" role="group" aria-label="图片缩放">
                  <UTooltip text="缩小"><UButton icon="i-tabler-minus" color="neutral" variant="ghost" size="xs" square aria-label="缩小" :disabled="zoomPercent <= ZOOM_MIN" @click="adjustZoom(-1)" /></UTooltip>
                  <div class="asset-image-cropper-zoom">
                    <input class="asset-image-cropper-zoom-range" type="range" :value="zoomPercent" :min="ZOOM_MIN" :max="ZOOM_MAX" :step="ZOOM_STEP" aria-label="缩放比例" @input="handleZoomInput">
                    <output class="text-center text-xs tabular-nums text-default" aria-live="polite">{{ zoomPercent }}%</output>
                  </div>
                  <UTooltip text="放大"><UButton icon="i-tabler-plus" color="neutral" variant="ghost" size="xs" square aria-label="放大" :disabled="zoomPercent >= ZOOM_MAX" @click="adjustZoom(1)" /></UTooltip>
                </div>
                <span class="asset-image-cropper-toolbar-divider" aria-hidden="true" />
                <div class="asset-image-cropper-transform-controls" role="group" aria-label="旋转和翻转">
                  <UTooltip text="向左旋转"><UButton icon="i-tabler-rotate-2" color="neutral" variant="ghost" size="xs" square aria-label="向左旋转" @click="rotateCrop(-90)" /></UTooltip>
                  <UTooltip text="向右旋转"><UButton icon="i-tabler-rotate-clockwise" color="neutral" variant="ghost" size="xs" square aria-label="向右旋转" @click="rotateCrop(90)" /></UTooltip>
                  <span class="mx-1 h-4 w-px bg-accented" aria-hidden="true" />
                  <UTooltip text="水平翻转"><UButton icon="i-tabler-flip-horizontal" color="neutral" variant="ghost" size="xs" square aria-label="水平翻转" @click="flipCrop('horizontal')" /></UTooltip>
                  <UTooltip text="垂直翻转"><UButton icon="i-tabler-flip-vertical" color="neutral" variant="ghost" size="xs" square aria-label="垂直翻转" @click="flipCrop('vertical')" /></UTooltip>
                  <UTooltip text="重置"><UButton icon="i-tabler-focus-centered" color="neutral" variant="ghost" size="xs" square aria-label="重置" @click="resetCrop" /></UTooltip>
                  <UTooltip text="拖动图片调整位置；滚轮或缩放工具调整大小；拖动裁剪框调整范围。"><UButton icon="i-tabler-help-circle" color="neutral" variant="ghost" size="xs" square aria-label="图片编辑帮助" /></UTooltip>
                </div>
              </div>
            </div>
          </div>

          <UAlert
            v-if="localError"
            color="error"
            variant="soft"
            icon="i-tabler-alert-circle"
            :title="localError"
          />
          <div v-if="$slots.queue" class="min-w-0"><slot name="queue" /></div>
        </div>
        <aside class="min-w-0 space-y-4">
          <slot name="controls" :source-size="sourceSize" :output-size="currentOutputSize" />

        </aside>
      </div>
    </template>

    <template #footer>
      <div class="flex w-full justify-end gap-2">
        <UButton color="neutral" variant="ghost" label="取消" :disabled="processing" @click="cancelCrop" />
        <UButton icon="i-tabler-crop" :label="confirmLabel" :loading="processing" :disabled="!canConfirm" @click="confirmCrop" />
      </div>
    </template>
  </AssetCropperFrame>
</template>

<style scoped>
.asset-image-cropper-layout {
  scrollbar-width: thin;
  scrollbar-color: var(--ui-border-accented) transparent;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 1rem;
}

@media (min-width: 1024px) {
  .asset-image-cropper-layout {
    grid-template-columns: minmax(0, 1fr) 18rem;
  }
}

@media (min-width: 1280px) {
  .asset-image-cropper-layout--embedded {
    grid-template-columns: minmax(0, 1fr) 20rem;
  }
}

.asset-image-cropper-layout--embedded .asset-image-cropper-stage {
  height: clamp(16rem, calc(100dvh - 23rem), 32rem);
  min-height: 16rem;
}

@media (max-width: 1023px) {
  .asset-image-cropper-layout--embedded .asset-image-cropper-stage {
    height: clamp(12rem, 32dvh, 20rem);
    min-height: 12rem;
  }
}

.asset-image-cropper-stage {
  height: clamp(20rem, 56vh, 32rem);
  min-height: 20rem;
  background-color: var(--ui-bg-elevated);
  background-image:
    linear-gradient(45deg, color-mix(in oklab, var(--ui-border) 45%, transparent) 25%, transparent 25%),
    linear-gradient(-45deg, color-mix(in oklab, var(--ui-border) 45%, transparent) 25%, transparent 25%),
    linear-gradient(45deg, transparent 75%, color-mix(in oklab, var(--ui-border) 45%, transparent) 75%),
    linear-gradient(-45deg, transparent 75%, color-mix(in oklab, var(--ui-border) 45%, transparent) 75%);
  background-position:
    0 0,
    0 14px,
    14px -14px,
    -14px 0;
  background-size: 28px 28px;
}

.asset-image-cropper-viewport {
  position: absolute;
  inset: 0;
}

.asset-image-cropper-layout--embedded .asset-image-cropper-viewport {
  inset: 0.75rem 3rem;
}

.asset-image-cropper-toolbar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  max-width: 100%;
  padding: 0.375rem;
  border: 1px solid var(--ui-border);
  border-radius: 0.75rem;
  background: var(--ui-bg);
}

.asset-image-cropper-toolbar-row {
  display: flex;
  justify-content: center;
  padding-top: 0.5rem;
}

.asset-image-cropper-toolbar-divider {
  width: 1px;
  height: 1.25rem;
  background: var(--ui-border-accented);
}

.asset-image-cropper-zoom-controls,
.asset-image-cropper-transform-controls {
  display: flex;
  flex: none;
  align-items: center;
  gap: 0.125rem;
}

.asset-image-cropper-zoom {
  display: grid;
  flex: none;
  width: 8rem;
  grid-template-columns: minmax(0, 1fr) 2.5rem;
  align-items: center;
  gap: 0.5rem;
}

@media (max-width: 767px) {
  .asset-image-cropper-layout--embedded .asset-image-cropper-viewport {
    inset: 0.75rem 1.75rem;
  }
  .asset-image-cropper-toolbar-divider {
    display: none;
  }
  .asset-image-cropper-zoom {
    width: 5.5rem;
    gap: 0.25rem;
  }
}

.asset-image-cropper-zoom-range {
  width: 100%;
  height: 1rem;
  cursor: pointer;
  accent-color: var(--ui-primary);
}

.asset-image-cropper-zoom-range:focus-visible {
  border-radius: 0.25rem;
  outline: 3px solid color-mix(in oklab, var(--ui-primary) 25%, transparent);
  outline-offset: 2px;
}

:deep(.cropper-container) {
  width: 100% !important;
  height: 100% !important;
}

:deep(.cropper-wrap-box),
:deep(.cropper-drag-box) {
  width: 100% !important;
  height: 100% !important;
}

:deep(.cropper-view-box),
:deep(.cropper-face) {
  outline-color: var(--ui-primary);
}

:deep(.cropper-line),
:deep(.cropper-point) {
  background-color: var(--ui-primary);
}
</style>
