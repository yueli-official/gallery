import { canvasImageBlob } from './canvas-image'
import { calculateCropCanvasSize, filenameForCrop, type AssetCropOutputType } from './image-cropper'
import { assertImageDimensions, validateImageConstraints, type AssetImageConstraints } from './image-constraints'
export interface WorkbenchCrop {left:number;top:number;width:number;height:number;rotate:number;scaleX:number;scaleY:number}
/** Original pixels and saved crop: no mounted modal required. */
export async function exportWorkbenchImage(file:File, options:{ratio?:number;side:number;maxWidth?:number;format:AssetCropOutputType;quality:number;constraints?:AssetImageConstraints}, crop?:WorkbenchCrop):Promise<File>{
 validateImageConstraints(options.constraints)
 const source=await createImageBitmap(file,{imageOrientation:'from-image'})
 try{
  const angle=(crop?.rotate||0)*Math.PI/180
  const width=Math.abs(source.width*Math.cos(angle))+Math.abs(source.height*Math.sin(angle))
  const height=Math.abs(source.width*Math.sin(angle))+Math.abs(source.height*Math.cos(angle))
  const fixedSize=options.constraints?.fixedOutputSize
  const ratio=fixedSize?fixedSize.width/fixedSize.height:options.ratio||width/height,w=Math.min(width,height*ratio),h=w/ratio
  const area=crop||{left:(width-w)/2,top:(height-h)/2,width:w,height:h,rotate:0,scaleX:1,scaleY:1}
  assertImageDimensions(area,options.constraints)
  if(fixedSize&&Math.abs(area.width-area.height*ratio)>Math.max(1,ratio))throw new Error('裁剪比例不符合固定输出尺寸，请重新裁剪')
  const bounds={width:options.maxWidth??options.side,height:options.maxWidth===undefined?options.side:undefined}
  if(options.constraints?.maxOutputSide){bounds.width=Math.min(bounds.width,options.constraints.maxOutputSide);bounds.height=Math.min(bounds.height??options.constraints.maxOutputSide,options.constraints.maxOutputSide)}
  const size=fixedSize??calculateCropCanvasSize(area,bounds)
  assertImageDimensions(size,options.constraints,true)
  const canvas=document.createElement('canvas');canvas.width=size.width;canvas.height=size.height
  const ctx=canvas.getContext('2d',{colorSpace:'srgb'});if(!ctx)throw new Error('当前浏览器不支持图片处理')
  if(options.format==='image/jpeg'){ctx.fillStyle='#fff';ctx.fillRect(0,0,size.width,size.height)}
  ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high'
  ctx.scale(size.width/area.width,size.height/area.height);ctx.translate(-area.left,-area.top);ctx.translate(width/2,height/2);ctx.rotate(angle);ctx.scale(area.scaleX,area.scaleY);ctx.drawImage(source,-source.width/2,-source.height/2)
  const blob=await canvasImageBlob(canvas,options.format,options.quality/100)
  canvas.width=canvas.height=1
  if(options.constraints?.maxBytes&&blob.size>options.constraints.maxBytes)throw new Error('处理后的图片超过资源策略允许的大小，请调整质量或边长')
  return new File([blob],filenameForCrop(file.name,options.format),{type:options.format})
 }finally{source.close()}
}
