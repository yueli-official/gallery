import { createBffHandler } from "@yueli/nuxt-runtime/server";

export function createAssetApiProxy(timeoutMs: number) {
  return createBffHandler({
    mountPath: "/asset-api",
    profile: "asset",
    timeoutMs,
    maxRequestBodyBytes: 1024 * 1024,
    resolveTarget({ event }) {
      return assetBffTarget(String(useRuntimeConfig(event).assetBase));
    },
    credential: {
      async resolve({ event }) {
        const runtime = useRuntimeConfig(event);
        const audience = String(runtime.assetAudience || "asset-api");
        let headers = await sessionAuthHeaders(event);
        if (!headers.authorization) {
          headers = ["GET", "HEAD", "OPTIONS"].includes(event.method)
            ? await guestSessionAuthHeaders(event, audience, false)
            : await guestSessionAuthHeaders(event, audience);
        }
        return assetBffCredential(headers);
      },
    },
  });
}
