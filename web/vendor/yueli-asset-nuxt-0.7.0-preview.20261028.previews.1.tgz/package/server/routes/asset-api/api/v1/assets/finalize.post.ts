import { createAssetApiProxy } from "../../../../../utils/assetApiProxy";

// Finalization includes all configured previews, including under encoder contention.
export default createAssetApiProxy(10 * 60_000);
