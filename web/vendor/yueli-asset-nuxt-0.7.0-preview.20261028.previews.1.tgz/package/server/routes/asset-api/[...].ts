import { createAssetApiProxy } from "../../utils/assetApiProxy";

export default createAssetApiProxy(60_000);
