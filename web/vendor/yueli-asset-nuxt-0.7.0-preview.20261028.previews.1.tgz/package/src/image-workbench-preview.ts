export interface ImageRasterPreview {url:string;width:number;height:number;previewWidth:number;previewHeight:number}
type Reply={id:number;blob?:Blob;error?:string;width:number;height:number;previewWidth:number;previewHeight:number;editBlob?:Blob;editWidth?:number;editHeight?:number}
/** One decoder worker, 256px thumbnails, encoded 1536px previews capped at 64 MiB. */
export class ImageWorkbenchPreviewStore {
 private worker:Worker|null=null
 private next=0
 private closed=false
 private pending=new Map<number,{resolve:(value:Reply)=>void;reject:(error:Error)=>void}>()
 private thumbnails=new Set<string>()
 private edits=new Map<string,ImageRasterPreview>()
 private requests=new Map<string,Promise<ImageRasterPreview>>()
 private pinned=''
 private sizes=new Map<string,number>()
 private encodedBytes=0
 private readonly maxEncodedBytes=64*1024*1024
 private createWorker(){
  if(this.worker)return this.worker
  const worker=new Worker(new URL('./image-workbench-preview.worker.ts',import.meta.url),{type:'module'})
  worker.onmessage=(event:MessageEvent<Reply>)=>{const item=this.pending.get(event.data.id);if(!item)return;this.pending.delete(event.data.id);if(event.data.error)item.reject(new Error(event.data.error));else item.resolve(event.data)}
  worker.onerror=()=>{for(const item of this.pending.values())item.reject(new Error('图片预览处理失败'));this.pending.clear()}
  this.worker=worker;return worker
 }
 private async request(file:File,side:number):Promise<Reply>{
  if(this.closed)throw new Error('图片会话已关闭')
  const id=++this.next
  const value=await new Promise<Reply>((resolve,reject)=>{this.pending.set(id,{resolve,reject});this.createWorker().postMessage({id,file,side})})
  if(this.closed)throw new Error('图片会话已关闭')
  return value
 }
 private raster(value:Reply):ImageRasterPreview{return {url:URL.createObjectURL(value.blob!),width:value.width,height:value.height,previewWidth:value.previewWidth,previewHeight:value.previewHeight}}
 private cache(key:string,value:ImageRasterPreview,size:number){this.remove(key);this.edits.set(key,value);this.sizes.set(key,size);this.encodedBytes+=size;this.trim()}
 async thumbnail(file:File,key:string){const result=await this.request(file,256);if(result.editBlob)this.cache(key,{url:URL.createObjectURL(result.editBlob),width:result.width,height:result.height,previewWidth:result.editWidth!,previewHeight:result.editHeight!},result.editBlob.size);const value=this.raster(result);this.thumbnails.add(value.url);return value}
 releaseThumbnail(url:string){if(this.thumbnails.delete(url))URL.revokeObjectURL(url)}
 pin(key:string){this.pinned=key}
 async preview(file:File,key:string){
  const cached=this.edits.get(key)
  if(cached){this.edits.delete(key);this.edits.set(key,cached);return cached}
  const pending=this.requests.get(key);if(pending)return pending
  const request=this.request(file,1536).then(reply=>{const value=this.raster(reply);this.cache(key,value,reply.blob!.size);return value}).finally(()=>this.requests.delete(key))
  this.requests.set(key,request);return request
 }
 private trim(){while(this.encodedBytes>this.maxEncodedBytes){const key=Array.from(this.edits.keys()).find(k=>k!==this.pinned);if(!key)break;this.remove(key)}}
 remove(key:string){const cached=this.edits.get(key);if(cached){URL.revokeObjectURL(cached.url);this.edits.delete(key);this.encodedBytes-=this.sizes.get(key)||0;this.sizes.delete(key)}}
 dispose(){this.closed=true;this.worker?.terminate();this.worker=null;for(const item of this.pending.values())item.reject(new Error('图片会话已关闭'));this.pending.clear();for(const url of this.thumbnails)URL.revokeObjectURL(url);for(const value of this.edits.values())URL.revokeObjectURL(value.url);this.thumbnails.clear();this.edits.clear();this.requests.clear();this.sizes.clear();this.encodedBytes=0}
 get stats(){return {thumbnails:this.thumbnails.size,editPreviews:this.edits.size,encodedBytes:this.encodedBytes,maxEncodedBytes:this.maxEncodedBytes}}
}
