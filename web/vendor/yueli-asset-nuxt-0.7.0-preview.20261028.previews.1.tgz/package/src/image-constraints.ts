import type { AssetCropOutputType } from './image-cropper'

/** Consumer-owned image requirements. Dimensions are original/output pixels, never preview pixels. */
export interface AssetImageConstraints {
  aspectRatio?: number
  lockAspectRatio?: boolean
  minWidth?: number
  minHeight?: number
  maxOutputSide?: number
  /** Exact output dimensions; also lock the crop ratio. Small crops are rejected, never enlarged. */
  fixedOutputSize?: { width: number; height: number }
  outputType?: AssetCropOutputType
  /** Exact lossy encoder quality from 1 to 100. PNG ignores this setting. */
  outputQuality?: number
  maxBytes?: number
  allowAnimation?: boolean
}

export function validateImageConstraints(rules: AssetImageConstraints = {}) {
  for (const key of ['minWidth', 'minHeight', 'maxOutputSide', 'maxBytes'] as const) {
    const value = rules[key]
    if (value !== undefined && (!Number.isSafeInteger(value) || value <= 0)) throw new Error(`${key} 必须为正整数`)
  }
  if (rules.aspectRatio !== undefined && (!Number.isFinite(rules.aspectRatio) || rules.aspectRatio <= 0)) throw new Error('图片比例必须大于零')
  if (rules.outputQuality !== undefined && (!Number.isSafeInteger(rules.outputQuality) || rules.outputQuality < 1 || rules.outputQuality > 100)) throw new Error('输出质量必须为 1 到 100 的整数')
  if (rules.lockAspectRatio && rules.aspectRatio === undefined && !rules.fixedOutputSize) throw new Error('锁定比例时必须配置图片比例')
  if (rules.fixedOutputSize) {
    const { width, height } = rules.fixedOutputSize
    if (![width, height].every(value => Number.isSafeInteger(value) && value > 0)) throw new Error('固定输出宽高必须为正整数')
    if (rules.aspectRatio !== undefined && Math.abs(rules.aspectRatio - width / height) > 0.000001) throw new Error('固定输出尺寸与配置比例冲突')
    if ((rules.minWidth || 0) > width || (rules.minHeight || 0) > height) throw new Error('最小尺寸不能超过固定输出尺寸')
    if (rules.maxOutputSide && Math.max(width, height) > rules.maxOutputSide) throw new Error('固定输出尺寸超过最大输出边长')
  }
  const ratio = rules.lockAspectRatio ? rules.aspectRatio : undefined
  const width = Math.max(rules.minWidth || 0, ratio ? (rules.minHeight || 0) * ratio : 0)
  const height = Math.max(rules.minHeight || 0, ratio ? (rules.minWidth || 0) / ratio : 0)
  if (rules.maxOutputSide && Math.max(width, height) > rules.maxOutputSide) throw new Error('最小尺寸与最大输出边长冲突，请调整图片配置')
}

export function assertImageDimensions(size: { width: number; height: number }, rules: AssetImageConstraints = {}, output = false) {
  const minWidth = Math.max(rules.minWidth || 0, rules.fixedOutputSize?.width || 0)
  const minHeight = Math.max(rules.minHeight || 0, rules.fixedOutputSize?.height || 0)
  if (size.width < minWidth) throw new Error(`图片宽度不能小于 ${minWidth}px，请选择更大的原图或扩大裁剪区域`)
  if (size.height < minHeight) throw new Error(`图片高度不能小于 ${minHeight}px，请选择更大的原图或扩大裁剪区域`)
  if (!output) return
  if (rules.fixedOutputSize && (size.width !== rules.fixedOutputSize.width || size.height !== rules.fixedOutputSize.height)) throw new Error(`输出图片必须为 ${rules.fixedOutputSize.width} × ${rules.fixedOutputSize.height}px`)
  if (rules.maxOutputSide && Math.max(size.width, size.height) > rules.maxOutputSide) throw new Error(`图片最长边不能超过 ${rules.maxOutputSide}px`)
  if (rules.lockAspectRatio && rules.aspectRatio && Math.abs(size.width - size.height * rules.aspectRatio) > Math.max(1, rules.aspectRatio)) throw new Error('图片比例不符合要求，请重新裁剪')
}
