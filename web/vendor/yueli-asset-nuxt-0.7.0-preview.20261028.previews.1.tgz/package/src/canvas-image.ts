/** Only for newly encoded sRGB canvases, never for original uploaded files. */
export function canvasImageBytes(bytes: Uint8Array, type: string): Uint8Array {
  const parts: Uint8Array[] = []
  if (type === 'image/webp') {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength)
    parts.push(bytes.slice(0, 12))
    let removed = false
    for (let offset = 12; offset < bytes.length;) {
      if (offset + 8 > bytes.length) throw new Error('图片编码无效')
      const length = view.getUint32(offset + 4, true)
      const end = offset + 8 + length + (length & 1)
      if (end > bytes.length) throw new Error('图片编码无效')
      const kind = String.fromCharCode(...bytes.subarray(offset, offset + 4))
      if (kind === 'ICCP') removed = true
      else parts.push(bytes.slice(offset, end))
      offset = end
    }
    if (removed) for (const part of parts.slice(1)) {
      if (String.fromCharCode(...part.subarray(0, 4)) === 'VP8X') part[8] = part[8]! & ~0x20
    }
  } else if (type === 'image/jpeg') {
    parts.push(bytes.slice(0, 2))
    for (let offset = 2; offset < bytes.length;) {
      if (bytes[offset] !== 0xff) throw new Error('图片编码无效')
      const marker = bytes[offset + 1]
      if (marker === 0xda || marker === 0xd9) { parts.push(bytes.slice(offset)); break }
      const length = ((bytes[offset + 2] || 0) << 8) | (bytes[offset + 3] || 0)
      const end = offset + 2 + length
      if (length < 2 || end > bytes.length) throw new Error('图片编码无效')
      const signature = String.fromCharCode(...bytes.subarray(offset + 4, offset + 16))
      if (!(marker === 0xe2 && signature === 'ICC_PROFILE\0')) parts.push(bytes.slice(offset, end))
      offset = end
    }
  } else return bytes
  const result = new Uint8Array(parts.reduce((length, part) => length + part.length, 0))
  let offset = 0
  for (const part of parts) { result.set(part, offset); offset += part.length }
  if (type === 'image/webp') new DataView(result.buffer).setUint32(4, result.length - 8, true)
  return result
}

export async function canvasImageBlob(canvas: HTMLCanvasElement, type: string, quality: number): Promise<Blob> {
  const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, type, quality))
  if (!blob || blob.type !== type) throw new Error('图片导出格式不受当前浏览器支持')
  if (type !== 'image/webp' && type !== 'image/jpeg') return blob
  return new Blob([canvasImageBytes(new Uint8Array(await blob.arrayBuffer()), type) as Uint8Array<ArrayBuffer>], { type })
}
