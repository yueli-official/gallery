<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { CollectionPanel, CollectionPagination } from '@yueli/ui/collection/pattern';
import type { CollectionControl, CollectionPanelMessages } from '@yueli/ui/collection/pattern';
import { AdminRowActions } from '@yueli/ui/admin';
import { useMinimumLoading } from '@yueli/ui/feedback';
import AssetReferenceSummary from './AssetReferenceSummary.vue';
import type { AssetReferenceAttempt, AssetReferenceHistoryPage, AssetReferenceOwnerStatus, AssetReferenceStatusPage, AssetReferenceSyncAdapter, AssetReferenceSyncMode, AssetReferenceSyncRun, AssetReferenceSyncRunPage, AssetReferenceSyncRunItemPage } from '../references';

const props = withDefaults(defineProps<{ adapter: AssetReferenceSyncAdapter; canRetry?: boolean; embedded?: boolean; active?: boolean; showHeader?: boolean }>(), { showHeader: true });
const result = ref<AssetReferenceStatusPage | null>(null);
const loading = ref(false);
const visibleLoading = useMinimumLoading(loading);
const failure = ref('');
const notice = ref('');
const operationFailure = ref('');
const page = ref(1);
const size = ref(10);
const search = ref('');
const filters = ref<Record<string, string>>({ refType: '*', status: '*', hasAssets: '*', sourceWindow: '*', syncWindow: '*' });
const operating = ref(false);
const progress = ref('');
const syncRuns = ref<AssetReferenceSyncRunPage | null>(null);
const runsLoading = ref(false);
const runsFailure = ref('');
const taskHistoryOpen = ref(false);
const taskHistory = ref<AssetReferenceSyncRunPage | null>(null);
const taskHistoryPage = ref(1);
const taskHistoryLoading = ref(false);
const taskHistoryFailure = ref('');
const taskDetail = ref<AssetReferenceSyncRun | null>(null);
const taskItems = ref<AssetReferenceSyncRunItemPage | null>(null);
const taskItemsPage = ref(1);
const taskItemsLoading = ref(false);
const taskItemsFailure = ref('');
const currentRun = computed(() => syncRuns.value?.items.find(run => run.status === 'running') ?? syncRuns.value?.items[0]);
const runActive = computed(() => currentRun.value?.status === 'running');
const runNeedsAttention = computed(() => currentRun.value?.status === 'partial' || currentRun.value?.status === 'failed');
let pollTimer: ReturnType<typeof setTimeout> | undefined;
let disposed = false;
let runReadSequence = 0;
let taskReadSequence = 0;
let taskItemReadSequence = 0;
const historyOwner = ref<AssetReferenceOwnerStatus | null>(null);
const historyOpen = ref(false);
const historyResult = ref<AssetReferenceHistoryPage | null>(null);
const historyPage = ref(1);
const historyLoading = ref(false);
const historyFailure = ref('');
const attemptJob = ref('');
const attempts = ref<AssetReferenceAttempt[]>([]);
const attemptLoading = ref(false);
const attemptFailure = ref('');
let loadSequence = 0;
let historySequence = 0;
let attemptSequence = 0;
const items = computed(() => result.value?.items ?? []);
const filterCount = computed(() => Object.values(filters.value).filter(value => value !== '*').length);
const controls = computed<CollectionControl[]>(() => [
  { kind: 'select', id: 'refType', label: '对象类型', value: filters.value.refType!, options: [{ label: '全部类型', value: '*' }, ...Object.entries(props.adapter.kindLabels ?? {}).map(([value, label]) => ({ value, label }))] },
  { kind: 'select', id: 'status', label: '同步状态', value: filters.value.status!, options: [{ label: '全部状态', value: '*' }, { label: '已同步', value: 'synced' }, { label: '待同步', value: 'pending' }, { label: '同步失败', value: 'failed' }, { label: '同步中', value: 'running' }, { label: '等待重试', value: 'retrying' }] },
  { kind: 'select', id: 'hasAssets', label: '引用资源', value: filters.value.hasAssets!, options: [{ label: '不限', value: '*' }, { label: '有资源引用', value: 'yes' }, { label: '无资源引用', value: 'no' }] },
  ...[['sourceWindow', '内容更新时间'], ['syncWindow', '成功同步时间']].map(([id, label]) => ({ kind: 'select' as const, id: id!, label: label!, value: filters.value[id!]!, options: [{ label: '不限时间', value: '*' }, { label: '最近 24 小时', value: '1' }, { label: '最近 7 天', value: '7' }, { label: '最近 30 天', value: '30' }] })),
]);
const messages = computed<CollectionPanelMessages>(() => ({
  searchPlaceholder: '搜索对象名称或 ID', searchAction: '搜索', filtersAction: '筛选', activeFilters: count => `${count} 项筛选`, clearFilters: '清除筛选',
  selectPage: '选择本页对象', selectItem: label => `选择 ${label}`, bulkRegion: '引用批量操作', selected: count => `已选 ${count} 项`, selectAllResults: '选择全部结果', clearSelection: '取消选择',
  emptyTitle: search.value || filterCount.value ? '没有符合条件的对象' : '尚无引用记录', emptyDescription: search.value || filterCount.value ? '调整搜索或筛选条件后重试。' : '保存使用资源的内容后，会在此登记引用状态。',
  errorTitle: '引用状态加载失败', retry: '重新加载', showing: (first, last, total) => `${first}–${last} / ${total} 项`, pageSize: '每页条数', pageSizeControl: '每页条数', pageSizeOption: count => `${count} 项 / 页`,
}));
function key(owner: Pick<AssetReferenceOwnerStatus, 'refType' | 'refId'>) { return JSON.stringify([owner.refType, owner.refId]); }
function synced(owner: AssetReferenceOwnerStatus) { return owner.appliedVersion >= owner.version; }
function state(value: string) { return ({ synced: '已同步', succeeded: '成功', failed: '同步失败', running: '同步中', retrying: '等待重试', queued: '等待同步', paused: '已暂停', cancelled: '已取消', lease_expired: '执行中断' } as Record<string, string>)[value] || '待确认'; }
function timestamp(value?: string) { return value ? new Date(value).toLocaleString() : '未记录'; }
function date(value?: string) { return value ? new Date(value).toLocaleDateString() : '未记录'; }
function time(value?: string) { return value ? new Date(value).toLocaleTimeString() : ''; }
function origin(value: string) { return ({ change: '内容保存', manual: '手动同步', retry: '失败重试', 'global-pending': '同步未同步对象', 'global-force': '强制同步全部', initialization: '初始化', retirement:'旧引用退役' } as Record<string, string>)[value] || '历史记录'; }
function active(value?: string) { return value === '*' ? undefined : value; }
function after(days?: string) { return days && days !== '*' ? new Date(Date.now() - Number(days) * 86400000).toISOString() : undefined; }
async function load(nextPage = page.value) {
  const sequence = ++loadSequence;
  page.value = nextPage; loading.value = true; failure.value = '';
  try {
    const next = await props.adapter.list({ page: nextPage, size: size.value, search: search.value.trim(), refType: active(filters.value.refType), status: active(filters.value.status), hasAssets: active(filters.value.hasAssets), sourceAfter: after(filters.value.sourceWindow), syncedAfter: after(filters.value.syncWindow) });
    if (sequence !== loadSequence) return;
    result.value = next;
  } catch (error) { if (sequence === loadSequence) failure.value = props.adapter.describeError(error); }
  finally { if (sequence === loadSequence) loading.value = false; }
}
function applyFilters(snapshot: { values: Record<string, string | number> }) {
  filters.value = Object.fromEntries(Object.keys(filters.value).map(id => [id, String(snapshot.values[id] ?? '*')]));
  void load(1);
}
function clearFilters() { filters.value = Object.fromEntries(Object.keys(filters.value).map(id => [id, '*'])); void load(1); }
async function operate(owners: AssetReferenceOwnerStatus[], action: 'sync' | 'retry') {
  if (!props.canRetry || operating.value || loading.value || !owners.length) return;
  operating.value = true; operationFailure.value = ''; notice.value = '';

  let completed = 0;
  const failed: string[] = [];
  try {
    for (const [index, owner] of owners.entries()) {
      progress.value = `正在提交 ${index + 1} / ${owners.length}`;
      try { await props.adapter[action](owner); completed++; }
      catch (error) { failed.push(`${owner.label || owner.refId}：${props.adapter.describeError(error)}`); }
    }
    notice.value = completed ? `已提交 ${completed} 项${action === 'sync' ? '同步' : '重试'}。队列执行后点击“刷新状态”查看结果。` : '';
    operationFailure.value = failed.length ? `${failed.length} 项未能提交：${failed.slice(0, 3).join('、')}${failed.length > 3 ? '等' : ''}。请刷新状态后重试。` : '';
    await load();
  } finally { operating.value = false; progress.value = ''; }
}
function actions(owner: AssetReferenceOwnerStatus) {
  return [
    { id: 'history', label: '同步记录', icon: 'i-tabler-history', onSelect: () => { historyOwner.value = owner; historyOpen.value = true; void loadHistory(1); } },
    { id: 'sync', label: '重新同步引用', icon: 'i-tabler-refresh', hidden: !props.canRetry, disabled: operating.value || loading.value, onSelect: () => { void operate([owner], 'sync'); } },
    { id: 'retry', label: '重试失败任务', icon: 'i-tabler-rotate-clockwise', hidden: !props.canRetry || synced(owner) || owner.status !== 'failed', disabled: operating.value || loading.value, onSelect: () => { void operate([owner], 'retry'); } },
  ];
}
function modeLabel(mode: AssetReferenceSyncMode) { return mode === 'force' ? '强制同步全部对象' : '同步未同步对象'; }
function runState(run: AssetReferenceSyncRun) { return ({ running: '同步中', succeeded: '已完成', partial: '部分失败', failed: '已中断' } as Record<string, string>)[run.status] || '待确认'; }
function completed(run: AssetReferenceSyncRun) { return run.succeeded + run.failed + run.skipped; }
function stopPolling() { if (pollTimer) clearTimeout(pollTimer); pollTimer = undefined; }
async function loadRuns() {
  stopPolling(); const sequence = ++runReadSequence; const wasRunning = runActive.value;
  runsLoading.value = true; runsFailure.value = '';
  try {
    const next = await props.adapter.syncRuns(1, 5);
    if (disposed || sequence !== runReadSequence) return;
    syncRuns.value = next;
    if (wasRunning && !next.items.some(run => run.status === 'running')) void load();
    if (props.active !== false && next.items.some(run => run.status === 'running')) pollTimer = setTimeout(() => { void loadRuns(); }, 5000);
  } catch (error) { if (!disposed && sequence === runReadSequence) runsFailure.value = props.adapter.describeError(error); }
  finally { if (sequence === runReadSequence) runsLoading.value = false; }
}
async function refresh() { await Promise.all([load(), loadRuns()]); }
async function startGlobalSync(mode: AssetReferenceSyncMode) {
  if (!props.canRetry || operating.value || runActive.value || runsLoading.value || loading.value) return;
  operating.value = true; notice.value = ''; operationFailure.value = '';
  try {
    const run = await props.adapter.startSync(mode);
    syncRuns.value = { items: [run], total: 1, page: 1, size: 5 };
    if (!run.total) notice.value = '当前没有需要同步的对象。';
    else if (run.mode !== mode) notice.value = `已有“${modeLabel(run.mode)}”任务，后台将继续执行。`;
    await loadRuns();
  } catch (error) { operationFailure.value = props.adapter.describeError(error); }
  finally { operating.value = false; }
}
function backToTasks() { ++taskItemReadSequence; taskDetail.value = null; }
function openTaskHistory() { backToTasks(); taskHistoryOpen.value = true; void loadTaskHistory(1); }
async function loadTaskHistory(nextPage = taskHistoryPage.value) {
  const sequence = ++taskReadSequence;
  taskHistoryPage.value = nextPage; taskHistoryLoading.value = true; taskHistoryFailure.value = '';
  try { const next = await props.adapter.syncRuns(nextPage, 10); if (sequence === taskReadSequence) taskHistory.value = next; }
  catch (error) { if (sequence === taskReadSequence) taskHistoryFailure.value = props.adapter.describeError(error); }
  finally { if (sequence === taskReadSequence) taskHistoryLoading.value = false; }
}
async function loadTaskItems(run: AssetReferenceSyncRun, nextPage = 1) {
  const sequence = ++taskItemReadSequence;
  taskDetail.value = run; taskItemsPage.value = nextPage; taskItemsLoading.value = true; taskItemsFailure.value = '';
  try { const next = await props.adapter.syncRunItems(run.id, nextPage, 10); if (sequence === taskItemReadSequence) taskItems.value = next; }
  catch (error) { if (sequence === taskItemReadSequence) taskItemsFailure.value = props.adapter.describeError(error); }
  finally { if (sequence === taskItemReadSequence) taskItemsLoading.value = false; }
}
watch(() => props.active, active => { if (active === false) stopPolling(); else if (!disposed) void loadRuns(); });
async function loadHistory(nextPage = historyPage.value) {
  if (!historyOwner.value) return;
  const sequence = ++historySequence;
  ++attemptSequence; attemptJob.value = ''; attempts.value = []; attemptLoading.value = false;
  historyPage.value = nextPage; historyResult.value = null; historyFailure.value = ''; historyLoading.value = true;
  try { const next = await props.adapter.history(historyOwner.value, nextPage, 10); if (sequence === historySequence) historyResult.value = next; }
  catch (error) { if (sequence === historySequence) historyFailure.value = props.adapter.describeError(error); }
  finally { if (sequence === historySequence) historyLoading.value = false; }
}
async function loadAttempts(jobId: string) {
  if (!historyOwner.value) return;
  const sequence = ++attemptSequence;
  attemptJob.value = jobId; attempts.value = []; attemptFailure.value = ''; attemptLoading.value = true;
  try { const next = await props.adapter.attempts(historyOwner.value, jobId); if (sequence === attemptSequence) attempts.value = next; }
  catch (error) { if (sequence === attemptSequence) attemptFailure.value = props.adapter.describeError(error); }
  finally { if (sequence === attemptSequence) attemptLoading.value = false; }
}
onMounted(() => { void refresh(); });
onBeforeUnmount(() => { disposed = true; ++runReadSequence; stopPolling(); });
defineExpose({ result, failure, openTaskHistory });
</script>

<template>
  <div :class="embedded ? 'min-w-0' : 'yueli-card mt-5 min-w-0'">
    <header v-if="showHeader" class="border-b border-default px-3 py-3 sm:px-4">
      <AssetReferenceSummary :result="result" :failed-to-load="!!failure" :can-retry="canRetry" @history="openTaskHistory" />
    </header>
    <div v-if="runActive || runNeedsAttention || runsFailure || notice || operationFailure || (operating && progress)" class="space-y-3 border-b border-default px-3 py-3 sm:px-4">
      <div v-if="runActive && currentRun" class="space-y-2" role="status">
        <div class="flex flex-wrap items-center justify-between gap-2 text-sm"><span class="inline-flex items-center gap-2"><UIcon name="i-tabler-loader-2" class="size-4 animate-spin text-primary" />{{ modeLabel(currentRun.mode) }}<span class="text-muted">同步中</span></span><span class="text-xs tabular-nums text-muted">{{ completed(currentRun) }} / {{ currentRun.total }}</span></div>
        <UProgress :model-value="completed(currentRun)" :max="currentRun.total || 1" aria-label="全局同步进度" size="xs" />
        <p v-if="currentRun.lastError" class="text-xs text-error">{{ currentRun.lastError }}</p>
      </div>
      <div v-if="runNeedsAttention && currentRun" role="alert" class="flex flex-wrap items-center justify-between gap-2">
        <p class="text-sm text-error">{{ currentRun.status === 'partial' ? '上次同步有失败项。' : '上次同步已中断。' }}</p>
        <UButton label="查看任务记录" color="neutral" variant="ghost" size="sm" @click="openTaskHistory" />
      </div>
      <div v-if="runsFailure" role="alert" class="flex flex-wrap items-center gap-2"><p class="text-sm text-error">{{ runsFailure }}</p><UButton label="重新读取任务" color="neutral" variant="ghost" size="sm" @click="loadRuns" /></div>
      <p v-if="operating && progress" class="text-xs text-muted" role="status">{{ progress }}</p><UAlert v-if="notice" color="success" variant="subtle" :description="notice" /><UAlert v-if="operationFailure" color="error" variant="subtle" :description="operationFailure" />
    </div>
    <CollectionPanel v-model:search="search" label="资源引用" surface="plain" :items="items" :item-key="key" :item-label="owner => owner.label || owner.refId" :messages="messages"
      :controls="controls" :active-filter-count="filterCount" :state="visibleLoading ? 'loading' : failure ? 'error' : 'ready'" :error-message="failure" :total="result?.total ?? 0" :page="page" :page-size="size"
      @search="load(1)" @filter-apply="applyFilters" @clear-filters="clearFilters" @retry="load()" @page-change="load($event)" @page-size-change="size = $event; load(1)">
      <template #utilities><UTooltip text="刷新状态"><UButton aria-label="刷新状态" icon="i-tabler-refresh" variant="ghost" color="neutral" :loading="loading || runsLoading" :disabled="operating" @click="refresh" /></UTooltip></template>
      <template #actions><div class="flex min-w-0 flex-wrap items-center justify-end gap-1.5">
        <UButton v-if="canRetry" label="同步未同步对象" icon="i-tabler-player-play" :disabled="operating || runActive || loading || runsLoading || !result?.pending" @click="startGlobalSync('pending')" />
        <UButton v-if="canRetry" label="强制同步全部" icon="i-tabler-refresh" color="neutral" variant="outline" :disabled="operating || runActive || loading || runsLoading || !result?.registered" @click="startGlobalSync('force')" />

      </div></template>
      <template #columns><div class="reference-columns"><span>对象</span><span class="reference-wide">资源数</span><span class="reference-wide">同步状态</span><span class="reference-wide">内容更新</span><span class="reference-wide">成功同步</span><span class="reference-wide sr-only">操作</span></div></template>
      <template #loading><div v-for="index in 5" :key="index" class="reference-row border-b border-default px-3 py-4 last:border-0 sm:px-4"><div class="flex items-center gap-3"><USkeleton class="size-9 shrink-0 rounded-lg" /><div class="flex-1 space-y-2"><USkeleton class="h-4 w-3/4 rounded" /><USkeleton class="h-3 w-1/3 rounded" /></div></div><USkeleton v-for="column in 4" :key="column" class="reference-wide h-4 w-3/4 rounded" /></div></template>
      <template #item="{ item: owner }">
        <div class="reference-row">
          <div class="reference-identity flex min-w-0 items-center gap-3">
            <span class="grid size-9 shrink-0 place-items-center rounded-lg bg-elevated text-muted"><UIcon name="i-tabler-file-description" class="size-5" /></span>
            <div class="min-w-0"><p :title="owner.label || owner.refId" class="line-clamp-2 break-words text-sm font-medium">{{ owner.label || owner.refId }}</p><p class="mt-1 text-xs text-muted">{{ adapter.kindLabels?.[owner.refType] || owner.refType }}<span class="reference-compact"> · {{ owner.referenceCount }} 个资源</span></p></div>
          </div>
          <span class="reference-wide text-sm tabular-nums" :aria-label="`${owner.referenceCount} 个资源`">{{ owner.referenceCount }}</span>
          <span class="reference-state inline-flex items-center gap-1.5 text-xs" :class="synced(owner) ? 'text-success' : owner.status === 'failed' ? 'text-error' : 'text-warning'"><UIcon :name="synced(owner) ? 'i-tabler-circle-check' : owner.status === 'failed' ? 'i-tabler-alert-circle' : 'i-tabler-clock'" class="size-4 shrink-0" />{{ state(synced(owner) ? 'synced' : owner.status) }}</span>
          <time :datetime="owner.sourceUpdatedAt" class="reference-source text-xs tabular-nums text-muted"><span class="reference-compact">内容更新：</span><span class="reference-date">{{ date(owner.sourceUpdatedAt) }}</span><span class="reference-time">{{ time(owner.sourceUpdatedAt) }}</span></time>
          <time :datetime="owner.syncedAt" class="reference-synced text-xs tabular-nums text-muted"><span class="reference-compact">成功同步：</span><span class="reference-date">{{ date(owner.syncedAt) }}</span><span class="reference-time">{{ time(owner.syncedAt) }}</span></time>
          <div class="reference-actions justify-self-end"><AdminRowActions :items="actions(owner)" :label="`${owner.label || owner.refId}的操作`" presentation="overflow" /></div>
          <p v-if="owner.lastError && !synced(owner)" class="col-span-full break-words text-xs text-error">{{ owner.lastError }}</p>
        </div>
      </template>
    </CollectionPanel>
    <details v-if="result?.initializations.length" class="border-t border-default px-3 py-4 text-xs text-muted sm:px-4"><summary class="cursor-pointer">初始化记录</summary><ul class="mt-3 space-y-2"><li v-for="run in result.initializations" :key="run.id">{{ timestamp(run.startedAt) }} · {{ run.actor }} · {{ run.status === 'succeeded' ? '已登记' : state(run.status) }} · {{ run.owners }} 个对象，清理 {{ run.cleared }} 个已移除对象</li></ul></details>
    <UModal v-model:open="historyOpen" title="同步记录" :description="historyOwner?.label || historyOwner?.refId" :ui="{ content: 'max-w-2xl' }">
      <template #body>
        <p v-if="historyOwner" class="mb-4 text-xs text-muted">目标版本 {{ historyOwner.version }} · 已应用版本 {{ historyOwner.appliedVersion }}</p>
        <p v-if="historyLoading" role="status" class="py-6 text-sm text-muted">正在加载同步记录…</p>
        <div v-else-if="historyFailure" role="alert"><p class="text-sm text-error">{{ historyFailure }}</p><UButton label="重新加载" variant="ghost" @click="loadHistory()" /></div>
        <p v-else-if="!historyResult?.items.length" class="py-6 text-sm text-muted">尚无保留的同步记录。</p>
        <ol v-else class="divide-y divide-default">
          <li v-for="job in historyResult.items" :key="job.id" class="py-4 first:pt-0">
            <div class="flex flex-wrap items-center justify-between gap-2"><p class="text-sm font-medium">{{ origin(job.origin) }} · 版本 {{ job.version }}</p><UBadge :color="job.status === 'succeeded' ? 'success' : job.status === 'failed' ? 'error' : 'warning'" variant="subtle">{{ state(job.status) }}</UBadge></div>
            <p class="mt-2 break-all text-xs text-muted">操作人：{{ job.actor || '未记录' }}</p>
            <p class="mt-1 text-xs text-muted">提交：{{ timestamp(job.requestedAt) }}<span v-if="job.finishedAt"> · 结束：{{ timestamp(job.finishedAt) }}</span></p>
            <p v-if="job.lastError" class="mt-2 break-words text-xs text-error">{{ job.lastError }}</p>
            <UButton label="执行明细" color="neutral" variant="ghost" size="xs" class="mt-2" @click="loadAttempts(job.id)" />
            <div v-if="attemptJob === job.id" class="mt-2 rounded-md bg-elevated p-3 text-xs" aria-live="polite"><p v-if="attemptLoading">正在加载执行明细…</p><div v-else-if="attemptFailure"><p class="text-error">{{ attemptFailure }}</p><UButton label="重新加载明细" size="xs" variant="ghost" @click="loadAttempts(job.id)" /></div><p v-else-if="!attempts.length" class="text-muted">尚未开始执行。</p><ol v-else class="space-y-2"><li v-for="attempt in attempts" :key="attempt.number">第 {{ attempt.number }} 次 · {{ timestamp(attempt.startedAt) }} · {{ state(attempt.outcome) }}<p v-if="attempt.error" class="mt-1 break-words text-error">{{ attempt.error }}</p></li></ol></div>
          </li>
        </ol>
        <UPagination v-if="historyResult && historyResult.total > 10" :page="historyPage" :total="historyResult.total" :items-per-page="10" size="sm" class="mt-4" @update:page="loadHistory" />
      </template>
    </UModal>
    <UModal v-model:open="taskHistoryOpen" title="同步任务记录" description="整个资源空间的同步任务、操作者与逐项结果。" :ui="{ content: 'max-w-2xl' }">
      <template #body>
        <template v-if="taskDetail">
          <UButton label="返回任务记录" icon="i-tabler-arrow-left" color="neutral" variant="ghost" size="sm" class="mb-3" @click="backToTasks" /><p class="mb-3 text-sm font-medium">{{ modeLabel(taskDetail.mode) }} · {{ timestamp(taskDetail.startedAt) }}</p>
          <p v-if="taskItemsLoading" class="text-sm text-muted" role="status">正在读取对象结果…</p><div v-else-if="taskItemsFailure" role="alert"><p class="text-sm text-error">{{ taskItemsFailure }}</p><UButton label="重新读取结果" variant="ghost" @click="loadTaskItems(taskDetail, taskItemsPage)" /></div><p v-else-if="!taskItems?.items.length" class="text-sm text-muted">本次没有需要处理的对象。</p>
          <ol v-else class="divide-y divide-default"><li v-for="item in taskItems.items" :key="key(item)" class="py-3"><div class="flex min-w-0 items-start justify-between gap-3"><span class="min-w-0 break-words text-sm">{{ item.label || item.refId }}</span><UBadge :color="item.status === 'failed' ? 'error' : item.status === 'succeeded' || item.status === 'skipped' ? 'success' : 'warning'" variant="subtle">{{ ({ pending: '等待处理', submitted: '同步中', succeeded: '成功', failed: '失败', skipped: '已是最新' } as Record<string, string>)[item.status] }}</UBadge></div><p class="mt-1 break-all text-xs text-muted">{{ adapter.kindLabels?.[item.refType] || item.refType }} · {{ item.refId }}</p><p v-if="item.lastError" class="mt-1 text-xs text-error">{{ item.lastError }}</p></li></ol>
          <CollectionPagination v-if="taskItems && taskItems.total > 10" :model-value="taskItemsPage" :total-pages="Math.ceil(taskItems.total / 10)" :disabled="taskItemsLoading" size="sm" class="mt-4" @update:model-value="loadTaskItems(taskDetail, $event)" />
        </template>
        <template v-else>
          <p v-if="taskHistoryLoading" role="status" class="text-sm text-muted">正在读取任务记录…</p><div v-else-if="taskHistoryFailure" role="alert"><p class="text-sm text-error">{{ taskHistoryFailure }}</p><UButton label="重新读取记录" variant="ghost" @click="loadTaskHistory()" /></div><p v-else-if="!taskHistory?.items.length" class="text-sm text-muted">尚无手动同步任务。</p>
          <ol v-else class="divide-y divide-default"><li v-for="run in taskHistory.items" :key="run.id" class="py-4 first:pt-0"><div class="flex flex-wrap items-center justify-between gap-2"><p class="text-sm font-medium">{{ modeLabel(run.mode) }}</p><UBadge :color="run.status === 'running' ? 'warning' : run.status === 'succeeded' ? 'success' : 'error'" variant="subtle">{{ runState(run) }}</UBadge></div><p class="mt-2 text-xs text-muted">{{ timestamp(run.startedAt) }} · 已完成 {{ completed(run) }}/{{ run.total }} · 成功 {{ run.succeeded }} · 失败 {{ run.failed }}<span v-if="run.skipped"> · 已是最新 {{ run.skipped }}</span></p><p class="mt-1 break-all text-xs text-muted">操作人：{{ run.actor }}</p><p v-if="run.lastError" class="mt-1 text-xs text-error">{{ run.lastError }}</p><UButton label="对象结果" color="neutral" variant="ghost" size="sm" class="mt-2" @click="loadTaskItems(run)" /></li></ol>
          <CollectionPagination v-if="taskHistory && taskHistory.total > 10" :model-value="taskHistoryPage" :total-pages="Math.ceil(taskHistory.total / 10)" :disabled="taskHistoryLoading" size="sm" class="mt-4" @update:model-value="loadTaskHistory" />
        </template>
      </template>
    </UModal>
  </div>
</template>

<style scoped>
.reference-row { display: grid; min-width: 0; grid-template-columns: minmax(0, 1fr) auto; column-gap: 1rem; row-gap: 0.5rem; align-items: center; }
.reference-wide { display: none; }
.reference-identity { grid-column: 1; }
.reference-state { grid-column: 2; grid-row: 1; justify-self: end; white-space: nowrap; }
.reference-source { grid-column: 1 / -1; grid-row: 2; padding-right: 2.75rem; }
.reference-synced { grid-column: 1 / -1; grid-row: 3; padding-right: 2.75rem; }
.reference-actions { grid-column: 2; grid-row: 2 / 4; }
.reference-time { margin-left: 0.375rem; }
@container collection (min-width: 44rem) {
  .reference-row, .reference-columns { display: grid; grid-template-columns: minmax(0, 2.6fr) minmax(0, 0.65fr) minmax(0, 1fr) minmax(0, 1.25fr) minmax(0, 1.25fr) 2.25rem; column-gap: 1rem; }
  .reference-wide { display: block; }
  .reference-compact { display: none; }
  .reference-identity, .reference-state, .reference-source, .reference-synced, .reference-actions { grid-column: auto; grid-row: auto; }
  .reference-source, .reference-synced { padding-right: 0; }
  .reference-state { justify-self: start; }
  .reference-date { display: block; color: var(--ui-text); }
  .reference-time { display: block; margin: 0.25rem 0 0; }
}
@container collection (min-width: 64rem) {
  .reference-row, .reference-columns { column-gap: 1.5rem; }
}
</style>
