<script setup lang="ts">
const props = defineProps<{ active: number; total: number; disabled?: boolean }>()
const emit = defineEmits<{ change: [index: number] }>()
function change(index: number) {
  if (!props.disabled && index >= 0 && index < props.total) emit('change', index)
}
</script>

<template>
  <div class="flex shrink-0 items-center gap-2" aria-label="图片切换" data-image-navigation>
    <UButton icon="i-tabler-chevron-left" aria-label="上一张" color="neutral" variant="soft" size="sm" square class="size-8 justify-center" :ui="{ leadingIcon: 'size-4' }" :disabled="disabled || active === 0" @click="change(active - 1)" />
    <span class="min-w-10 text-center text-xs tabular-nums text-muted" role="status" aria-live="polite" aria-atomic="true" data-image-position>{{ total ? active + 1 : 0 }} / {{ total }}</span>
    <UButton icon="i-tabler-chevron-right" aria-label="下一张" color="neutral" variant="soft" size="sm" square class="size-8 justify-center" :ui="{ leadingIcon: 'size-4' }" :disabled="disabled || active >= total - 1" @click="change(active + 1)" />
  </div>
</template>
