<script setup lang="ts">
import { computed } from 'vue';
import type { AssetReferenceStatusPage } from '../references';
const props = withDefaults(defineProps<{ result?: AssetReferenceStatusPage | null; failedToLoad?: boolean; canRetry?: boolean; showCount?: boolean }>(), { showCount: true });
defineEmits<{ history: [] }>();
const waiting = computed(() => Math.max(0, (props.result?.pending ?? 0) - (props.result?.failed ?? 0)));
</script>

<template>
  <div class="flex min-w-0 flex-wrap items-center gap-x-4 gap-y-2">
    <div class="flex min-w-0 flex-wrap items-center gap-x-3 gap-y-1 text-sm" aria-live="polite">
      <template v-if="result">
        <span v-if="showCount" class="font-medium">{{ result.registered }} 个对象</span>
        <span v-if="result.registered && !result.pending" class="inline-flex items-center gap-1.5 text-muted"><UIcon name="i-tabler-circle-check" class="size-4 shrink-0 text-success" />全部已同步</span>
        <span v-if="waiting" class="text-warning">{{ waiting }} 项待同步</span><span v-if="result.failed" class="text-error">{{ result.failed }} 项失败</span>
      </template>
      <span v-else class="text-muted">{{ failedToLoad ? '状态暂不可用' : '正在读取状态…' }}</span>
    </div>
    <div class="ml-auto flex items-center gap-1">
      <UButton label="任务记录" icon="i-tabler-history" color="neutral" variant="ghost" size="sm" @click="$emit('history')" />
      <UPopover :content="{ align: 'end' }"><UButton aria-label="同步说明" icon="i-tabler-help-circle" color="neutral" variant="ghost" size="sm" />
        <template #content><div class="w-72 max-w-[calc(100vw-2rem)] space-y-3 p-4 text-sm"><p class="font-medium">同步说明</p><p class="text-muted">保存内容后自动同步。“刷新状态”仅查询结果。</p><p v-if="canRetry" class="text-muted">两种同步操作均作用于整个资源空间，不受搜索、筛选和分页影响。“同步未同步对象”处理未完成项，正在执行的任务继续使用；“强制同步全部对象”重新投递全部已登记引用，包括已同步项。</p><p class="text-muted">任务在后台分批执行，关闭页面仍会继续。进度及逐项结果保留在“任务记录”。</p></div></template>
      </UPopover>
    </div>
  </div>
</template>
