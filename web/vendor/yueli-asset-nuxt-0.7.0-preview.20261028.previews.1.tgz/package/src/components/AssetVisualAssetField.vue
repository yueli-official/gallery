<script setup lang="ts">
import { computed, nextTick, ref } from 'vue'
import { VisualAssetField } from '@yueli/ui/admin'
import type { AdminIconGroup, AdminIconOption } from '@yueli/ui/admin'
import AssetImageWorkbench from './AssetImageWorkbench.vue'
import { validateImageConstraints, type AssetImageConstraints } from '../image-constraints'
import type { AssetRegistrationResponse } from '../registration'
import { useAssetRuntimeApi } from '../../app/utils/api'

const props = withDefaults(defineProps<{
  icon?: string
  imageUrl?: string
  previewUrl?: string
  file?: File | null
  title?: string
  description?: string
  name?: string
  iconLabel?: string
  imageLabel?: string
  showIcon?: boolean
  showImage?: boolean
  imageRequired?: boolean
  error?: string
  disabled?: boolean
  readonly?: boolean
  uploading?: boolean
  progress?: number
  imageOptions?: AssetImageConstraints
  imageSpec?: string
  profileKey?: string
  iconOptions?: readonly AdminIconOption[]
  iconGroups?: readonly AdminIconGroup[]
}>(), {
  icon: '', imageUrl: '', previewUrl: '', file: null, title: '视觉资产',
  description: '', iconLabel: '图标', imageLabel: '封面', showIcon: true, showImage: true,
  imageRequired: false, error: '', disabled: false, readonly: false,
  uploading: false, progress: undefined, imageOptions: () => ({}), imageSpec: '',
  profileKey: undefined, iconOptions: () => [], iconGroups: () => [],
})
const emit = defineEmits<{
  'update:icon': [value: string]
  processed: [file: File]
  'clear-image': []
  processing: [value: boolean]
}>()
const api = useAssetRuntimeApi('asset')
const workbenchOpen = ref(false)
const preparing = ref(false)
const processing = ref(false)
const localError = ref('')
const validated = ref(false)
const rules = ref<AssetImageConstraints>({})
const workbench = ref<InstanceType<typeof AssetImageWorkbench>>()
const visibleUrl = computed(() => props.previewUrl || props.imageUrl)
const fieldError = computed(() => props.error || localError.value || (validated.value && props.imageRequired && !visibleUrl.value ? `请选择${props.imageLabel}` : ''))
const busy = computed(() => preparing.value || processing.value || props.uploading)

function validate() {
  validated.value = true
  return !fieldError.value
}

async function pick(edit = false) {
  if (props.disabled || props.readonly || busy.value) return
  preparing.value = true
  localError.value = ''
  emit('processing', true)
  try {
    const next = { ...props.imageOptions }
    validateImageConstraints(next)
    if (props.profileKey) {
      const response = await api.call<AssetRegistrationResponse>('/api/v1/assets/registration')
      const profile = response.state.registration?.effective.profiles.find(item => item.key === props.profileKey)
      if (!profile) throw new Error('当前图片用途尚未获得有效资源策略，请检查资源设置')
      if (!profile.allowedMimes.includes(next.outputType || 'image/webp')) throw new Error('输出格式不符合当前资源策略，请调整图片配置')
      next.maxBytes = Math.min(next.maxBytes ?? profile.maxBytes, profile.maxBytes)
    }
    rules.value = next
    workbenchOpen.value = true
    await nextTick()
    if (edit && props.file) await workbench.value?.add([props.file])
  } catch (error) {
    localError.value = error instanceof Error ? error.message : '图片工具暂时无法打开，请重试'
  } finally {
    preparing.value = false
    emit('processing', processing.value)
  }
}

function processed(files: File[]) {
  if (!files[0]) return
  localError.value = ''
  emit('processed', files[0])
}

function onProcessingProgress(value: { pending: boolean }) {
  processing.value = value.pending
  emit('processing', value.pending)
}

function clear() {
  localError.value = ''
  emit('clear-image')
}
defineExpose({ validate })
</script>

<template>
  <VisualAssetField :icon="icon" :image-url="visibleUrl" :title="title" :description="description" :name="name"
    :icon-label="iconLabel" :image-label="imageLabel" :show-icon="showIcon" :show-image="showImage"
    :required="imageRequired" :error="fieldError" :disabled="disabled" :readonly="readonly" :busy="busy"
    :progress="uploading ? progress : undefined" :image-aspect-ratio="imageOptions.fixedOutputSize ? imageOptions.fixedOutputSize.width / imageOptions.fixedOutputSize.height : imageOptions.aspectRatio || 1" :image-spec="imageSpec"
    :icon-options="iconOptions" :icon-groups="iconGroups" @update:icon="emit('update:icon', $event)"
    @pick-image="pick()" @clear-image="clear">
    <template v-if="$slots['icon-filters']" #icon-filters="scope"><slot name="icon-filters" v-bind="scope" /></template>
    <template #image-actions>
      <UButton v-if="file && !readonly" label="编辑图片" icon="i-tabler-crop" size="sm" color="neutral" variant="ghost" :disabled="disabled || busy" @click="pick(true)" />
    </template>
  </VisualAssetField>
  <AssetImageWorkbench ref="workbench" v-model:open="workbenchOpen" :max-files="1" :constraints="rules"
    confirm-label="使用图片" @processed="processed" @progress="onProcessingProgress" />
</template>
