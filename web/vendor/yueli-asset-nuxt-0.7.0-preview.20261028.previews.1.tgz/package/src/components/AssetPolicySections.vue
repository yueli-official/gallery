<script setup lang="ts">
import { computed, ref } from 'vue';
import { TabbedSurface } from '@yueli/ui/admin';
import type { AssetReferenceSyncAdapter } from '../references';
import AssetReferenceStatus from './AssetReferenceStatus.vue';
import AssetReferenceSummary from './AssetReferenceSummary.vue';
import AssetPreviewPreparation from './AssetPreviewPreparation.vue';

const props = defineProps<{ referenceSync?: AssetReferenceSyncAdapter; canEdit?: boolean; hasPreviews?: boolean }>();
const emit = defineEmits<{ previewsReady: [] }>();
const section = ref('purposes');
const status = ref<InstanceType<typeof AssetReferenceStatus> | null>(null);
const sections = computed(() => [
  { value: 'purposes', label: '用途', icon: 'i-tabler-adjustments' },
  ...(props.referenceSync ? [{ value: 'references', label: '资源引用', icon: 'i-tabler-link', badge: status.value?.result?.registered }] : []),
  ...(props.hasPreviews ? [{ value: 'previews', label: '预览图', icon: 'i-tabler-photo' }] : []),
]);
</script>

<template>
  <TabbedSurface v-if="referenceSync || hasPreviews" v-model="section" :items="sections" navigation-label="资源策略分区">
    <template v-if="section === 'references'" #actions>
      <AssetReferenceSummary :result="status?.result" :failed-to-load="!!status?.failure" :can-retry="canEdit" :show-count="false" @history="status?.openTaskHistory()" />
    </template>
    <div v-show="section === 'purposes'"><slot /></div>
    <AssetReferenceStatus v-if="referenceSync" ref="status" v-show="section === 'references'" :active="section === 'references'" :adapter="referenceSync" :can-retry="canEdit" :show-header="false" embedded />
    <AssetPreviewPreparation v-if="hasPreviews" v-show="section === 'previews'" :active="section === 'previews'" :can-edit="canEdit" @ready="emit('previewsReady')" />
  </TabbedSurface>
  <section v-else class="yueli-card"><slot /></section>
</template>
