<script setup lang="ts">
import UModal from '@nuxt/ui/components/Modal.vue'
defineOptions({ inheritAttrs: false })
defineProps<{ embedded?: boolean }>()
</script>
<template>
  <div v-if="embedded"><slot name="body" /></div>
  <UModal v-else v-bind="$attrs" :dismissible="false">
    <template v-if="$slots.header" #header><slot name="header" /></template>
    <template #body><slot name="body" /></template>
    <template #footer><slot name="footer" /></template>
  </UModal>
</template>
