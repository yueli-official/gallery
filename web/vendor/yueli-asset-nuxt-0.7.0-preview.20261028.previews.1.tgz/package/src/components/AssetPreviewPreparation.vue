<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { useAssetRuntimeApi } from '../../app/utils/api';

const props = defineProps<{ active: boolean; canEdit?: boolean }>();
const emit = defineEmits<{ ready: [] }>();
interface PreviewRun {
  id: string; status: string; revision: number; activatesPolicy: boolean;
  total: number; prepared: number; failed: number;
  failures: { assetId: string; code: string }[];
  createdAt: string; finishedAt?: string; errorCode?: string;
}
const { call } = useAssetRuntimeApi('asset');
const runs = ref<PreviewRun[]>([]);
const page = ref(1);
const total = ref(0);
const loading = ref(false);
const busy = ref('');
const error = ref('');
let timer: ReturnType<typeof setTimeout> | undefined;
let disposed = false;
const running = computed(() => runs.value.some(run => ['queued', 'running', 'retrying'].includes(run.status)));
const labels: Record<string,string> = { queued:'等待生成', running:'正在生成', retrying:'正在重试', succeeded:'已完成', failed:'生成失败', paused:'已暂停', cancelled:'已取消' };

async function load(quiet = false) {
  if (loading.value || disposed) return;
  loading.value = true;
  if (!quiet) error.value = '';
  try {
    const response = await call<{ items: PreviewRun[]; total: number }>('/api/v1/assets/previews', { query: { page: page.value, size: 10 } });
    const finished = response.items.some(next => next.activatesPolicy && next.status === 'succeeded' && runs.value.some(old => old.id === next.id && old.status !== 'succeeded'));
    runs.value = response.items; total.value = response.total;
    if (finished) emit('ready');
  } catch { error.value = '预览生成记录加载失败，请重试。'; }
  finally {
    loading.value = false;
    clearTimeout(timer);
    if (!disposed && props.active && running.value) timer = setTimeout(() => load(true), 2000);
  }
}

async function start(id?: string) {
  if (busy.value) return;
  busy.value = id || 'new'; error.value = '';
  try {
    await call<PreviewRun>(id ? `/api/v1/assets/previews/${encodeURIComponent(id)}/retry` : '/api/v1/assets/previews', { method:'POST' });
    page.value = 1;
    await load();
  } catch { error.value = id ? '未能重试生成，请刷新记录后再试。' : '未能开始生成，请刷新记录后再试。'; }
  finally { busy.value = ''; }
}

watch(() => props.active, active => { clearTimeout(timer); if (active) void load(); });
watch(page, () => { if (props.active) void load(); });
onMounted(() => { if (props.active) void load(); });
onBeforeUnmount(() => { disposed = true; clearTimeout(timer); });
</script>

<template>
  <section class="space-y-4 p-4 sm:p-5" aria-label="预览图生成">
    <div class="flex flex-wrap items-start justify-between gap-3">
      <div class="min-w-0">
        <h2 class="text-sm font-semibold text-highlighted">预览图</h2>
        <p class="mt-1 text-xs text-muted">生成本资源空间全部图片的预览图，已就绪的预览会保留。关闭页面后任务继续。</p>
      </div>
      <div class="flex shrink-0 items-center gap-2">
        <UButton label="刷新" icon="i-tabler-refresh" color="neutral" variant="ghost" size="sm" :loading="loading" @click="load()" />
        <UButton v-if="canEdit" :label="running ? '生成中' : '生成全部预览图'" icon="i-tabler-photo-cog" size="sm" :loading="busy === 'new'" :disabled="running || !!busy" @click="start()" />
      </div>
    </div>
    <UAlert v-if="error" color="error" variant="subtle" :title="error" />
    <USkeleton v-if="loading && !runs.length" class="h-24 w-full" />
    <p v-else-if="!runs.length && !error" class="py-6 text-center text-sm text-muted">暂无生成任务。新上传的图片会自动准备预览图。</p>
    <div v-else class="divide-y divide-default">
      <article v-for="run in runs" :key="run.id" class="space-y-2 py-3">
        <div class="flex flex-wrap items-center justify-between gap-2">
          <div class="flex flex-wrap items-center gap-2">
            <span class="text-sm font-medium">{{ run.activatesPolicy ? '更新预览图' : '生成预览图' }}</span>
            <UBadge :label="labels[run.status] || '状态待确认'" :color="run.status === 'failed' ? 'error' : run.status === 'succeeded' ? 'success' : 'neutral'" variant="subtle" size="sm" />
          </div>
          <UButton v-if="canEdit && run.status === 'failed'" label="重试未完成项" color="neutral" variant="soft" size="xs" :loading="busy === run.id" :disabled="!!busy" @click="start(run.id)" />
        </div>
        <p class="text-xs text-muted" role="status">已准备 {{ run.prepared }} / {{ run.total }} 张<span v-if="run.failed"> · {{ run.failed }} 张失败</span></p>
        <UProgress v-if="['queued','running','retrying'].includes(run.status)" :model-value="run.total ? Math.round((run.prepared + run.failed) / run.total * 100) : 0" size="xs" />
        <p v-if="run.activatesPolicy && run.status !== 'succeeded'" class="text-xs text-muted">全部预览就绪后，新设置才会生效。</p>
        <details v-if="run.failures.length" class="text-xs text-muted">
          <summary class="cursor-pointer">查看失败图片<span v-if="run.failed > run.failures.length">（前 {{ run.failures.length }} 项）</span></summary>
          <ul class="mt-2 space-y-1"><li v-for="failure in run.failures" :key="failure.assetId" class="break-all">{{ failure.assetId }} · 预览生成失败</li></ul>
        </details>
        <p class="text-xs text-dimmed">{{ new Date(run.createdAt).toLocaleString() }}</p>
      </article>
    </div>
    <UPagination v-if="total > 10" v-model:page="page" :total="total" :items-per-page="10" size="sm" />
  </section>
</template>
