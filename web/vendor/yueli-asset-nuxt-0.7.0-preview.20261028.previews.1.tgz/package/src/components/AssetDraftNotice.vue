<script setup lang="ts">
defineProps<{ expiresAt?: string; resetRequired?: boolean; disabled?: boolean }>();
defineEmits<{ restart: [] }>();
</script>

<template>
  <div v-if="expiresAt || resetRequired" class="flex min-w-0 flex-wrap items-center gap-2 text-xs" :class="resetRequired ? 'text-warning' : 'text-muted'" role="status">
    <UIcon :name="resetRequired ? 'i-tabler-clock-exclamation' : 'i-tabler-shield-check'" class="size-4 shrink-0" />
    <span v-if="resetRequired">临时会话已失效。重新开始后，请重新选择未保存的图片或文件。</span>
    <span v-else>未保存的素材暂存至 {{ new Date(expiresAt!).toLocaleString() }}，保存后由内容引用保护。</span>
    <UButton v-if="resetRequired" label="重新开始" color="neutral" variant="outline" size="xs" :disabled="disabled" @click="$emit('restart')" />
  </div>
</template>
