<script setup lang="ts">
defineProps<{ editing: boolean; status: string; ready?: boolean }>();
defineEmits<{ edit: []; cancel: []; save: [] }>();
</script>

<template>
  <div class="flex flex-wrap items-center justify-end gap-2">
    <template v-if="editing">
      <UButton label="取消" color="neutral" variant="ghost" :disabled="status === 'saving'" @click="$emit('cancel')" />
      <UButton data-asset-registration-save icon="i-tabler-device-floppy" :label="status === 'saving' ? '保存中' : '保存'" :loading="status === 'saving'" @click="$emit('save')" />
    </template>
    <UButton v-else data-asset-registration-edit :label="status === 'saved' ? '已保存' : status === 'preparing' ? '预览图准备中' : status === 'submitted' ? '已提交申请' : '编辑策略'" :icon="status === 'saved' ? 'i-tabler-check' : 'i-tabler-adjustments'" :disabled="!ready" @click="$emit('edit')" />
  </div>
</template>
