<script setup lang="ts">
import type { AssetVariantSlotDefinition } from "../registration";
import AssetRegistrationSummary from "./AssetRegistrationSummary.client.vue";
import AssetPolicyActions from './AssetPolicyActions.vue';
import { ref } from 'vue';
import type { AssetReferenceSyncAdapter } from '../references';

withDefaults(
  defineProps<{
    expectedNamespace: string;
    profileOrder?: string[];
    canEdit?: boolean;
    variantSlots?: AssetVariantSlotDefinition[];
    id?: string;
    title?: string;
    icon?: string;
    referenceSync?: AssetReferenceSyncAdapter;
  }>(),
  {
    profileOrder: () => [],
    canEdit: false,
    variantSlots: () => [],
    id: "assets",
    title: "资源策略",
    icon: "i-tabler-database-cog",
  },
);
const summary = ref<InstanceType<typeof AssetRegistrationSummary> | null>(null);
</script>

<template>
  <YManagePage :id="id" :title="title" :icon="icon">
    <template #subtitle>管理资源用途与引用同步</template>
    <template v-if="canEdit" #actions>
      <AssetPolicyActions :editing="summary?.editing ?? false" :status="summary?.saveStatus ?? 'idle'" :ready="summary?.ready" @edit="summary?.beginEdit()" @cancel="summary?.cancelEdit()" @save="summary?.save()" />
    </template>
    <ClientOnly>
      <AssetRegistrationSummary
        ref="summary"
        hide-actions
        :expected-namespace="expectedNamespace"
        :profile-order="profileOrder"
        :can-edit="canEdit"
        :variant-slots="variantSlots"
        :reference-sync="referenceSync"
      />
      <template #fallback>
        <div class="space-y-3" aria-label="正在加载资源策略">
          <USkeleton class="h-28 w-full rounded-xl" />
          <USkeleton class="h-56 w-full rounded-xl" />
        </div>
      </template>
    </ClientOnly>
  </YManagePage>
</template>
