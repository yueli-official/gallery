export interface AssetDraftSession {
  id: string;
  state: 'active' | 'sealed' | 'committed' | 'cancelled';
  expiresAt: string;
}

export interface AssetDraftAsset { assetId?: string; mediaKey?: string }

export type AssetReferenceRequest = <T>(path: string, options: {
  method: 'POST' | 'PUT'; body: Record<string, unknown>;
}) => Promise<T>;

export interface AssetReferenceOwnerStatus {
  refType: string; refId: string; label: string; url: string;
  version: number; appliedVersion: number; jobId: string; status: string;
  lastError: string; attempt: number; updatedAt: string;
  sourceUpdatedAt?: string; syncedAt?: string; requestedAt?: string; referenceCount: number;
}
export interface AssetReferenceStatusPage {
  items: AssetReferenceOwnerStatus[]; total: number; pending: number; registered: number; failed: number; page: number; size: number;
  initializations: { id: string; actor: string; status: string; owners: number; cleared: number; lastError: string; startedAt: string; finishedAt?: string }[];
}
export interface AssetReferenceAttempt {
  number: number; outcome: string; error?: string; startedAt: string; finishedAt?: string;
}
export interface AssetReferenceSyncAdapter {
  kindLabels?: Record<string, string>;
  /** Resolve the consumer's declared HTTP failures; never expose raw exceptions. */
  describeError: (error: unknown) => string;
  list: (query: AssetReferenceQuery) => Promise<AssetReferenceStatusPage>;
  history: (owner: AssetReferenceOwnerStatus, page: number, size: number) => Promise<AssetReferenceHistoryPage>;
  attempts: (owner: AssetReferenceOwnerStatus, jobId: string) => Promise<AssetReferenceAttempt[]>;
  sync: (owner: AssetReferenceOwnerStatus) => Promise<AssetReferenceOperation>;
  retry: (owner: AssetReferenceOwnerStatus) => Promise<AssetReferenceOperation>;
  startSync: (mode: AssetReferenceSyncMode) => Promise<AssetReferenceSyncRun>;
  syncRuns: (page: number, size: number) => Promise<AssetReferenceSyncRunPage>;
  syncRunItems: (runId: string, page: number, size: number) => Promise<AssetReferenceSyncRunItemPage>;
}
export type AssetReferenceSyncMode = 'pending' | 'force';
export interface AssetReferenceSyncRun {
  id: string; mode: AssetReferenceSyncMode; actor: string; status: string;
  total: number; prepared: number; queued: number; succeeded: number; failed: number; skipped: number;
  lastError: string; startedAt: string; finishedAt?: string;
}
export interface AssetReferenceSyncRunPage { items: AssetReferenceSyncRun[]; total: number; page: number; size: number }
export interface AssetReferenceSyncRunItem {
  refType: string; refId: string; label: string; status: string; version: number; jobId: string; lastError: string;
}
export interface AssetReferenceSyncRunItemPage { items: AssetReferenceSyncRunItem[]; total: number; page: number; size: number }
export interface AssetReferenceQuery {
  page: number; size: number; search?: string; refType?: string; status?: string; hasAssets?: string;
  sourceAfter?: string; sourceBefore?: string; syncedAfter?: string; syncedBefore?: string;
}
export interface AssetReferenceOperation { id: string; status: string; version: number }

export type AssetReferenceManagementRequest = <T>(path: string, options?: {
  method?: 'GET' | 'POST'; query?: Record<string, string | number | undefined>; body?: Record<string, unknown>;
}) => Promise<T>;

/** Shared wire adapter. Products retain authorization, their request client,
 * object vocabulary and declared failure messages; page behavior stays here. */
export function createAssetReferenceSyncAdapter(request: AssetReferenceManagementRequest, options: {
  kindLabels: Record<string, string>;
  describeError: (error: unknown) => string;
  basePath?: string;
}): AssetReferenceSyncAdapter {
  const base = options.basePath ?? '/api/v1/manage/asset-references';
  return {
    kindLabels: options.kindLabels,
    describeError: options.describeError,
    list: query => request<AssetReferenceStatusPage>(base, { query: { ...query } }),
    history: (owner, page, size) => request<AssetReferenceHistoryPage>(`${base}/history`, { query: { refType: owner.refType, refId: owner.refId, page, size } }),
    attempts: async (owner, jobId) => (await request<{ items: AssetReferenceAttempt[] }>(`${base}/attempts`, { query: { refType: owner.refType, refId: owner.refId, jobId } })).items,
    sync: owner => request<AssetReferenceOperation>(`${base}/sync`, { method: 'POST', body: { refType: owner.refType, refId: owner.refId } }),
    retry: owner => request<AssetReferenceOperation>(`${base}/retry`, { method: 'POST', body: { refType: owner.refType, refId: owner.refId } }),
    startSync: mode => request<AssetReferenceSyncRun>(`${base}/sync-runs`, { method: 'POST', body: { mode } }),
    syncRuns: (page, size) => request<AssetReferenceSyncRunPage>(`${base}/sync-runs`, { query: { page, size } }),
    syncRunItems: (runId, page, size) => request<AssetReferenceSyncRunItemPage>(`${base}/sync-runs/items`, { query: { runId, page, size } }),
  };
}
export interface AssetReferenceDelivery {
  id: string; version: number; origin: string; actor: string; status: string; attempt: number; lastError: string;
  requestedAt: string; startedAt?: string; finishedAt?: string;
}
export interface AssetReferenceHistoryPage { items: AssetReferenceDelivery[]; total: number; page: number; size: number }

/** Temporary ownership is independent of a business ID. Use per-tab storage
 * for an editor instance; never cancel from beforeunload or delete the asset.
 * Finalize must receive draftSessionId, so recording the file and protection
 * is atomic in Asset, including deduplicated uploads.
 */
export class AssetDraftSessionResetRequired extends Error {
  constructor(readonly reason: 'expired' | 'invalid') { super(`asset.draft.${reason}`); }
}

export function createAssetDraftSession(request: AssetReferenceRequest, storageKey: string, options: { lifetimeSeconds?: number; storage?: 'tab' | 'memory' } = {}) {
  let session: AssetDraftSession | null = null;
  let pending: Promise<AssetDraftSession> | null = null;
  const key = `asset:draft:${storageKey}`;

  async function ensure(): Promise<AssetDraftSession> {
    if (pending) return pending;
    pending = (async () => {
      const persisted = options.storage === 'memory' ? (session ? JSON.stringify(session) : null) : sessionStorage.getItem(key);
      let saved: AssetDraftSession | null = null;
      if (persisted) {
        try { saved = JSON.parse(persisted) as AssetDraftSession; }
        catch { throw new AssetDraftSessionResetRequired('invalid'); }
        if (!saved || typeof saved.id !== 'string' || !saved.id || !Number.isFinite(Date.parse(saved.expiresAt))) throw new AssetDraftSessionResetRequired('invalid');
        if (Date.parse(saved.expiresAt) <= Date.now()) throw new AssetDraftSessionResetRequired('expired');
      }
      const next = await request<AssetDraftSession>('/api/v1/asset-references/drafts', {
        method: 'POST', body: { ...(saved ? { sessionId: saved.id } : {}), ...(options.lifetimeSeconds ? { lifetimeSeconds: options.lifetimeSeconds } : {}) },
      });
      session = next;
      if (options.storage !== 'memory') sessionStorage.setItem(key, JSON.stringify(next));
      return next;
    })();
    try { return await pending; } finally { pending = null; }
  }

  async function cancel() {
    if (!session) return;
    await request('/api/v1/asset-references/drafts/cancel', {
      method: 'POST', body: { sessionId: session.id },
    });
    session = null;
    if (options.storage !== 'memory') sessionStorage.removeItem(key);
  }

  async function hold(assets: AssetDraftAsset[]) {
    const active = await ensure();
    const next = await request<AssetDraftSession>('/api/v1/asset-references/drafts/holds', {
      method: 'PUT', body: { sessionId: active.id, assets },
    });
    session = next;
    if (options.storage !== 'memory') sessionStorage.setItem(key, JSON.stringify(next));
    return next;
  }

  function restart() {
    if (pending) throw new Error('asset.draft.operation_in_progress');
    session = null;
    if (options.storage !== 'memory') sessionStorage.removeItem(key);
  }

  return { ensure, hold, cancel, restart, current: () => session };
}

/** Reactive editor state around the same session protocol. Reset remains an
 * explicit user operation; this never retries expired drafts automatically. */
export function useAssetDraftSession(request: AssetReferenceRequest, storageKey: string, options: { lifetimeSeconds?: number; storage?: 'tab' | 'memory' } = {}) {
  const manager = createAssetDraftSession(request, storageKey, options);
  const session = ref<AssetDraftSession | null>(null);
  const resetRequired = ref(false);
  async function track(operation: () => Promise<AssetDraftSession>) {
    try { const next = await operation(); session.value = next; resetRequired.value = false; return next; }
    catch (error) { if (error instanceof AssetDraftSessionResetRequired) resetRequired.value = true; throw error; }
  }
  return {
    session, resetRequired, expiresAt: computed(() => session.value?.expiresAt),
    ensure: () => track(() => manager.ensure()),
    hold: (assets: AssetDraftAsset[]) => track(() => manager.hold(assets)),
    async cancel() { await manager.cancel(); session.value = null; resetRequired.value = false; },
    restart() { manager.restart(); session.value = null; resetRequired.value = false; },
  };
}
import { computed, ref } from 'vue';
