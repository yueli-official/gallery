/// <reference lib="webworker" />
export {}
let queue=Promise.resolve()
self.onmessage=(event:MessageEvent<{id:number;file:File;side:number}>)=>{
 const {id,file,side}=event.data
 queue=queue.then(async()=>{
  let bitmap:ImageBitmap|undefined
  try{
   bitmap=await createImageBitmap(file,{imageOrientation:'from-image'})
   const width=bitmap.width,height=bitmap.height,k=Math.min(1,side/width,side/height)
   const editorScale=Math.min(1,1536/width,1536/height)
   const canvas=new OffscreenCanvas(Math.max(1,Math.round(width*editorScale)),Math.max(1,Math.round(height*editorScale)))
   const ctx=canvas.getContext('2d')
   if(!ctx)throw new Error('图片预览不可用')
   ctx.drawImage(bitmap,0,0,canvas.width,canvas.height)
   bitmap.close()
   bitmap=undefined
   let transparent=false
   if(file.type!=='image/jpeg'){const pixels=ctx.getImageData(0,0,canvas.width,canvas.height).data;for(let i=3;i<pixels.length;i+=4)if(pixels[i]!==255){transparent=true;break}}
   const editBlob=await canvas.convertToBlob({type:transparent?'image/png':'image/jpeg',quality:.78})
   if(side>256){self.postMessage({id,blob:editBlob,width,height,previewWidth:canvas.width,previewHeight:canvas.height});return}
   const thumbnail=new OffscreenCanvas(Math.max(1,Math.round(width*k)),Math.max(1,Math.round(height*k)))
   thumbnail.getContext('2d')!.drawImage(canvas,0,0,thumbnail.width,thumbnail.height)
   const blob=await thumbnail.convertToBlob({type:'image/webp',quality:.78})
   self.postMessage({id,blob,width,height,previewWidth:thumbnail.width,previewHeight:thumbnail.height,editBlob,editWidth:canvas.width,editHeight:canvas.height})
  }catch(error){self.postMessage({id,error:error instanceof Error?error.message:'图片预览失败'})}
  finally{bitmap?.close()}
 })
}
