// Shared asset-plane BFF and typed envelope clients.
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

// Cropper's package main is CommonJS; Vite dev must consume its ESM entry.
const cropperEntry = createRequire(import.meta.url).resolve('cropperjs')
  .replace(/cropper(?:\.common)?\.js$/, 'cropper.esm.js');

export default defineNuxtConfig({
  modules: ['@yueli/ui'],
  css: [fileURLToPath(new URL('./src/tailwind.css', import.meta.url))],
  vite: {
    resolve: { alias: [{ find: /^cropperjs$/, replacement: cropperEntry }] },
    // A source overlay can place this owned dependency outside the app/layer root.
    server: { fs: { allow: [dirname(cropperEntry)] } },
  },
  runtimeConfig: {
    assetBase: "",
    assetAudience: "asset-api",
    identityBase: "",
  },
});
