# 通用视觉资产字段

`AssetVisualAssetField`从`@yueli/asset-nuxt/components`导入，组合Foundation的图标/图片Tabs和现有图片采集工作台。启用Asset Nuxt layer与`@yueli/ui`模块，并在应用根使用`UApp`；不手工导入共享CSS。

## 完整消费示例

下面的`save`由产品注入：负责权限、初始化上传、`assetUploadURL`传输、Finalize、业务引用与保存。返回的`imageUrl`仅供显示，持久化Asset引用或mediaKey。示例不会把临时blob URL写入接口。

```vue
<script setup lang="ts">
import { nextTick, onBeforeUnmount, ref, shallowRef } from 'vue'
import { AssetVisualAssetField } from '@yueli/asset-nuxt/components'
import type { AssetImageConstraints } from '@yueli/asset-nuxt/components'

const props = defineProps<{
  initialIcon: string
  initialImageUrl: string
  profileKey: string
  save: (input: { icon: string; file: File | null; removeImage: boolean }) => Promise<{ imageUrl: string }>
}>()
const field = ref<InstanceType<typeof AssetVisualAssetField>>()
const icon = ref(props.initialIcon)
const imageUrl = ref(props.initialImageUrl)
const file = shallowRef<File | null>(null)
const previewUrl = ref('')
const removeImage = ref(false)
const processing = ref(false)
const saving = ref(false)
const error = ref('')
const options: AssetImageConstraints = {
  fixedOutputSize: { width: 256, height: 256 },
  outputType: 'image/webp',
  allowAnimation: false,
}
function revokePreview() {
  if (previewUrl.value) URL.revokeObjectURL(previewUrl.value)
  previewUrl.value = ''
}
function prepared(value: File) {
  revokePreview()
  file.value = value
  previewUrl.value = URL.createObjectURL(value)
  removeImage.value = false
  error.value = ''
}
function clear() {
  revokePreview()
  file.value = null
  imageUrl.value = ''
  removeImage.value = true
}
async function submit() {
  if (processing.value || saving.value) return
  error.value = ''
  await nextTick()
  if (!field.value?.validate()) return
  saving.value = true
  try {
    const saved = await props.save({ icon: icon.value, file: file.value, removeImage: removeImage.value })
    imageUrl.value = saved.imageUrl
    file.value = null
    removeImage.value = false
    revokePreview()
  } catch {
    error.value = '保存失败，请重试；当前图片草稿已保留。'
  } finally {
    saving.value = false
  }
}
onBeforeUnmount(revokePreview)
</script>

<template>
  <AssetVisualAssetField ref="field" v-model:icon="icon" :image-url="imageUrl"
    :preview-url="previewUrl" :file="file" :profile-key="profileKey" :image-options="options"
    image-required :error="error" :disabled="saving" image-spec="固定256×256px · WebP"
    @processed="prepared" @clear-image="clear" @processing="processing = $event" />
  <UButton label="保存" :loading="saving" :disabled="processing" @click="submit" />
</template>
```

`imageRequired`可省略；否则提交前调用`validate()`，由共享字段显示错误。它检查图片值，不把图标当作图片。选择、编辑和切换Tab都不自动保存；成功处理只发出`processed(File)`。取消工作台保留外部已有值及草稿。

工作台打开后可直接用 Ctrl+V（macOS 为 Command+V）粘贴剪贴板中的图片；上传与编辑页都支持，焦点在标题、正文或底部按钮时均有效。粘贴图片走同一套去重、数量与图片规格校验。普通文本及非图片文件保持原有粘贴行为；关闭工作台后不接管粘贴，也不申请读取剪贴板权限。消费者无需额外绑定事件。

上传区域接受拖放和粘贴；点击其留白、图标或提示不会打开文件选择器。只有“选择图片”按钮会打开选择器，同时支持鼠标、Enter及空格键。可先点击上传区域再粘贴，无需预先点击按钮。

## 图片配置

| `imageOptions`字段 | 含义 |
| --- | --- |
| `fixedOutputSize:{width,height}` | 精确输出正整数宽高，自动锁定裁剪比例；大图缩小，小图/小裁剪区域拒绝放大 |
| `aspectRatio` | 正数宽高比，例如`16 / 9`、`5 / 2`；作为初始比例 |
| `lockAspectRatio` | 锁定配置比例；必须配置比例或固定输出尺寸 |
| `minWidth/minHeight` | 原图、原始像素裁剪区域及最终输出的最低宽高，不是界面预览尺寸 |
| `maxOutputSide` | 最终输出最长边上限，例如4096；等比缩小，不放大 |
| `outputType` | 固定输出`image/webp`、`image/jpeg`或`image/png` |
| `outputQuality` | 固定 WebP/JPEG 编码质量，1–100 的整数；PNG 不使用此参数 |
| `maxBytes` | 可选输出字节上限；`profileKey`提供的有效Profile上限仍生效 |
| `allowAnimation` | 可选保留动画；需要固定裁剪/尺寸等静态约束时拒绝动画，不能绕过规格 |

最长边场景可直接替换示例配置：

```ts
const options: AssetImageConstraints = {
  aspectRatio: 5 / 2,
  lockAspectRatio: true,
  minWidth: 1000,
  minHeight: 400,
  maxOutputSide: 4096,
  outputType: 'image/webp',
}
```

固定输出尺寸与比例/最小尺寸/最长边有矛盾时明确报错，不静默选择某个配置。固定尺寸是精确结果，最长边是上限；不把256px最大边冒充固定256×256。

### 接入前确定规格

使用图片编辑器的产品先写下图片用途、单次处理张数、裁剪比例、输出宽高或最长边、格式、质量、透明度、动画、是否允许放大，以及这些项目中哪些允许用户调整。分类、角色、标签等同一类封面应共用一份规格，不应在不同表单里各自配置不同的比例。把确定的规格传给`imageOptions`，将同样的格式和尺寸要求写到产品服务端的可信媒体元数据校验中，并在字段旁用`imageSpec`说明用户需要准备的图片。质量属于浏览器编码参数，服务端只能复核最终格式、尺寸和字节数。

例如固定方形封面可配置`fixedOutputSize:{width:512,height:512}`、`outputType:'image/webp'`、`outputQuality:95`、`allowAnimation:false`。固定尺寸会锁定 1:1 裁剪，保留 WebP 透明区域；原图或裁剪区域不足 512px 时提示更换或扩大裁剪，不放大像素。

## 字段接口与分类

`icon/imageUrl/previewUrl/file`分别是图标、正式展示地址、本地预览地址和已处理的待上传文件。产品创建/释放自己的blob URL；组件释放工作台内部预览、缓存和Worker。已有远程图片没有提供原始文件时只显示预览/更换，不从缩略图冒充原图重编辑。

`title/description/name/iconLabel/imageLabel/showIcon/showImage/iconOptions/iconGroups`沿用Foundation语义；分类元素是`{value,label,icons}`，省略即只保留搜索。`icon-filters`插槽提供`groups/activeGroup/selectGroup`，可替换分类栏表现，仍使用共享筛选状态。没有业务或站点名称判断。

`error/disabled/readonly/uploading/progress`控制字段状态；`progress`使用0至100，未知进度省略。`processing(boolean)`表示图片准备/导出，产品据此阻止提交不完整文件。`clear-image`只表示清除草稿引用，不能据此直接删除可能被复用的Asset对象。

## 操作流程与失败处理

1. 点击选择/更换图片；配置了`profileKey`时先读取已接受Registration，核对配置输出MIME并收窄有效字节上限。没有有效策略时在字段报错。
2. 工作台支持文件选择、拖拽、粘贴。此字段一次只接受一张；选入后直接进入编辑，选择多张时提示重新选择，已有草稿不会丢失。编辑中可更换图片。
3. 调整裁剪、旋转或允许调整的格式/质量。固定尺寸只显示只读尺寸，锁比例时不能改变比例；固定质量只显示数值。
4. 点击使用图片后按原图像素导出，并再次检查规格。导出错误在工作台显示；正确处理后才发出File，网络上传仍由产品执行。
5. 产品上传/保存失败时保留file和previewUrl供重试；成功后更新正式媒体展示值并释放草稿。取消编辑不清除外部草稿。

浏览器检查不构成服务端授权或业务尺寸强制边界。Asset负责真实格式、字节数及内部安全护栏；产品若强制业务宽高/比例，应在服务端基于可信媒体元数据校验。用户界面不暴露内部总像素护栏。

## 采用与迁移

消费者采用前核对打包版本及Foundation依赖，完成独立制品类型/构建、真实处理/上传、取消重试与主题/宽窄屏验证。不要依赖相邻源码链接或手写产品依赖基线。直接使用`AssetImageWorkbench`的多图场景仍保留上传/编辑页；编辑时默认只修改当前图片，选择两张以上后可用右侧按钮将当前图片的输出参数应用到全部，裁剪位置、旋转与翻转不会复制。

约束响应更新时，固定输出宽高与锁定比例同时约束当前编辑区和导出；已添加图片保留的自由裁剪选项不能覆盖消费者的强制比例。省略强制比例时仍可自由裁剪。
