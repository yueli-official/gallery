# 资源引用管理与临时图片

当前为未发布的源码候选，须使用显式本地联调；旧固定制品不具备本页新增合同。

## 资源策略页接入

`AssetPolicyPage` 接收可选 `referenceSync: AssetReferenceSyncAdapter`。顶部整合注册状态与文件保护，下面使用 Foundation `TabbedSurface` 的“用途 / 资源引用”。不传 Adapter 的消费者只显示用途，不生成空标签。独立使用 `AssetReferenceStatus` 默认自带卡片，嵌入已有卡片设置 `embedded`；可用 `active=false` 暂停任务进度轮询。

页面复用 `YManagePage` 的标题Card和 `#actions`，编辑/取消/保存都在同一页头操作区。注册、资源空间和文件保护使用紧凑信息栏；保护说明通过悬停或键盘焦点查看。引用总数放在标签徽标，状态和任务记录放在标签栏右侧，不重复显示完成摘要。列表宽度足够时按对象、资源数、同步状态、内容更新、成功同步列对齐；窄屏保留全部字段并纵向排列，不横向裁掉时间或操作。

独立 `AssetRegistrationSummary` 保留自己的策略动作；在公共页头组合时使用 `hideActions`，通过模板ref公开的 `ready/editing/saveStatus` 与 `beginEdit/cancelEdit/save` 接线。独立 `AssetReferenceStatus` 默认显示摘要栏；父级组合可用 `showHeader=false`，通过 `result/failure/openTaskHistory` 在现有Tabs中投影同一份数据，不另发重复状态请求。普通消费者直接使用 `AssetPolicyPage` 即可。

消费者须配套 Asset Go 管理模块、共享 v1/v2/v3 迁移与新的 Work Definition。v3 显式更新引用模块已知旧 Work 摘要，未知摘要仍拒绝启动，不在运行时自动改合同。不要用新前端连接旧 API。产品只提供鉴权、能力权限和 HTTP Adapter，不复制任务、差集、版本或页面行为。

Adapter 必须实现：

- `list(query)`：名称/ID、类型、同步状态、资源数、内容/同步时间的服务端筛选及分页。
- `startSync(mode)`：`pending` 同步未同步对象；`force` 强制同步全部已登记对象。一次调用返回持久任务，不由浏览器循环分页提交。
- `syncRuns(page,size)`、`syncRunItems(runId,page,size)`：当前服务登记账本的任务进度、历史及逐项结果。
- `history(owner,page,size)`、`attempts(owner,jobId)`：对象的跨版本同步记录及执行明细。
- `sync(owner)`、`retry(owner)`：对象操作菜单的显式重新读取，以及当前失败任务的重试。
- `kindLabels`：消费者配置对象名称；`describeError(error)` 使用产品声明式错误解析器，不展示异常正文。

类型入口为 `@yueli/asset-nuxt/references`。`canEdit`（独立组件为 `canRetry`）控制同步操作，服务端仍须验证资源策略管理权限。组件没有 Docs/Blog 分支。

```vue
<AssetPolicyPage :expected-namespace="namespace" :profile-order="profiles"
  :can-edit="canManageAssets" :reference-sync="referenceSyncAdapter" />
```

## 操作规则

1. 保存对象时自动登记引用并后台投递。“刷新状态”只读取结果。
2. **同步未同步对象**：作用于当前服务登记账本的未完成引用；排队、执行中、自动重试中的任务直接继续使用，失败/停用任务按当前台账重新投递，已经完成的对象不重复同步。
3. **强制同步全部对象**：忽略本地“已同步”判断，对全部已登记对象的权威引用集合分配新投递版本，包括删除产生的空集合。它用于强制重投，不重新解析全部业务正文，也不推测未接入写入机制的业务数据。未登记数据的初始化/灾备校准仍使用显式 `Initialize`。
4. 两种操作不受搜索、筛选或分页影响，不需要勾选。服务端物化对象键后以50项推进，限制未完成投递数量；关闭页面、断网或服务重启不取消任务。重复点击返回当前任务，避免并行重复。
5. 进度基于实际投递确认，入队不算成功。主界面保留对象总数和当前状态，仅运行中显示一份进度，成功后收起；部分失败或中断保留提示。成功/失败/已是最新计数、逐项结果与操作者保留在“任务记录”，失败在前且支持分页。活动任务可见时每5秒读取轻量进度，离开标签或页面停止轮询；普通启动和空闲页面不启动全站同步。
6. 对象行的“重新同步引用”仍可重新读取单个业务对象；“同步记录/执行明细”查看来源、操作者及尝试。全局任务来源为 `global-pending` / `global-force`。这是可选诊断入口，批量操作不依赖它。

加载失败、空台账、筛选无结果、任务/历史读取失败分别反馈。Foundation CollectionPanel 的 `surface="plain"` 复用外层卡片，`#actions` 统一搜索筛选和两个全局动作，不在产品覆盖私有DOM或卡片CSS。

同一资源空间可有多个独立服务账本。例如商品和订单各自拥有数据库与Worker，页面的全局按钮不会跨服务扫描订单库；各服务必须分别接入事务登记并完成显式存量初始化。

## 编辑器临时会话

```ts
import { createAssetDraftSession } from '@yueli/asset-nuxt/references'
const draft = createAssetDraftSession(callAssetAPI, uniqueEditorInstanceKey, { lifetimeSeconds: 7 * 24 * 60 * 60 })
const session = await draft.ensure()
await finalize({ uploadToken, draftSessionId: session.id })
```

ID由服务端生成，支持非HTTPS本地环境。会话按编辑实例保存在标签页sessionStorage；`ensure`复用/续期活动会话，`restart`只丢弃本地指针。`AssetDraftSessionResetRequired`区分过期/无效数据，用户明确重新开始后再创建，不删除文件。

一次操作内完成上传/保存时可用 `{storage:'memory'}`。放弃编辑可显式`cancel`释放临时占用，不在unload调用，也不把浏览器保存响应当作正式引用移交确认。已保存对象继续由服务端事务和持久引用保护。


响应式编辑器可使用 `useAssetDraftSession(callAssetAPI, uniqueEditorInstanceKey)`，将 `expiresAt.value` 和 `resetRequired.value` 传入公共 `AssetDraftNotice`，`@restart`调用 `draft.restart`。选择已有资源先 `await draft.hold([{assetId}])` 或 `[{mediaKey}]` 再放入表单；缓存上传结果也必须确认当前会话仍保护该素材。重新开始只清本地会话指针，用户需重新选择未保存素材；不会删除文件或自动承诺过期素材仍存在。

```ts
import {createAssetReferenceSyncAdapter} from '@yueli/asset-nuxt/references'
const references = createAssetReferenceSyncAdapter(callProductAPI, {
  kindLabels: { entry: '条目', attachment: '附件' },
  describeError: error => productFailureMessage(error, '引用操作失败，请稍后重试。'),
})
```

`callProductAPI`使用消费者自身的API Target与登录会话，`callAssetAPI`使用Asset Target。不要因两者都返回JSON而混用站点与Asset请求函数。对象类型、名称与错误文案由配置提供，组件中没有产品名判断。
