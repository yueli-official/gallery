# Traffic for Nuxt

Register each public Nuxt site in the Admin collector. Add `@yueli/traffic-nuxt` to the Nuxt modules and configure the canonical origin and public route allowlist. Match explicit paths and map dynamic segments to reportable resource names.

```ts
yueliTraffic: {
  origin: "https://example.com",
  routes: [{ pattern: "^/$", resource: "/" }],
}
```

Set `NUXT_YUELI_TRAFFIC_COLLECTOR_URL` and `NUXT_YUELI_TRAFFIC_WRITE_TOKEN` in the Web server environment. The browser posts to its own origin and never receives the site write token. Private routes, route parameters and query strings stay out of tracking data. Global Privacy Control and Do Not Track suppress collection.
