import { addPlugin, addServerHandler, createResolver, defineNuxtModule } from "@nuxt/kit";

interface PublicRoute {
  pattern: string;
  resource: string;
}

interface TrafficOptions {
  origin: string;
  routes: PublicRoute[];
}

export default defineNuxtModule<TrafficOptions>({
  meta: { name: "@yueli/traffic-nuxt", configKey: "yueliTraffic" },
  setup({ origin, routes }, nuxt) {
    if (origin !== new URL(origin).origin || !routes.length) {
      throw new Error("Traffic requires a canonical origin and eligible public routes");
    }
    for (const { pattern, resource } of routes) {
      if (!pattern.startsWith("^/") || !pattern.endsWith("$") ||
          !/^\/[a-zA-Z0-9/_:.-]{0,199}$/.test(resource) || resource.startsWith("//")) {
        throw new Error("Invalid public route for site traffic");
      }
      new RegExp(pattern);
    }
    nuxt.options.runtimeConfig.yueliTraffic = {
      origin,
      resources: routes.map(route => route.resource),
      collectorUrl: "",
      writeToken: "",
    };
    nuxt.options.runtimeConfig.public.yueliTrafficRoutes = routes;
    const resolver = createResolver(import.meta.url);
    addPlugin({ src: resolver.resolve("runtime/page-view.client"), mode: "client" });
    addServerHandler({
      route: "/api/site-traffic/page",
      method: "post",
      handler: resolver.resolve("runtime/page-view.post"),
    });
  },
});
