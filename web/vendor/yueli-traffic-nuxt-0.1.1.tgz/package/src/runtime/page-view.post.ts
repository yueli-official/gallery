import { randomUUID } from "node:crypto";
import { useRuntimeConfig } from "#imports";
import {
  defineEventHandler, getRequestHeader, getRequestWebStream, sendNoContent,
  setResponseHeaders, setResponseStatus, type H3Event,
} from "h3";

interface TrafficRuntimeConfig {
  origin: string;
  resources: string[];
  collectorUrl: string;
  writeToken: string;
}

const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const maxBodyBytes = 1024;

const failures = {
  400: "traffic.ingest.invalid_event",
  403: "traffic.ingest.origin_required",
  413: "traffic.ingest.event_too_large",
  415: "traffic.ingest.json_required",
  503: "traffic.ingest.unavailable",
} as const;

function problem(event: H3Event, status: keyof typeof failures) {
  const code = failures[status];
  setResponseStatus(event, status);
  setResponseHeaders(event, {
    "content-type": "application/problem+json",
    "cache-control": "no-store",
  });
  return { type: `https://errors.yueli.dev/problems/${code}`, status, code, traceId: randomUUID() };
}

export default defineEventHandler(async (event) => {
  const config = useRuntimeConfig(event).yueliTraffic as TrafficRuntimeConfig;
  if (getRequestHeader(event, "origin") !== config.origin) {
    return problem(event, 403);
  }
  if (getRequestHeader(event, "sec-gpc") === "1" || getRequestHeader(event, "dnt") === "1") {
    return sendNoContent(event);
  }
  if (!config.collectorUrl || !/^[A-Za-z0-9_-]{32,128}$/.test(config.writeToken)) {
    return problem(event, 503);
  }
  if (getRequestHeader(event, "content-type")?.split(";")[0] !== "application/json") {
    return problem(event, 415);
  }
  const stream = getRequestWebStream(event);
  const reader = stream?.getReader();
  const decoder = new TextDecoder();
  let raw = "";
  let size = 0;
  if (reader) {
    try {
      for (;;) {
        const chunk = await reader.read();
        if (chunk.done) break;
        size += chunk.value.byteLength;
        if (size > maxBodyBytes) {
          await reader.cancel();
          return problem(event, 413);
        }
        raw += decoder.decode(chunk.value, { stream: true });
      }
      raw += decoder.decode();
    } finally {
      reader.releaseLock();
    }
  }
  let payload: unknown;
  try {
    payload = JSON.parse(raw);
  } catch {
    return problem(event, 400);
  }
  if (typeof payload !== "object" || !payload) {
    return problem(event, 400);
  }
  const { id, resource, visitorKey, referrer } = payload as Record<string, unknown>;
  if (typeof id !== "string" || !uuid.test(id) ||
      typeof resource !== "string" || !config.resources.includes(resource) ||
      typeof visitorKey !== "string" || (visitorKey !== "" && !uuid.test(visitorKey)) ||
      typeof referrer !== "string" || !/^[a-z0-9.-]{0,253}$/i.test(referrer)) {
    return problem(event, 400);
  }
  const agent = getRequestHeader(event, "user-agent") ?? "";
  try {
    await $fetch("/v1/events", {
      baseURL: config.collectorUrl,
      method: "POST",
      headers: { authorization: `Bearer ${config.writeToken}` },
      body: {
        id,
        metric: "page_view",
        resource,
        visitorKey,
        occurredAt: new Date().toISOString(),
        class: /bot|crawl|spider|preview|headless/i.test(agent) ? "bot" : "unknown",
        ...(!resource.includes(":") && { page: { path: resource, referrer } }),
      },
      retry: 0,
      redirect: "error",
      timeout: 1500,
    });
  } catch {
    return problem(event, 503);
  }
  return sendNoContent(event);
});
