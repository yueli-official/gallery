import { defineNuxtPlugin, useRouter, useRuntimeConfig } from "#app";

interface TrafficNavigator extends Navigator {
  globalPrivacyControl?: boolean;
}

const visitorStorageKey = "yueli-site-traffic-visitor";

export default defineNuxtPlugin((app) => {
  const privacy = navigator as TrafficNavigator;
  if (privacy.globalPrivacyControl || privacy.doNotTrack === "1") return;

  const router = useRouter();
  const routes = useRuntimeConfig().public.yueliTrafficRoutes as { pattern: string; resource: string }[];
  const rules = routes.map(rule => ({ matches: new RegExp(rule.pattern), resource: rule.resource }));
  let previousPath: string | undefined;

  async function record(path: string) {
    if (path === previousPath) return;
    const resource = rules.find(rule => rule.matches.test(path))?.resource;
    const referrer = previousPath ? "internal" : document.referrer ? new URL(document.referrer).hostname : "";
    previousPath = path;
    if (!resource) return;

    const visitorKey = localStorage.getItem(visitorStorageKey) || crypto.randomUUID();
    localStorage.setItem(visitorStorageKey, visitorKey);
    await $fetch("/api/site-traffic/page", {
      method: "POST",
      body: { id: crypto.randomUUID(), resource, visitorKey, referrer },
      retry: 0,
    });
  }

  app.hook("app:mounted", () => { void record(router.currentRoute.value.path).catch(() => undefined); });
  router.afterEach((to, _from, failure) => {
    if (!failure) void record(to.path).catch(() => undefined);
  });
});
