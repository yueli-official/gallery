export interface SiteLauncherItem { id: string; name: string; url: string; icon: 'home' | 'book' | 'package' }
