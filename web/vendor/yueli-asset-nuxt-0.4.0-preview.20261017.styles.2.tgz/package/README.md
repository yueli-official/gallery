# @yueli/asset-nuxt

公开图片只通过 `assetMediaUrl(assetId, rendition)` 生成命名媒体 URL；消费者不得拼接 Asset UUID、尺寸、裁剪、
质量或内部派生路径。默认同站点地址为：

```text
/media/{mediaKey}?format=webp&preset=display&v=1
```

该路径由匿名媒体代理转发给 Asset `/api/v1/media/*`；`v` 是必填缓存代际，派生规则变化时递增。`/asset-api` 继续只承载上传、管理等真正 API。生产环境
可通过 `base` 指向专用图片域名；query 始终按 `format`、`name` 的 canonical 顺序输出。以后新增 Asset v2 时
由代理选择 implementation 版本，浏览器 URL 不随之变化。

Asset 所有的 Nuxt 客户端层，提供同源 Asset/Identity BFF、标准 API composable、站点资源设置界面与图片裁剪器。
它不处理文件字节，也不拥有业务条目；资源元数据、存储和交付策略仍由 Asset 服务负责。

## 边界

- BFF 使用 `@yueli/nuxt-runtime` 的有界 handler，并从 `@yueli/identity-nuxt` 取得服务端会话凭证。
- composable 直接组合 Foundation HTTP/Nuxt runtime，不依赖产品自定义 `useApi`。
- 设置工作流与裁剪器组合 Foundation UI 的 settings、feedback 和 image 原语，不依赖 Platform Manage/UI。
- 产品拥有 site/profile 选择、业务授权和上传完成后的领域引用。标准资源策略页布局由 `AssetPolicyPage` 拥有。

## 使用

```ts
export default defineNuxtConfig({
  extends: ["@yueli/identity-nuxt", "@yueli/asset-nuxt"],
});
```

管理后台直接使用领域页面 Module：

layer 会自动启用 Foundation UI 并登记全部 Asset 组件的样式来源。站点无需导入 `@yueli/asset-nuxt/tailwind.css`，也不声明包内部的 `@source`。默认布局随组件提供；业务参数、主题变量、组件公开 props 与 slots 负责定制。源码联调时，本层精确登记 Cropper 自身的依赖目录，产品无需另设 Vite 文件访问范围。

```vue
<AssetPolicyPage
  expected-namespace="gallery"
  :profile-order="['gallery-submission']"
  :can-edit="canEditAssets"
/>
```

消费端必须配置名为 `asset` 与 `identity` 的 Yueli runtime target，并提供私有
`NUXT_ASSET_BASE`、`NUXT_IDENTITY_BASE`。大文件应使用 Asset 的签名直传/分片协议，不经过有界 BFF body。

## 验证

```text
pnpm --filter @yueli/asset-nuxt test
```

## Shared image workbench (preview)

`AssetImageWorkbench` from `@yueli/asset-nuxt/components` provides Upload/Edit tabs, content deduplication, 256px thumbnails, a 1536px cached editor preview and original-resolution export. Inputs remain local until its `processed(File[])` event; the consumer owns uploading and insertion. Closing clears the session and releases its worker and URLs.

In insecure HTTP environments, deduplication falls back to exact chunked byte comparisons via `assetFilesEqual`; no filename or approximate hash is trusted. `createAssetUploadMemo(maxEntries)` lets consumers align retry caches with their queue limit (default remains 4).

Props: `maxFiles` caps processing/insertion (undefined = unlimited); excess selected images stay visible for removal, while edit and insert remain disabled; `maxOutputSide` caps the output size control (default 4096); `fixedMaxOutputSide` uses a site-policy longest edge as a read-only limit and enforces it at export; `fixedMaxOutputWidth` instead limits only width and preserves tall body images (takes precedence over the longest-edge limit); `defaultOutputSide`, `defaultOutputType` and `defaultQuality` seed processing. Read accepted registration settings before opening; these browser options do not authorize bypassing Asset policy. `v-model:open` controls the dialog, exposed `add(File[])` supports editor drop/paste adapters. Batch edits require Apply; per-image edits stay isolated. GIF/animated WebP retain their original frames. Encoded edit previews use a 64MiB LRU budget; this is not a total browser memory cap.

Feedback: queue constraints use shared dismissible InlineStatus beside the upload area; Apply uses ActionFeedbackButton and resets its success state when draft settings change. Foundation UI feedback.2 supplies the accepted closable/tinted/swipe/action design. No duplicate success Toast or solid-color error banner.

Image editing dialogs never dismiss on backdrop click or Escape; cancel/close must be explicit. The queue limit warning is dismissible, but processing remains disabled until the queue is within its configured limit.

workbench.8 adds modal-independent original-pixel export. Confirm hides the modal while a local progress region advances per exported file; `progress({completed,total,pending})` lets consumers coordinate upload progress and prevent submitting an incomplete body. Failed exports reopen the editor with saved crops/options; successful completion clears local previews. It does not perform network uploads.

workbench.12 refines layout: compact empty upload state, bounded thumbnail grid with queue summary, grouped edit settings and a compact carousel. The modal body owns scrolling for embedded editing; no new upload limits or gradients.

The Nuxt layer resolves the exact `cropperjs` import to its ESM entry for Vite; consumers retain the package types and CSS subpath without per-product aliases.

workbench.13 places queue position/previous/next beside the crop tools, moves zoom to the right and adds wider horizontal/narrow vertical gutters around the embedded crop viewport. The thumbnail strip only shows thumbnails. Gutters change display space, not crop bounds or exported pixels.

workbench.16 uses one embedded preview background, one crop toolbar including zoom, a backed thumbnail strip and larger previous/position/next controls in the modal footer. Insert has an icon and a separate numeric count; no full-width punctuation is used for spacing. Standalone cropping keeps the existing background and crop-mask options.

workbench.17 returns footer navigation and actions to compact 32px buttons with 16px icons and 12px labels/counts, preserving the footer layout.
