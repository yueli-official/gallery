<script setup lang="ts">
import { InlineStatus, ActionFeedbackButton } from '@yueli/ui/feedback/pattern'
import { useActionFeedback } from '@yueli/ui/feedback'
import {exportWorkbenchImage,type WorkbenchCrop} from '../image-workbench-export'
import AssetImageCropper from './AssetImageCropper.vue'
import AssetImageQueue from './AssetImageQueue.vue'
import AssetImageNavigation from './AssetImageNavigation.vue'
import { computed, ref, shallowRef, watch, nextTick, onBeforeUnmount } from 'vue'
import { ImageWorkbenchPreviewStore, type ImageRasterPreview } from '../image-workbench-preview'
import type Cropper from 'cropperjs'
import { assetFilesEqual } from '../upload'
import { preserveImageTimeline } from '../animated-image'
const props=withDefaults(defineProps<{maxFiles?:number;maxOutputSide?:number;fixedMaxOutputSide?:number;fixedMaxOutputWidth?:number;defaultOutputSide?:number;defaultOutputType?:'image/webp'|'image/jpeg'|'image/png';defaultQuality?:number}>(),{maxFiles:undefined,maxOutputSide:4096,defaultOutputSide:1200,defaultOutputType:'image/webp',defaultQuality:88})
const open=defineModel<boolean>('open',{default:false})
const emit=defineEmits<{processed:[files:File[]];progress:[value:{completed:number;total:number;pending:boolean}]}>()
type Options={ratio:string;ratioWidth:number;ratioHeight:number;side:number;format:'image/webp'|'image/jpeg'|'image/png';quality:number}
type Item={id:number;file:File;url:string;fingerprint:string;options:Options;crop?:Cropper.Data;exportCrop?:WorkbenchCrop;animated:boolean}
const items=ref<Item[]>([]), active=ref(0),tab=ref('upload'),selectedFiles=ref<File[]>([]),surface=ref<InstanceType<typeof AssetImageCropper>>(),busy=ref(false),error=ref(''),notice=ref('')
const applyFeedback=useActionFeedback()
const processingProgress=ref({completed:0,total:0})
let sequence=0
let generation=0
let pendingAdd:Promise<void>=Promise.resolve()
const fingerprints=new WeakMap<File,Promise<string>>()
let previewStore:ImageWorkbenchPreviewStore|undefined
let previewGeneration=0
const activePreview=shallowRef<ImageRasterPreview>(),previewPending=ref(false),adding=ref(false)
function store(){return previewStore ||= new ImageWorkbenchPreviewStore()}
const fixedSide=computed(()=>props.fixedMaxOutputSide===undefined?undefined:Math.min(props.fixedMaxOutputSide,props.maxOutputSide))
const fixedWidth=computed(()=>props.fixedMaxOutputWidth)
const overLimit=computed(()=>props.maxFiles!==undefined&&items.value.length>props.maxFiles)
const overflowDismissed=ref(false)
const overflowMessage=computed(()=>`已选择 ${items.value.length} 张，最多 ${props.maxFiles} 张，请移除 ${items.value.length-(props.maxFiles||0)} 张后继续`)
watch(()=>[items.value.length,props.maxFiles],()=>{overflowDismissed.value=false})
function defaults():Options{return {ratio:'free',ratioWidth:3,ratioHeight:2,side:fixedSide.value??Math.min(props.defaultOutputSide,props.maxOutputSide),format:props.defaultOutputType,quality:props.defaultQuality}}
function fingerprint(file:File){let value=fingerprints.get(file);if(!value){value=file.arrayBuffer().then(bytes=>crypto.subtle.digest('SHA-256',bytes)).then(hash=>Array.from(new Uint8Array(hash),n=>n.toString(16).padStart(2,'0')).join(''));fingerprints.set(file,value)}return value}
function clearSession(){applyFeedback.reset();generation++;previewGeneration++;previewStore?.dispose();previewStore=undefined;activePreview.value=undefined;previewPending.value=false;adding.value=false;items.value=[];selectedFiles.value=[];active.value=0;tab.value='upload';settingsScope.value='all';batchOptions.value=defaults();appliedOptions.value=defaults();error.value='';notice.value=''}
const current=computed(()=>items.value[active.value])
const settingsScope=ref('all')
const batchOptions=ref<Options>(defaults())
const appliedOptions=ref<Options>({...batchOptions.value})
const settings=computed(()=>settingsScope.value==='all'?batchOptions.value:(current.value?.options||batchOptions.value))
const ratioItems=[{label:'自由裁剪',value:'free'},{label:'宽屏 16:9',value:'16:9'},{label:'横向 3:2',value:'3:2'},{label:'标准 4:3',value:'4:3'},{label:'方形 1:1',value:'1:1'},{label:'自定义比例',value:'custom'}]
const formats=[{label:'WebP',value:'image/webp'},{label:'JPEG',value:'image/jpeg'},{label:'PNG · 无损',value:'image/png'}]
const ratio=computed(()=>{const o=current.value?.options;if(!o||o.ratio==='free')return undefined;return o.ratio==='custom'?o.ratioWidth/o.ratioHeight:Number(o.ratio.split(':')[0])/Number(o.ratio.split(':')[1])})
function save(){if(current.value&&surface.value?.canConfirm){current.value.crop=surface.value.getState();current.value.exportCrop=surface.value.getExportState()}}
function choose(index:number){if(overLimit.value||adding.value||busy.value)return;save();active.value=index;settingsScope.value='current';notice.value='';tab.value='edit'}
function beginEdit(){if(overLimit.value||adding.value||busy.value)return;save();settingsScope.value='all';tab.value='edit'}
function switchTab(value:string|number){if(value==='edit')beginEdit();else{save();tab.value=String(value)}}
function add(files:File[]){
 const token=generation
 const run=async()=>{
  if(busy.value||token!==generation)return
  error.value='';notice.value='';adding.value=true
  let duplicates=0,index=0
  try{
   const seen=new Set(items.value.map(i=>i.fingerprint)),incoming:Array<{file:File;hash:string}>=[]
   for(const file of files){
    if(!file.type.startsWith('image/'))continue
    let hash:string
    if(globalThis.crypto?.subtle)hash=await fingerprint(file)
    else {
     const known=[...items.value.map(item=>({file:item.file,hash:item.fingerprint})),...incoming]
     let duplicate:typeof known[number]|undefined
     for(const candidate of known){if(await assetFilesEqual(candidate.file,file)){duplicate=candidate;break}}
     hash=duplicate?.hash||`local-${++sequence}`
    }
    if(token!==generation)return
    if(seen.has(hash)){duplicates++;continue}
    seen.add(hash);incoming.push({file,hash})
   }
   for(const {file,hash} of incoming){
    index++;notice.value=`正在准备预览 ${index}/${incoming.length}`
    const animated=await preserveImageTimeline(file)
    if(token!==generation)return
    const owner=store(),thumb=await owner.thumbnail(file,hash)
    if(token!==generation){owner.releaseThumbnail(thumb.url);return}
    items.value.push({id:++sequence,file,url:thumb.url,fingerprint:hash,options:{...appliedOptions.value},animated});tab.value='upload'
   }
   if(token===generation)notice.value=duplicates?`已忽略 ${duplicates} 张重复图片`:''
  }catch(e){if(token===generation)error.value=e instanceof Error?e.message:'图片读取失败'}
  finally{if(token===generation)adding.value=false}
 }
 const result=pendingAdd.then(run);pendingAdd=result.catch(()=>{});return result
}
async function preparePreview(){const token=++previewGeneration;activePreview.value=undefined;previewPending.value=false;const item=current.value;if(!open.value||tab.value!=='edit'||!item||item.animated)return;previewPending.value=true;const owner=store();owner.pin(item.fingerprint);try{const preview=await owner.preview(item.file,item.fingerprint);if(token!==previewGeneration)return;activePreview.value=preview;previewPending.value=false;}catch(e){if(token===previewGeneration){previewPending.value=false;error.value=e instanceof Error?e.message:'图片预览失败'}}}
watch(()=>[open.value,tab.value,current.value?.id],()=>{void preparePreview()})
watch(selectedFiles,files=>{if(files.length){void add(files);selectedFiles.value=[]}})
function paste(e:ClipboardEvent){const files=Array.from(e.clipboardData?.files||[]);if(files.length){e.preventDefault();void add(files)}}
function resetRatio(){if(settingsScope.value==='current'&&current.value){current.value.crop=undefined;current.value.exportCrop=undefined}}
watch(batchOptions,()=>applyFeedback.reset(),{deep:true,flush:'sync'})
function applySettings(){if(settingsScope.value!=='all')return;const token=applyFeedback.begin();save();appliedOptions.value={...batchOptions.value};for(const item of items.value){const changed=item.options.ratio!==batchOptions.value.ratio||item.options.ratioWidth!==batchOptions.value.ratioWidth||item.options.ratioHeight!==batchOptions.value.ratioHeight;Object.assign(item.options,batchOptions.value);if(changed){item.crop=undefined;item.exportCrop=undefined}}notice.value='';applyFeedback.success(token)}
function remove(index:number){save();const item=items.value[index]!;previewStore?.releaseThumbnail(item.url);previewStore?.remove(item.fingerprint);items.value.splice(index,1);active.value=Math.min(active.value,items.value.length-1);if(!items.value.length){active.value=0;tab.value='upload'}}
async function confirm(){
 if(overLimit.value||busy.value||adding.value||!items.value.length)return
 save();busy.value=true;error.value=''
 const token=generation,total=items.value.length
 processingProgress.value={completed:0,total};emit('progress',{completed:0,total,pending:true})
 await nextTick();await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))
 try{
  const results:File[]=[]
  for(const item of items.value){
   if(token!==generation)return
   const o=item.options,ratio=o.ratio==='free'?undefined:o.ratio==='custom'?o.ratioWidth/o.ratioHeight:Number(o.ratio.split(':')[0])/Number(o.ratio.split(':')[1])
   results.push(item.animated?item.file:await exportWorkbenchImage(item.file,{ratio,side:fixedSide.value??o.side,maxWidth:fixedWidth.value,format:o.format,quality:o.quality},item.exportCrop))
   if(token!==generation)return
   processingProgress.value={completed:results.length,total};emit('progress',{completed:results.length,total,pending:true})
  }
  emit('processed',results);open.value=false
 }catch(e){if(token===generation){error.value=e instanceof Error?e.message:'图片处理失败';tab.value='edit'}}
 finally{busy.value=false;emit('progress',{completed:total,total,pending:false})}
}
watch(()=>[props.maxOutputSide,props.defaultOutputSide,props.defaultOutputType,props.defaultQuality],()=>{if(!items.value.length){batchOptions.value=defaults();appliedOptions.value=defaults()}})
watch(open,value=>{if(!value)clearSession();else if(!items.value.length){batchOptions.value=defaults();appliedOptions.value=defaults()}},{flush:'sync'})
onBeforeUnmount(clearSession)
defineExpose({add,getPreviewCacheStats:()=>previewStore?.stats})
</script>
<template>
  <UModal :open="open && !busy" @update:open="value => { if (!busy) open = value }" title="添加图片"
    :dismissible="false" :close="!busy"
    :ui="{ content: 'sm:max-w-7xl', body: 'asset-image-workbench-scroll min-h-0 p-4 sm:p-5' }">
    <template #body>
      <div @paste.capture="paste" data-image-workbench>
        <UTabs :model-value="tab"
          :items="[{ label: '上传', value: 'upload' }, { label: `编辑${items.length ? ' (' + items.length + ')' : ''}`, value: 'edit', disabled: !items.length || adding || overLimit }]"
          :content="false" variant="link" class="mb-4" @update:model-value="switchTab" />
        <div v-if="tab === 'upload'" class="flex min-h-0 flex-col gap-3"
          :class="items.length ? 'h-[min(38rem,calc(100dvh-15rem))]' : ''" data-upload-pane>
          <UFileUpload v-model="selectedFiles" multiple accept="image/*" layout="grid" :preview="false"
            label="拖入图片，或点击选择" :description="maxFiles === undefined ? '可选择多张图片，添加后统一编辑' : `最多 ${maxFiles} 张，添加后统一编辑`"
            :disabled="busy || adding" class="w-full shrink-0"
            :ui="{ base: items.length ? 'min-h-40 p-4 sm:p-4' : 'min-h-64 p-6 sm:p-8', label: 'font-medium', wrapper: 'gap-2' }" data-upload-dropzone>
            <template #leading><span class="inline-flex size-12 items-center justify-center rounded-xl bg-primary/10 text-primary"><UIcon name="i-tabler-cloud-upload" class="size-7" /></span></template>
            <template #actions="{ open: chooseFiles }"><UButton label="选择图片" icon="i-tabler-plus" :disabled="busy || adding" @click.stop="chooseFiles()" @keyup.stop /></template>
          </UFileUpload>
          <InlineStatus v-if="overLimit && !overflowDismissed" variant="plain" tone="warning" dismiss-label="关闭提示" class="shrink-0" @dismiss="overflowDismissed = true">{{ overflowMessage }}</InlineStatus>
          <InlineStatus v-if="error" variant="plain" tone="error" dismissible dismiss-label="关闭提示" class="shrink-0" @dismiss="error = ''">{{ error }}</InlineStatus>
          <template v-if="items.length">
            <div class="flex shrink-0 items-center justify-between gap-3 rounded-lg bg-elevated px-3 py-2" data-upload-toolbar>
              <span class="text-sm text-muted">已添加 {{ items.length }} 张图片</span>
              <UButton label="清空图片" icon="i-tabler-trash" color="neutral" variant="ghost" size="sm" :disabled="busy || adding" @click="clearSession" />
            </div>
            <div class="asset-image-workbench-scroll min-h-0 flex-1 overflow-y-auto" data-upload-scroll>
              <div class="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-6" aria-label="已添加图片">
                <div v-for="(item, index) in items" :key="item.id" class="relative min-w-0 overflow-hidden rounded-lg border border-default bg-default p-1.5">
                  <button class="w-full min-w-0 text-left" :disabled="adding || busy || overLimit" :aria-label="`编辑 ${item.file.name}`" @click="choose(index)">
                    <img :src="item.url" alt="" class="aspect-[3/2] w-full rounded-md bg-elevated object-cover" loading="lazy" decoding="async">
                    <span :title="item.file.name" class="block truncate px-1 pb-1 pt-2 text-xs">{{ item.file.name }}</span>
                  </button>
                  <UButton icon="i-tabler-x" :aria-label="`移除 ${item.file.name}`" color="neutral" variant="soft" size="xs" class="absolute right-2.5 top-2.5" :disabled="busy || adding" @click="remove(index)" />
                </div>
              </div>
            </div>
          </template>
        </div>
        <template v-else-if="current">
          <AssetImageCropper v-if="!current.animated" ref="surface" embedded maximal-crop browser-orientation :open="open"
            :file="activePreview ? current.file : undefined" :preview-url="activePreview?.url" :raster-preview="activePreview" :pending-preview="previewPending"
            :initial-crop="current.crop" :mode="current.options.ratio === 'free' ? 'free' : 'fixed-aspect'" :aspect-ratio="ratio"
            :output-width="(fixedWidth ?? fixedSide ?? current.options.side) || undefined"
            :output-height="fixedWidth === undefined ? ((fixedSide ?? current.options.side) || undefined) : undefined"
            :output-type="current.options.format" :quality="current.options.quality / 100" @error="error = $event">
            <template #queue><AssetImageQueue :items="items" :active="active" :disabled="busy" @change="choose" /></template>
            <template #controls="{ sourceSize, outputSize }">
              <div class="space-y-3" data-workbench-settings>
                <div class="rounded-lg border border-default p-1.5">
                  <UTabs v-model="settingsScope" :items="[{ label: '批量设置', value: 'all' }, { label: '当前图片', value: 'current' }]" :content="false" size="sm" />
                </div>
                <p v-if="settingsScope === 'current'" :title="current.file.name" class="truncate px-1 text-xs text-muted">{{ current.file.name }}</p>
                <div class="space-y-3 rounded-lg border border-default p-3">
                  <UFormField label="裁剪比例"><USelect v-model="settings.ratio" :items="ratioItems" class="w-full" :disabled="busy" @update:model-value="resetRatio()" /></UFormField>
                  <div v-if="settings.ratio === 'custom'" class="grid grid-cols-2 gap-2">
                    <UFormField label="比例宽"><UInputNumber v-model="settings.ratioWidth" :min="1" :max="100" class="w-full" @update:model-value="resetRatio()" /></UFormField>
                    <UFormField label="比例高"><UInputNumber v-model="settings.ratioHeight" :min="1" :max="100" class="w-full" @update:model-value="resetRatio()" /></UFormField>
                  </div>
                </div>
                <div class="rounded-lg border border-default p-3">
                  <UFormField :label="fixedWidth === undefined ? '最长边' : '最大宽度'" hint="不放大">
                    <p v-if="fixedWidth !== undefined || fixedSide !== undefined" class="rounded-md bg-elevated px-3 py-2 text-sm text-default" data-output-limit>{{ fixedWidth ?? fixedSide }} px</p>
                    <UInputNumber v-else v-model="settings.side" :min="64" :max="maxOutputSide" :step="1" class="w-full" :disabled="busy" />
                  </UFormField>
                </div>
                <div class="rounded-lg border border-default p-3">
                  <UFormField label="输出格式"><USelect v-model="settings.format" :items="formats" class="w-full" :disabled="busy" /></UFormField>
                </div>
                <div v-if="settings.format !== 'image/png'" class="rounded-lg border border-default p-3">
                  <UFormField label="质量" :hint="`${settings.quality}%`"><USlider v-model="settings.quality" :min="30" :max="100" :disabled="busy" /></UFormField>
                </div>
                <ActionFeedbackButton v-if="settingsScope === 'all'" :status="applyFeedback.status.value" :idle-label="`应用到全部（${items.length} 张）`" pending-label="应用中" success-label="已应用" block :disabled="busy" @click="applySettings" />
                <dl v-else class="space-y-2 rounded-lg bg-elevated p-3 text-xs">
                  <div class="flex justify-between gap-2"><dt>原图</dt><dd>{{ sourceSize?.width }} × {{ sourceSize?.height }}</dd></div>
                  <div class="flex justify-between gap-2 font-medium text-primary"><dt>最终输出</dt><dd data-output-size>{{ outputSize?.width }} × {{ outputSize?.height }}</dd></div>
                </dl>
              </div>
            </template>
          </AssetImageCropper>
          <div v-else class="space-y-4"><img :src="current.url" alt="动态图预览" class="mx-auto max-h-80"><InlineStatus variant="plain" tone="info">动态图保留原始帧，不使用静态裁剪和旋转。</InlineStatus><AssetImageQueue :items="items" :active="active" :disabled="busy" @change="choose" /></div>
        </template>
        <InlineStatus v-if="error && tab !== 'upload'" variant="plain" tone="error" dismissible dismiss-label="关闭提示" class="mt-3" @dismiss="error = ''">{{ error }}</InlineStatus>
      </div>
    </template>
    <template #footer>
      <div class="flex w-full flex-wrap items-center justify-between gap-2" data-workbench-footer>
        <AssetImageNavigation v-if="tab === 'edit'" :active="active" :total="items.length" :disabled="busy || adding || overLimit" @change="choose" />
        <span v-else role="status" class="text-xs text-muted">{{ busy ? '正在处理图片…' : notice || `已添加 ${items.length}${maxFiles !== undefined ? '/' + maxFiles : ''} 张图片` }}</span>
        <div class="ml-auto flex shrink-0 gap-2">
          <UButton label="取消" color="neutral" variant="ghost" size="sm" class="h-8 px-3 text-xs" :disabled="busy" @click="save(); open = false" />
          <UButton v-if="tab === 'upload'" label="编辑" size="sm" class="h-8 px-3 text-xs" :disabled="!items.length || busy || adding || overLimit" @click="beginEdit" />
          <UButton v-else icon="i-tabler-photo-plus" :aria-label="`插入 ${items.length} 张图片`" size="sm" class="h-8 gap-1 px-3 text-xs" :ui="{ leadingIcon: 'size-4' }" :loading="busy" :disabled="!items.length || overLimit || adding" @click="confirm" data-image-insert>
            <span>插入</span><span class="min-w-4 text-center tabular-nums" aria-hidden="true">{{ items.length }}</span>
          </UButton>
        </div>
      </div>
    </template>
  </UModal>
  <div v-if="busy" role="status" class="space-y-2 rounded-lg border border-default bg-elevated p-3" data-image-processing>
    <p class="text-xs text-muted">正在插入图片 {{ processingProgress.completed }} / {{ processingProgress.total }}</p>
    <UProgress :model-value="processingProgress.completed" :max="processingProgress.total" size="xs" />
  </div>
</template>

<style>
.asset-image-workbench-scroll { scrollbar-width: thin; scrollbar-color: var(--ui-border-accented) transparent; }
.asset-image-workbench-scroll::-webkit-scrollbar { width: 6px; height: 6px; }
.asset-image-workbench-scroll::-webkit-scrollbar-thumb { background: var(--ui-border-accented); border-radius: 6px; }
</style>
