import { canvasImageBlob } from './canvas-image'
import { calculateCropCanvasSize, filenameForCrop, type AssetCropOutputType } from './image-cropper'
export interface WorkbenchCrop {left:number;top:number;width:number;height:number;rotate:number;scaleX:number;scaleY:number}
/** Original pixels and saved crop: no mounted modal required. */
export async function exportWorkbenchImage(file:File, options:{ratio?:number;side:number;maxWidth?:number;format:AssetCropOutputType;quality:number}, crop?:WorkbenchCrop):Promise<File>{
 const source=await createImageBitmap(file,{imageOrientation:'from-image'})
 try{
  const angle=(crop?.rotate||0)*Math.PI/180
  const width=Math.abs(source.width*Math.cos(angle))+Math.abs(source.height*Math.sin(angle))
  const height=Math.abs(source.width*Math.sin(angle))+Math.abs(source.height*Math.cos(angle))
  const ratio=options.ratio||width/height,w=Math.min(width,height*ratio),h=w/ratio
  const area=crop||{left:(width-w)/2,top:(height-h)/2,width:w,height:h,rotate:0,scaleX:1,scaleY:1}
  const size=calculateCropCanvasSize(area,{width:options.maxWidth??options.side,height:options.maxWidth===undefined?options.side:undefined})
  const canvas=document.createElement('canvas');canvas.width=size.width;canvas.height=size.height
  const ctx=canvas.getContext('2d',{colorSpace:'srgb'});if(!ctx)throw new Error('当前浏览器不支持图片处理')
  if(options.format==='image/jpeg'){ctx.fillStyle='#fff';ctx.fillRect(0,0,size.width,size.height)}
  ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high'
  ctx.scale(size.width/area.width,size.height/area.height);ctx.translate(-area.left,-area.top);ctx.translate(width/2,height/2);ctx.rotate(angle);ctx.scale(area.scaleX,area.scaleY);ctx.drawImage(source,-source.width/2,-source.height/2)
  const blob=await canvasImageBlob(canvas,options.format,options.quality/100)
  canvas.width=canvas.height=1
  return new File([blob],filenameForCrop(file.name,options.format),{type:options.format})
 }finally{source.close()}
}
