<script setup lang="ts">
import { computed, ref } from 'vue';
import { TabbedSurface } from '@yueli/ui/admin';
import type { AssetReferenceSyncAdapter } from '../references';
import AssetReferenceStatus from './AssetReferenceStatus.vue';
import AssetReferenceSummary from './AssetReferenceSummary.vue';

defineProps<{ referenceSync?: AssetReferenceSyncAdapter; canEdit?: boolean }>();
const section = ref('purposes');
const status = ref<InstanceType<typeof AssetReferenceStatus> | null>(null);
const sections = computed(() => [
  { value: 'purposes', label: '用途', icon: 'i-tabler-adjustments' },
  { value: 'references', label: '资源引用', icon: 'i-tabler-link', badge: status.value?.result?.registered },
]);
</script>

<template>
  <TabbedSurface v-if="referenceSync" v-model="section" :items="sections" navigation-label="资源策略分区">
    <template v-if="section === 'references'" #actions>
      <AssetReferenceSummary :result="status?.result" :failed-to-load="!!status?.failure" :can-retry="canEdit" :show-count="false" @history="status?.openTaskHistory()" />
    </template>
    <div v-show="section === 'purposes'"><slot /></div>
    <AssetReferenceStatus ref="status" v-show="section === 'references'" :active="section === 'references'" :adapter="referenceSync" :can-retry="canEdit" :show-header="false" embedded />
  </TabbedSurface>
  <section v-else class="yueli-card"><slot /></section>
</template>
