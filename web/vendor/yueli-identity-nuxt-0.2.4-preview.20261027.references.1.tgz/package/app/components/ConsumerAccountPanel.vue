<script setup lang="ts">
import { computed } from "vue";
import { AccountMobilePanel, type AccountMenuAction, type AccountMenuAppearance } from "@yueli/ui/account-menu/pattern";
import { accountMediaUrl } from "../utils/account-media";
const props = withDefaults(defineProps<{
 siteName: string; contextActions?: readonly AccountMenuAction[];
 canManage?: boolean; manageTo?: string; manageLabel?: string; manageDescription?: string;
 switchSiteAction?: AccountMenuAction;
}>(), { canManage: undefined, contextActions: () => [], manageTo: "", manageLabel: "站点管理", manageDescription: "管理当前站点的内容" });
const { user, loggedIn, isAdmin, login, logout } = useAuth();
const colorMode = useColorMode();
const accountOrigin = computed(() => useRuntimeConfig().public.accountUrl || "http://localhost:3000");
const avatar = computed(() => accountMediaUrl(user.value?.avatar, accountOrigin.value));
const allowedToManage = computed(() => props.canManage ?? isAdmin.value);
const context = computed<AccountMenuAction[]>(() => [...props.contextActions, ...(props.manageTo && allowedToManage.value ? [{ label: props.manageLabel, description: props.manageDescription, icon: "i-tabler-layout-grid", to: props.manageTo }] : [])]);
const utility = computed<AccountMenuAction[]>(() => [
 { label: "我的钱包", description: "查看余额与消费记录", icon: "i-tabler-wallet", to: new URL('/wallet',accountOrigin.value).toString() },
 { label: "用户设置", description: "管理个人信息与账号安全", icon: "i-tabler-user-cog", to: accountOrigin.value },
]);
const appearance = computed<AccountMenuAppearance>(() => ({
 value: colorMode.preference === 'light' || colorMode.preference === 'dark' ? colorMode.preference : 'system',
 messages: { label: "外观", system: "跟随系统", light: "浅色", dark: "深色" },
 onChange: value => { colorMode.preference = value; },
}));
async function signIn() { await login(); }
const messages = { currentUser: "个人信息", currentSite: "当前站点：", role: "角色：", siteFeatures: "站点功能", generalFeatures: "通用功能", logout: "退出登录", actionFailed: "操作未完成，请稍后重试。" };
</script>
<template>
 <AccountMobilePanel v-if="loggedIn" :name="user?.name" :email="user?.email" :avatar-url="avatar" :site="{ label: siteName, role: allowedToManage ? '管理员' : '用户', switchAction: switchSiteAction }" :context-actions="context" :utility-actions="utility" :appearance="appearance" :logout="logout" :messages="messages" />
 <UEmpty v-else icon="i-tabler-user" title="我的" description="登录后查看个人信息与站点服务。"><template #actions><UButton icon="i-tabler-login" @click="signIn">登录</UButton></template></UEmpty>
</template>
