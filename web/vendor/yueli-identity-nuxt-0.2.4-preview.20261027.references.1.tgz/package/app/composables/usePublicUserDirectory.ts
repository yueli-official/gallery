import { computed, ref, toValue, watch, type MaybeRefOrGetter } from "vue";
import { loadPublicUserDirectory, type DirectoryUser } from "../utils/public-user-directory";

/** Client-side public profile enrichment; never stores data across sessions. */
export function usePublicUserDirectory(subjects: MaybeRefOrGetter<readonly string[]>) {
  const users = ref<Record<string, DirectoryUser>>({});
  const pending = ref(false);
  const error = ref<unknown>(null);
  const key = computed(() => [...new Set(toValue(subjects))].sort().join(","));
  let generation = 0;
  async function refresh() {
    if (typeof window === "undefined") return;
    const request = ++generation;
    pending.value = true;
    error.value = null;
    try {
      const result = await loadPublicUserDirectory(toValue(subjects), (ids) =>
        $fetch<{ items: DirectoryUser[] }>("/identity-api/api/v1/users", { query: { ids: ids.join(",") } }),
      );
      if (request === generation) users.value = result;
    } catch (failure) {
      if (request === generation) error.value = failure;
    } finally {
      if (request === generation) pending.value = false;
    }
  }
  watch(key, refresh, { immediate: true });
  return { users, pending, error, refresh };
}
