/** Reconcile shared account display state when returning from Account. */
export function observeProfileRefresh(
  target: Pick<Window, "addEventListener" | "removeEventListener">,
  document: Pick<Document, "visibilityState" | "addEventListener" | "removeEventListener">,
  refresh: () => Promise<unknown>,
) {
  let pending: Promise<unknown> | undefined;
  const reconcile = () => {
    if (document.visibilityState !== "visible" || pending) return;
    pending = Promise.resolve().then(refresh).catch(() => undefined).finally(() => { pending = undefined; });
  };
  target.addEventListener("focus", reconcile);
  document.addEventListener("visibilitychange", reconcile);
  return () => {
    target.removeEventListener("focus", reconcile);
    document.removeEventListener("visibilitychange", reconcile);
  };
}
