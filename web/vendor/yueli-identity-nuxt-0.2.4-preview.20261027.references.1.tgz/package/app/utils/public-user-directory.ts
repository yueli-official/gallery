export interface DirectoryUser {
  userKey: string;
  displayName: string;
  handle: string;
  avatar?: { mediaKey: string };
}

export async function loadPublicUserDirectory(
  subjects: readonly string[],
  fetchBatch: (ids: string[]) => Promise<{ items: DirectoryUser[] }>,
): Promise<Record<string, DirectoryUser>> {
  const ids = [...new Set(subjects.filter(Boolean))];
  const users: Record<string, DirectoryUser> = {};
  for (let offset = 0; offset < ids.length; offset += 100) {
    const response = await fetchBatch(ids.slice(offset, offset + 100));
    for (const user of response.items) users[user.userKey] = user;
  }
  return users;
}
