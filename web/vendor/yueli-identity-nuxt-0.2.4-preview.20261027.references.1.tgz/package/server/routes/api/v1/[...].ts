import { createBffHandler } from "@yueli/nuxt-runtime/server";

export default createBffHandler({
  mountPath: "/api/v1",
  resolveTarget({ event }) {
    return identityBffTarget(oidcConfig(event).downstreamBase);
  },
  credential: {
    async resolve({ event }) {
	  // Explicit PAT authentication must never fall back to a browser session.
	  // Consumers that have not opted in reject it in their API verifier.
	  const personalToken = identityPersonalTokenCredential(getHeader(event, "authorization"));
	  if (personalToken) return personalToken;
      const cfg = oidcConfig(event);
      let headers = await sessionAuthHeaders(event);
      if (!headers.authorization) {
        headers = ["GET", "HEAD", "OPTIONS"].includes(event.method)
          ? await guestSessionAuthHeaders(event, cfg.clientId, false)
          : await guestSessionAuthHeaders(event, cfg.clientId);
      }
      return identityBffCredential(headers);
    },
  },
});
