# 可选交互增强组件

原版组件保留，增强版从 `@yueli/ui/interaction` 独立导入；Nuxt 模块也自动注册组件。所有组件支持 `motion=false`，并尊重 prefers-reduced-motion。

## AI 查询入口

本页与组件 API、用途介绍和迁移说明随包版本一起生成目录。AI 先检查消费者实际安装版本，再按稳定 ID 查询，例如 `yueli-ui docs component:MotionSearchInput --section usage --project <consumer> --json`。usage 是简短介绍，api 包含源码属性和 withDefaults 默认表达式，readme 是本页，migration 是采用注意事项；不用读取整库就能判断是否适用。

外观使用原生 size/ui，动效使用 motion，行为由 enhanced、debounceMs、reserveSpace 等分别控制。系统减少动态效果会关闭动画；这不等于关闭防抖、最短加载或焦点恢复。首次采用先检查迁移说明和原页面的请求／条件挂载逻辑。

## 原组件可选增强（interaction.6 起）

已有导入无需改名：ActionFeedbackButton、CollectionActiveFilters、CollectionSelectionBar 增加 `enhanced`（默认 false）；开启后复用同一份 Motion 实现。`motion` 只控制动画，关闭后仍保留预留宽度、焦点恢复等行为。AdminTabs 直接增加 `motion`（默认 false），选中背景仍通过原生 `ui` 配置。

```vue
<ActionFeedbackButton enhanced :status="status" idle-label="保存" pending-label="保存中" success-label="已保存" error-label="重试" />
<AdminTabs v-model="tab" :items="tabs" navigation-label="内容导航" motion :ui="{ trigger: 'data-[state=active]:bg-primary/5' }" />
<CollectionActiveFilters enhanced :items="filters" @remove="removeFilter" @clear="clearFilters" />
<CollectionSelectionBar enhanced :count="selectedCount" :messages="messages" :reserve-space="false" :return-focus-to="searchElement" @clear-selection="clearSelection"><slot /></CollectionSelectionBar>
```

增强批量栏须始终挂载，以便 count=0 时恢复焦点和保留高度；不要在组件外使用 `v-if="count > 0"`。它自带区域边框和内边距，放入已有 Toolbar 时检查是否重复包裹。切换 enhanced 会替换内部 DOM，建议作为页面固定配置，不在请求期间切换。独立 Motion 导入保留，默认开启动效。

搜索、集合区域、折叠表单保留独立组件：搜索接入时删除消费者重复的防抖／model 查询监听，仅由 search 事件触发请求；集合区域只包裹内容，不包含 Toolbar 和分页；折叠表单按低频字段需要采用，校验仍由调用者负责。此候选未发布，产品仍需逐页检查行为与插槽合同后接入。

- MotionActionFeedbackButton：四个状态标签必填；沿用 ActionFeedbackButton 状态和按钮属性。预留全部文案宽度，隐藏测量副本 inert/aria-hidden，实际按钮保持同一 DOM，不改变焦点。支持 size/ui/color 等透传；测量副本自动移除 id/name/form/autofocus 等关联属性。业务请求由调用者处理。
- MotionAdminTabs：沿用 AdminTabs items、navigationLabel 与 v-model；沿用原版线形选中态，只增强颜色与指示器过渡，不拥有页面数据或内容挂载。
- MotionCollectionSelectionBar：沿用 count/messages/size/mode、事件与业务操作插槽。count=0 隐藏；reserveSpace 默认保留已经测得的占位高度，可关闭；returnFocusTo 可指定取消后的目标，否则焦点回到自身容器。
- MotionCollectionActiveFilters：items 为稳定 key/label，监听 remove/clear 更新数据；支持 size、label、clearLabel。标签退出时固定在原位置淡出，其余标签重新排列；支持换行。删除已聚焦标签后焦点移到相邻标签或容器。没有乐观改写调用者数据。

```vue
<script setup lang="ts">
import { MotionActionFeedbackButton } from "@yueli/ui/interaction";
</script>
<template>
  <MotionActionFeedbackButton
    :status="status"
    idle-label="保存"
    pending-label="正在保存"
    success-label="已保存"
    error-label="重试保存"
    @click="save"
  />
</template>
```

Nuxt UI 原生 size/ui 和品牌语义颜色保持可用。版本跟随包 SemVer，稳定组件 ID 由同源 AI catalog 生成；本版 maturity=experimental、lifecycle=active。现有产品无需升级或替换。本次仅本地候选，未发布。

## MotionSearchInput

独立导入的增强搜索输入。必填 label 和 clearLabel；v-model 是已完成组词的文本，search 事件是 trim 后的最终查询。停止输入 debounceMs（默认 300ms）后发出一次 search，Enter 可立即提交／重试，清空立即发出空查询并恢复输入焦点。输入法组词期间既不更新公共 model 也不发查询；组件卸载或禁用时清除待发送任务。外部 model 更新取消待发送任务，不自动查询，由调用者拥有路由／请求状态。

支持 Nuxt UI 原生 size/ui 与普通 input 属性透传，loading 由调用者提供，只用于原位指示；disabled/readonly 不可清空或提交。组件不执行请求、缓存数据或宣布请求成功；异步消费者必须取消旧请求或用请求序号忽略过期结果。motion 控制清空按钮淡入淡出；原生 loading 指示器沿用 Nuxt UI。

```vue
<MotionSearchInput v-model="query" label="搜索文章" clear-label="清空搜索" :loading="pending" @search="loadArticles" />
```

外观与动效分别配置：size/ui 属于外观，motion 属于动效，debounceMs 属于查询行为。搜索保持独立行为入口；已有按钮、Tabs、筛选标签和批量栏支持上文所列可选设置。

## MotionCollectionRegion

只包裹集合内容区域，Toolbar、筛选与分页由调用方放在区域外。label 和 loadingLabel 必填；loading 表达真实请求，state 选择 ready/empty/error。默认 Slot 渲染内容；loading Slot 提供与实际行结构一致的骨架（缺省为三行），empty/error Slot 必须提供对应恢复入口。

复用 useMinimumLoading，骨架状态至少保留 500ms；motion=false 或系统减少动态效果时仅取消过渡，不取消最短加载保障。reserveSpace 默认在加载和过渡期间保留已测得的内容高度，可关闭。退出节点立即 inert；若焦点位于退出区域，转移到区域容器，不抢区域外的搜索和工具栏焦点。初次 SSR 可直接渲染 loading 状态。状态切换会卸载当前 Slot，不适合包裹需要保留编辑草稿的表单。

组件不发请求、不缓存行、不拥有分页、错误文案或请求取消。调用者须保持 loading 与请求一致，并忽略旧请求返回；ready 中的数据更新不会自动动画，避免逐行干扰。

导航样式配置：原版 AdminTabs 与 MotionAdminTabs 均支持 Nuxt UI 原生 ui Slot 配置；例如 `:ui="{ trigger: 'data-[state=active]:bg-primary/5' }"` 添加选中背景。ui 只配置外观，motion 只配置过渡，默认外观保持不变。

## MotionDisclosure

复用 UCollapsible 的高度过渡和键盘语义，用于低频附加字段，不用于隐藏关键任务。label 必填，v-model:open 可控；invalid 从 false 变为 true 时展开（初始 true 也展开），不自动聚焦或持有校验。调用者仍拥有验证、提交和错误文案；校验在关闭时也应覆盖隐藏字段，提交失败时通过 invalid 打开错误分区。invalid 清除不会自动关闭，用户仍可主动关闭。

内容保持挂载以保留本地输入 DOM；关闭与退出内容 inert/aria-hidden，不可聚焦。若收起时焦点仍在内容内，则返回触发器；区域外焦点不被抢。支持 disabled、原生 size、Collapsible ui 和 Button buttonUi。motion 控制原生开合动画与箭头过渡，系统减少动态效果时关闭动效。持久内容不代表持久化存储，关闭时不会清理或重置草稿。
