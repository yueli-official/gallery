<script setup lang="ts">
import type { TabsProps } from "@nuxt/ui";
import AdminTabs, {
  type AdminTabItem,
} from "../../admin/components/AdminTabs.vue";
withDefaults(
  defineProps<{
    items: readonly AdminTabItem[];
    navigationLabel: string;
    motion?: boolean;
    ui?: TabsProps["ui"];
  }>(),
  { motion: true },
);
const active = defineModel<string>({ required: true });
</script>
<template>
  <div class="motion-tabs min-w-0" :data-motion="motion">
    <AdminTabs
      v-model="active"
      :items="items"
      :navigation-label="navigationLabel"
      :ui="ui"
      :motion="motion"
    />
  </div>
</template>
