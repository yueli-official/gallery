<script setup lang="ts">
import { ref, watch, nextTick, onBeforeUpdate } from "vue";
import type { ButtonProps } from "@nuxt/ui";
import type { CollectionActiveFilter } from "../../collection/components/CollectionActiveFilters.vue";
const props = withDefaults(
  defineProps<{
    items: readonly CollectionActiveFilter[];
    size?: ButtonProps["size"];
    label?: string;
    clearLabel?: string;
    motion?: boolean;
  }>(),
  { label: "已筛选", clearLabel: "清除全部", motion: true },
);
const emit = defineEmits<{ remove: [key: string]; clear: [] }>();
const root = ref<HTMLElement>();
const positions = new WeakMap<
  Element,
  { left: number; top: number; width: number; height: number }
>();
// Capture before Vue removes siblings or the flex layout changes.
onBeforeUpdate(() => {
  root.value
    ?.querySelectorAll<HTMLElement>("[data-filter-key]:not([inert])")
    .forEach((element) => {
      positions.set(element, {
        left: element.offsetLeft,
        top: element.offsetTop,
        width: element.offsetWidth,
        height: element.offsetHeight,
      });
    });
});
function beforeLeave(element: Element) {
  element.setAttribute("inert", "");
  const position = positions.get(element);
  if (!position) return;
  Object.assign((element as HTMLElement).style, {
    position: "absolute",
    left: `${position.left}px`,
    top: `${position.top}px`,
    width: `${position.width}px`,
    height: `${position.height}px`,
  });
}
function resetPosition(element: Element) {
  element.removeAttribute("inert");
  for (const property of ["position", "left", "top", "width", "height"])
    (element as HTMLElement).style.removeProperty(property);
}
let focusIndex: number | undefined;
function remove(key: string, event: MouseEvent) {
  if ((event.currentTarget as HTMLElement)?.contains(document.activeElement))
    focusIndex = props.items.findIndex((item) => item.key === key);
  emit("remove", key);
}
function clear(event: MouseEvent) {
  if ((event.currentTarget as HTMLElement)?.contains(document.activeElement))
    focusIndex = 0;
  emit("clear");
}
watch(
  () => props.items.map((item) => item.key).join("\0"),
  async () => {
    if (focusIndex === undefined) return;
    await nextTick();
    const buttons = root.value?.querySelectorAll<HTMLElement>(
      "[data-filter-key]:not([inert])",
    );
    (buttons?.[Math.min(focusIndex, buttons.length - 1)] ?? root.value)?.focus({
      preventScroll: true,
    });
    focusIndex = undefined;
  },
  { flush: "post" },
);
</script>
<template>
  <div
    ref="root"
    tabindex="-1"
    :aria-label="label"
    class="motion-filters flex min-w-0 flex-wrap items-center gap-2 text-xs"
    :data-motion="motion"
  >
    <span v-if="items.length" class="text-muted">{{ label }}</span>
    <TransitionGroup
      :name="motion ? 'filter' : undefined"
      @before-leave="beforeLeave"
      @before-enter="resetPosition"
      @leave-cancelled="resetPosition"
      @after-leave="resetPosition"
    >
      <UButton
        v-for="item in items"
        :key="item.key"
        :data-filter-key="item.key"
        :size="size"
        :label="item.label"
        color="neutral"
        variant="soft"
        trailing-icon="i-tabler-x"
        @click="remove(item.key, $event)"
      />
    </TransitionGroup>
    <UButton
      v-if="items.length"
      :label="clearLabel"
      :size="size"
      color="neutral"
      variant="link"
      @click="clear"
    />
  </div>
</template>
<style scoped>
.filter-enter-active,
.filter-leave-active,
.filter-move {
  transition:
    opacity 180ms ease-out,
    transform 180ms ease-out;
}
.filter-enter-from {
  opacity: 0;
  transform: scale(0.96);
}
.filter-leave-to {
  opacity: 0;
}
.filter-leave-active {
  position: absolute;
  pointer-events: none;
  /* TransitionGroup may also apply a move transform to an exiting wrapped item. */
  transform: none !important;
  transition: opacity 180ms ease-out;
}
.motion-filters {
  position: relative;
}
@media (prefers-reduced-motion: reduce) {
  .filter-enter-active,
  .filter-leave-active,
  .filter-move {
    transition: none;
  }
}
</style>
