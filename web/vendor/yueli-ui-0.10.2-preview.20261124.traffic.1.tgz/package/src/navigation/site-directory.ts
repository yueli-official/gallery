export type SiteLauncherIconKind =
  | "home" | "book" | "package" | "code" | "tv" | "account"
  | "gallery" | "blog" | "compass";

export interface SiteLauncherItem {
  id: string;
  name: string;
  url: string;
  icon: SiteLauncherIconKind;
}

export const yueliSites = [
  { id: "www", name: "官网", url: "https://www.yuelili.com/", icon: "home" },
  { id: "docs", name: "文档", url: "https://docs.yuelili.com/", icon: "book" },
  { id: "apps", name: "软件", url: "https://apps.yuelili.com/", icon: "package" },
  { id: "paste", name: "代码分享", url: "https://paste.yuelili.com/", icon: "code" },
  { id: "tv", name: "影视", url: "https://tv.yuelili.com/", icon: "tv" },
  { id: "account", name: "用户中心", url: "https://account.yuelili.com/", icon: "account" },
  { id: "gallery", name: "图库", url: "https://gallery.yuelili.com/", icon: "gallery" },
  { id: "blog", name: "AE博客", url: "https://cg.yuelili.com/", icon: "blog" },
  { id: "nav", name: "导航", url: "https://nav.yuelili.com/", icon: "compass" },
] as const satisfies readonly SiteLauncherItem[];
