import { addTemplate, createResolver, resolvePath } from "@nuxt/kit";
import type { Nuxt } from "nuxt/schema";
import { createRequire } from "node:module";
import { resolve } from "node:path";
import { verifyConsumerStyles } from "./style-contract.mjs";

/** One compilation graph keeps product tokens, plugins and component defaults together. */
export function installComponentStyles(nuxt: Nuxt) {
  const resolver = createResolver(import.meta.url);
  const consumerRequire = createRequire(
    resolve(nuxt.options.rootDir, "package.json"),
  );
  const frameworkStyles = [
    consumerRequire.resolve("tailwindcss/index.css"),
    consumerRequire.resolve("@nuxt/ui/runtime/index.css"),
  ];
  const typography = createRequire(import.meta.url).resolve(
    "@tailwindcss/typography",
  );
  nuxt.hook("modules:done", async () => {
    await verifyConsumerStyles(nuxt.options.rootDir, {
      cssEntries: nuxt.options.css,
    });
    const styles = await Promise.all(
      [...new Set(nuxt.options.css)].map((path) =>
        resolvePath(path, {
          cwd: nuxt.options.rootDir,
          alias: nuxt.options.alias,
        }),
      ),
    );
    const template = addTemplate({
      filename: "yueli-styles.css",
      write: true,
      getContents: () =>
        [
          `@plugin ${JSON.stringify(typography.replaceAll("\\", "/"))};`,
          ...[
            ...frameworkStyles,
            resolver.resolve("./theme.css"),
            ...styles,
          ].map(
            (path) => `@import ${JSON.stringify(path.replaceAll("\\", "/"))};`,
          ),
          `@source ${JSON.stringify(resolver.resolve(".").replaceAll("\\", "/"))};`,
        ].join("\n"),
    });
    nuxt.options.css = [template.dst];
  });
}
