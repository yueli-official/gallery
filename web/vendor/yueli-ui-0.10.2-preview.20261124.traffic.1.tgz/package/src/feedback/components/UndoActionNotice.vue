<script setup lang="ts">
import { onMounted, onBeforeUnmount, ref, watch } from 'vue';
import UButton from '@nuxt/ui/components/Button.vue';
import type { ButtonProps } from '@nuxt/ui';
const props=withDefaults(defineProps<{
  message: string;
  undo: () => Promise<void> | void;
  messages: { undo: string; pending: string; dismiss: string; failed: string };
  /** 0 keeps the action until dismissed; hover/focus pauses expiry. */
  durationMs?: number;
  size?: ButtonProps['size'];
}>(), {durationMs:8000});
const emit=defineEmits<{undone: []; dismissed: []; expired: []; undoError: [error:unknown]}>();
const busy=ref(false), failed=ref(false), visible=ref(true);
let timer:ReturnType<typeof setTimeout>|undefined;
let remaining=0, deadline=0, mounted=false, hovered=false, focused=false;
function pause(){if(timer!==undefined){clearTimeout(timer);timer=undefined;remaining=Math.max(0,deadline-Date.now());}}
function resume(){
  if(!mounted || !visible.value || busy.value || failed.value || hovered || focused || !props.durationMs || timer!==undefined)return;
  deadline=Date.now()+remaining;
  timer=setTimeout(()=>{timer=undefined;visible.value=false;emit('expired');},remaining);
}
function reset(){pause();remaining=Number.isFinite(props.durationMs)?Math.max(0,props.durationMs):8000;resume();}
watch(()=>props.durationMs,reset);
onMounted(()=>{mounted=true;reset();});
onBeforeUnmount(()=>{mounted=false;pause();});
function hover(value:boolean){hovered=value;if(value)pause();else resume();}
function focus(event:FocusEvent){focused=event.type==='focusin'||!!(event.currentTarget as HTMLElement).contains(event.relatedTarget as Node|null);if(focused)pause();else resume();}
async function restore(){
  if(busy.value||!visible.value)return;
  pause();busy.value=true;failed.value=false;
  try{await props.undo();if(mounted){visible.value=false;emit('undone');}}
  catch(error){if(mounted){failed.value=true;emit('undoError',error);}}
  finally{busy.value=false;resume();}
}
function dismiss(){if(busy.value)return;pause();visible.value=false;emit('dismissed');}
</script>
<template>
 <section v-if="visible" class="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-default bg-elevated p-3" data-undo-notice @mouseenter="hover(true)" @mouseleave="hover(false)" @focusin="focus" @focusout="focus">
  <p class="min-w-0 text-sm" role="status">{{failed ? messages.failed : message}}</p>
  <div class="flex shrink-0 items-center gap-2"><UButton :label="busy?messages.pending:messages.undo" icon="i-tabler-arrow-back-up" :loading="busy" :disabled="busy" :size="size" color="neutral" variant="soft" @click="restore"/><UButton :aria-label="messages.dismiss" icon="i-tabler-x" :disabled="busy" :size="size" color="neutral" variant="ghost" @click="dismiss"/></div>
 </section>
</template>
