<script setup lang="ts">
import { useToast } from "@nuxt/ui/composables";
import { computed } from "vue";
import type { NuxtToastInput } from "../notice";
import FeedbackToastViewport from "../internal/FeedbackToastViewport.vue";

const toast = useToast();
const props = withDefaults(
  defineProps<{
    closeLabel?: string;
    actionPendingLabel?: string;
    actionFailureLabel?: string;
  }>(),
  {
    closeLabel: "Close notification",
    actionPendingLabel: "Working…",
    actionFailureLabel: "Action failed. Try again.",
  },
);
const notices = computed(
  () => toast.toasts.value as unknown as NuxtToastInput[],
);
</script>

<template>
  <Teleport to="body">
    <FeedbackToastViewport
      v-bind="props"
      :notices="notices"
      @remove="toast.remove"
    />
  </Teleport>
</template>
