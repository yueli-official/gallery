<script setup lang="ts">
import { computed } from "vue";
import ActionFeedbackButtonBase from "../ActionFeedbackButtonBase.vue";
import MotionActionFeedbackButton from "../../interaction/components/MotionActionFeedbackButton.vue";
import type { MessageResolver } from "../../messages";
import type { ActionFeedbackStatus } from "../action";

type ButtonColor =
  | "primary"
  | "secondary"
  | "success"
  | "info"
  | "warning"
  | "error"
  | "neutral";
type ButtonVariant = "solid" | "outline" | "soft" | "subtle" | "ghost" | "link";

defineOptions({ inheritAttrs: false });

const props = withDefaults(
  defineProps<{
    enhanced?: boolean;
    motion?: boolean;
    status?: ActionFeedbackStatus;
    idleLabel?: string;
    pendingLabel?: string;
    successLabel?: string;
    errorLabel?: string;
    resolveMessage?: MessageResolver;
    idleIcon?: string;
    pendingIcon?: string;
    successIcon?: string;
    errorIcon?: string;
    color?: ButtonColor;
    successColor?: ButtonColor;
    errorColor?: ButtonColor;
    variant?: ButtonVariant;
    successVariant?: ButtonVariant;
    errorVariant?: ButtonVariant;
  }>(),
  {
    enhanced: false,
    motion: true,
    status: "idle",
    idleIcon: "i-tabler-device-floppy",
    pendingIcon: "i-tabler-loader-2",
    successIcon: "i-tabler-check",
    errorIcon: "i-tabler-alert-circle",
    color: "primary",
    successColor: "success",
    errorColor: "error",
    variant: "solid",
    successVariant: "solid",
    errorVariant: "soft",
  },
);

const emit = defineEmits<{ click: [event: MouseEvent] }>();

const baseProps = computed(() => {
  const { enhanced, motion, ...rest } = props;
  return rest;
});
const labels = computed(
  () =>
    Object.fromEntries(
      (["idle", "pending", "success", "error"] as const).map((state) => [
        `${state}Label`,
        props[`${state}Label`] ??
          props.resolveMessage?.({
            key: `foundation.feedback.action.${state}`,
          }) ??
          `foundation.feedback.action.${state}`,
      ]),
    ) as Record<
      "idleLabel" | "pendingLabel" | "successLabel" | "errorLabel",
      string
    >,
);
</script>
<template>
  <MotionActionFeedbackButton
    v-if="enhanced"
    v-bind="{ ...$attrs, ...baseProps, ...labels, motion }"
    @click="emit('click', $event)"
  />
  <ActionFeedbackButtonBase
    v-else
    v-bind="{ ...$attrs, ...baseProps }"
    @click="emit('click', $event)"
  />
</template>
