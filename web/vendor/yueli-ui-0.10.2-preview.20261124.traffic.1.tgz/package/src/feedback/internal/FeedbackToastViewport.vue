<script setup lang="ts">
import "../feedback-surface.css";
import {
  computed,
  nextTick,
  onBeforeUnmount,
  onMounted,
  reactive,
  ref,
  shallowReactive,
  watch,
} from "vue";
import {
  normalizeNuxtToastInput,
  type FeedbackNoticeAction,
  type NuxtToastInput,
} from "../notice";

// Internal renderer: global queue and repository Lab share gestures and lifetime.
const props = withDefaults(
  defineProps<{
    notices: readonly NuxtToastInput[];
    closeLabel?: string;
    actionPendingLabel?: string;
    actionFailureLabel?: string;
    motion?: boolean;
    duration?: number;
  }>(),
  {
    closeLabel: "Close notification",
    actionPendingLabel: "Working…",
    actionFailureLabel: "Action failed. Try again.",
    motion: true,
    duration: 180,
  },
);
const emit = defineEmits<{
  remove: [id: string | number];
  pause: [id: string | number];
  resume: [id: string | number];
}>();
type Notice = ReturnType<typeof normalizeNuxtToastInput>;
type Id = Notice["id"];
const notices = computed(() =>
  props.notices
    .filter((n) => n.open !== false)
    .slice(-3)
    .map(normalizeNuxtToastInput),
);
const retained = shallowReactive(new Map<Id, Notice>());
const displayed = computed(() => [...retained.values()]);
const closing = reactive(new Set<Id>());
const busy = reactive(new Set<Id>());
const failed = reactive(new Set<Id>());
const elements = new Map<Id, HTMLElement>();
const animations = new Map<Id, Animation>();
const timers = new Map<Id, ReturnType<typeof setTimeout>>();
const signatures = new Map<Id, string>();
const generations = new Map<Id, number>();
let generation = 0;
const hovered = new Set<Id>();
const focused = new Set<Id>();
const drag = {
  id: undefined as Id | undefined,
  pointer: -1,
  startX: 0,
  startY: 0,
  baseX: 0,
  opacity: 1,
  x: 0,
  width: 0,
  horizontal: false,
};
let mounted = true;
const reduced = ref(false);
let media: MediaQueryList | undefined;
function syncReduced() {
  reduced.value = media?.matches ?? false;
}
onMounted(() => {
  media = window.matchMedia("(prefers-reduced-motion: reduce)");
  syncReduced();
  media.addEventListener("change", syncReduced);
});
function clearTimer(id: Id) {
  const timer = timers.get(id);
  if (timer) clearTimeout(timer);
  timers.delete(id);
}
function schedule(notice: Notice) {
  clearTimer(notice.id);
  const duration = notice.duration;
  if (
    duration <= 0 ||
    closing.has(notice.id) ||
    hovered.has(notice.id) ||
    focused.has(notice.id) ||
    busy.has(notice.id) ||
    failed.has(notice.id) ||
    drag.id === notice.id
  )
    return;
  timers.set(
    notice.id,
    setTimeout(() => dismiss(notice.id), duration),
  );
}
function forget(id: Id) {
  clearTimer(id);
  retained.delete(id);
  closing.delete(id);
  busy.delete(id);
  failed.delete(id);
  hovered.delete(id);
  focused.delete(id);
  signatures.delete(id);
  generations.delete(id);
}
function animate(id: Id, opening: boolean) {
  const element = elements.get(id);
  if (!element) {
    if (!opening) forget(id);
    return;
  }
  // Capture before cancelling, including a partially completed close or rebound.
  const style = getComputedStyle(element);
  const from = { opacity: style.opacity, transform: style.transform };
  const fromX = new DOMMatrix(from.transform).m41;
  animations.get(id)?.cancel();
  animations.delete(id);
  const to = {
    opacity: opening ? "1" : "0",
    // Exit follows the current horizontal direction; there is no vertical step.
    transform: opening
      ? "none"
      : `translateX(calc(${fromX}px + var(--spacing) * ${(Math.sign(fromX) || 1) * 3}))`,
  };
  const finish = () => {
    if (opening) {
      element.style.opacity = "1";
      element.style.transform = "none";
    } else forget(id);
  };
  if (!props.motion || reduced.value || props.duration <= 0) {
    finish();
    return;
  }
  const animation = element.animate([from, to], {
    duration: opening ? props.duration : props.duration * 0.7,
    easing: opening
      ? "cubic-bezier(0.16, 1, 0.3, 1)"
      : "cubic-bezier(0.4, 0, 1, 1)",
    fill: "both",
  });
  animations.set(id, animation);
  animation.onfinish = () => {
    if (animations.get(id) !== animation) return;
    animations.delete(id);
    finish();
    animation.cancel();
  };
}
function close(id: Id) {
  if (closing.has(id)) return;
  closing.add(id);
  clearTimer(id);
  animate(id, false);
}
function dismiss(id: Id) {
  close(id);
  emit("remove", id);
}
watch(
  notices,
  (current) => {
    const visible = new Set(current.map((n) => n.id));
    for (const id of retained.keys()) if (!visible.has(id)) close(id);
    for (const notice of current) {
      const entering = !retained.has(notice.id) || closing.has(notice.id);
      if (entering) {
        busy.delete(notice.id);
        failed.delete(notice.id);
      }
      retained.set(notice.id, notice);
      closing.delete(notice.id);
      const signature = `${notice.duration}:${notice._duplicate ?? 0}`;
      if (entering || signatures.get(notice.id) !== signature) {
        signatures.set(notice.id, signature);
        if (entering) generations.set(notice.id, ++generation);
        schedule(notice);
      }
      if (entering)
        nextTick(() => {
          if (mounted && !closing.has(notice.id) && retained.has(notice.id))
            animate(notice.id, true);
        });
    }
  },
  { immediate: true },
);
watch(
  () => props.motion && !reduced.value,
  (enabled) => {
    if (enabled) return;
    for (const [id, animation] of animations) {
      animation.cancel();
      animations.delete(id);
      if (closing.has(id)) forget(id);
      else {
        const element = elements.get(id);
        if (element) {
          element.style.opacity = "1";
          element.style.transform = "none";
        }
      }
    }
  },
);
function pause(notice: Notice, reason: "hover" | "focus") {
  (reason === "hover" ? hovered : focused).add(notice.id);
  clearTimer(notice.id);
  emit("pause", notice.id);
}
function resume(notice: Notice, reason: "hover" | "focus", event?: FocusEvent) {
  if (
    event?.relatedTarget instanceof Node &&
    (event.currentTarget as HTMLElement)?.contains(event.relatedTarget)
  )
    return;
  (reason === "hover" ? hovered : focused).delete(notice.id);
  if (!hovered.has(notice.id) && !focused.has(notice.id))
    emit("resume", notice.id);
  schedule(notice);
}
async function runAction(
  notice: Notice,
  action: FeedbackNoticeAction,
  event: MouseEvent,
) {
  if (busy.has(notice.id)) return;
  const currentGeneration = generations.get(notice.id);
  const current = () =>
    mounted &&
    generations.get(notice.id) === currentGeneration &&
    !closing.has(notice.id);
  busy.add(notice.id);
  failed.delete(notice.id);
  clearTimer(notice.id);
  try {
    await action.onClick(event);
    if (current()) dismiss(notice.id);
  } catch {
    if (current()) failed.add(notice.id);
  } finally {
    if (current()) busy.delete(notice.id);
  }
}
function dragStart(notice: Notice, event: PointerEvent) {
  if (
    !event.isPrimary ||
    event.button !== 0 ||
    (event.target as HTMLElement).closest("button,a,input") ||
    busy.has(notice.id) ||
    closing.has(notice.id)
  )
    return;
  const element = event.currentTarget as HTMLElement;
  const style = getComputedStyle(element);
  Object.assign(drag, {
    id: notice.id,
    pointer: event.pointerId,
    startX: event.clientX,
    startY: event.clientY,
    baseX: new DOMMatrix(style.transform).m41,
    opacity: Number(style.opacity),
    x: 0,
    width: element.getBoundingClientRect().width,
    horizontal: false,
  });
  element.setPointerCapture(event.pointerId);
  clearTimer(notice.id);
}
function dragMove(event: PointerEvent) {
  if (drag.pointer !== event.pointerId) return;
  const dx = event.clientX - drag.startX,
    dy = event.clientY - drag.startY;
  if (
    !drag.horizontal &&
    Math.abs(dx) > 8 &&
    Math.abs(dx) > Math.abs(dy) * 1.2
  ) {
    drag.horizontal = true;
    const style = getComputedStyle(event.currentTarget as HTMLElement);
    drag.baseX = new DOMMatrix(style.transform).m41;
    drag.opacity = Number(style.opacity);
    animations.get(drag.id!)?.cancel();
    animations.delete(drag.id!);
  }
  if (drag.horizontal) {
    drag.x = drag.baseX + dx;
    const element = event.currentTarget as HTMLElement;
    element.dataset.dragging = "true";
    element.style.transform = `translateX(${drag.x}px)`;
    element.style.opacity = String(
      drag.opacity *
        (1 - Math.min(Math.abs(drag.x) / Math.max(drag.width, 1), 0.7)),
    );
    event.preventDefault();
  }
}
function dragEnd(notice: Notice, event: PointerEvent, cancelled = false) {
  if (drag.pointer !== event.pointerId) return;
  const shouldDismiss =
    !cancelled &&
    drag.horizontal &&
    Math.abs(drag.x) >= Math.min(96, drag.width * 0.3);
  const element = event.currentTarget as HTMLElement;
  if (element.hasPointerCapture(event.pointerId))
    element.releasePointerCapture(event.pointerId);
  delete element.dataset.dragging;
  Object.assign(drag, { id: undefined, pointer: -1, x: 0, horizontal: false });
  if (shouldDismiss) dismiss(notice.id);
  else {
    animate(notice.id, true);
    schedule(notice);
  }
}
function setElement(id: Id, element: unknown) {
  if (element instanceof HTMLElement) elements.set(id, element);
  else elements.delete(id);
}
onBeforeUnmount(() => {
  mounted = false;
  media?.removeEventListener("change", syncReduced);
  for (const id of timers.keys()) clearTimer(id);
  for (const animation of animations.values()) animation.cancel();
  animations.clear();
});
</script>

<template>
  <section class="yueli-toast-region" aria-label="通知">
    <div
      v-for="notice in displayed"
      :key="notice.id"
      :ref="(el) => setElement(notice.id, el)"
      class="yueli-toast-notice yueli-feedback-surface shadow-lg"
      :data-tone="notice.color"
      :data-state="closing.has(notice.id) ? 'closed' : 'open'"
      :aria-hidden="closing.has(notice.id) || undefined"
      :inert="closing.has(notice.id)"
      :role="
        notice.type === 'foreground' ||
        notice.color === 'error' ||
        notice.color === 'warning'
          ? 'alert'
          : 'status'
      "
      data-yueli-toast
      @pointerdown="dragStart(notice, $event)"
      @pointermove="dragMove"
      @pointerup="dragEnd(notice, $event)"
      @pointercancel="dragEnd(notice, $event, true)"
      @lostpointercapture="dragEnd(notice, $event, true)"
      @keydown.esc.stop="dismiss(notice.id)"
      @mouseenter="pause(notice, 'hover')"
      @mouseleave="resume(notice, 'hover')"
      @focusin="pause(notice, 'focus')"
      @focusout="resume(notice, 'focus', $event)"
    >
      <span
        v-if="notice.icon"
        class="yueli-toast-icon yueli-feedback-icon"
        aria-hidden="true"
      >
        <UIcon :name="notice.icon" class="size-5" />
      </span>
      <div class="min-w-0 flex-1">
        <p
          v-if="notice.title"
          class="line-clamp-2 text-sm font-semibold leading-5 text-highlighted"
        >
          {{ notice.title }}
        </p>
        <p
          v-if="notice.description"
          class="mt-0.5 line-clamp-2 text-xs leading-5 text-muted"
        >
          {{ notice.description }}
        </p>
        <div
          v-if="notice.actions?.length"
          class="mt-3 flex flex-wrap gap-2"
          data-toast-actions
        >
          <UButton
            v-for="(action, index) in notice.actions"
            :key="index"
            :label="
              busy.has(notice.id) ? props.actionPendingLabel : action.label
            "
            :icon="action.icon"
            :loading="busy.has(notice.id)"
            :disabled="busy.has(notice.id)"
            color="neutral"
            variant="outline"
            size="xs"
            @click="runAction(notice, action, $event)"
          />
        </div>
        <p
          v-if="failed.has(notice.id)"
          class="mt-2 text-xs text-error"
          role="alert"
        >
          {{ props.actionFailureLabel }}
        </p>
      </div>
      <UButton
        icon="i-tabler-x"
        color="neutral"
        variant="ghost"
        size="xs"
        square
        :aria-label="props.closeLabel"
        class="-mr-1 -mt-1 shrink-0 text-dimmed"
        @click="dismiss(notice.id)"
      />
    </div>
  </section>
</template>

<style scoped>
.yueli-toast-region {
  position: fixed;
  z-index: 110;
  bottom: calc(1rem + var(--yueli-mobile-bottom-space, 0rem));
  right: 1rem;
  display: flex;
  width: min(22rem, calc(100vw - 2rem));
  flex-direction: column;
  gap: 0.5rem;
  pointer-events: none;
}
.yueli-toast-notice {
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
  padding: 0.75rem;
  border-radius: 1rem;
  box-shadow: var(--shadow-toast, var(--shadow-lg));
  touch-action: pan-y;
  opacity: 0;
  transform: translateX(calc(var(--spacing) * 4));
  pointer-events: auto;
}
.yueli-toast-region[aria-hidden="true"] .yueli-toast-notice,
.yueli-toast-notice[data-state="closed"] {
  pointer-events: none;
}
.yueli-toast-icon {
  width: 2rem;
  height: 2rem;
  padding: 0.375rem;
  border-radius: 0.625rem;
  flex: none;
  color: var(--ui-text-highlighted);
}
.yueli-toast-notice[data-tone="error"] .yueli-toast-icon {
  color: var(--ui-error);
}
.yueli-toast-notice[data-tone="warning"] .yueli-toast-icon {
  color: var(--ui-warning);
}
.yueli-toast-notice[data-tone="success"] .yueli-toast-icon {
  color: var(--ui-success);
}
.yueli-toast-notice[data-tone="info"] .yueli-toast-icon {
  color: var(--ui-info);
}
.yueli-toast-notice[data-dragging="true"] {
  user-select: none;
}
</style>
