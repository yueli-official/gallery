# 共享反馈（feedback.2）

本次从 Yotta 的 useAppToast.ts / InlineStatus.vue 迁入反馈策略与布局，不复制桌面 RPC、语言包或第二套 Toast store。

- 浮动通知有 info/success/warning/error 四个便捷方法，底层也接受 neutral。
- InlineStatus 有五种 tone；variant 为 plain（默认，无面板）或 soft（浅色背景、边框）。标题与正文分行，actions 插槽位于下方，关闭按钮始终显示，点击先自隐藏再发送 dismiss，调用方可用 dismissLabel/@dismiss 配合清除业务状态。旧 dismissible 参数保留但不再隐藏关闭按钮。
- ActionFeedbackButton 继续使用既有 idle/pending/success/error，文案由产品提供；批量应用完成用“已应用”，不重复弹成功 Toast。
- Toast 全部可关闭，无进度条，最多三条；错误强制 duration=0，其他默认3200ms。鼠标悬停与键盘焦点暂停，新增其他通知不重置既有计时。左右滑动超过阈值关闭，短拖动回弹，垂直触摸交给页面滚动；键盘聚焦关闭按钮后也可按 Escape。
- Nuxt 根保留 UApp :toaster="null" 与唯一 FeedbackToastRegion。局部上传约束紧邻上传区，不能使用大块实色错误条。

迁移：旧 InlineStatus 使用方无需新增参数；需要浅色区域才配置 soft。原先依赖 InlineStatus 无关闭按钮、错误自动消失或 close=false 的调用方需接受统一持久/可关闭策略。组件元数据、配置和本文随包一起提供，可通过 @yueli/ui/discovery 查询；源码预览不代表生产消费者已升级。

## 操作与视觉

Toast 与 soft 区域提示共用反馈表面：浅色语义背景、语义边框、图标浅底。Toast 另外使用浮层阴影；简洁 plain 不带面板。长正文自动换行，浮动正文最多两行；手机端保留关闭区域。

可通过 actions: [{label, icon?, onClick}] 提供可选撤销/重试。异步执行防重复，成功关闭，失败保留消息与操作，并用 actionFailureLabel 显示可恢复反馈；执行中使用 actionPendingLabel。消费方拥有实际撤销事务、权限和状态；关闭提示不会取消已经发出的业务操作。必要确认仍使用 Modal，禁止把必选任务藏在会自动消失的 Toast 中。

参考：[PrimeVue Toast](https://primevue.dev/toast/) 的浅色语义、自定义操作与暂停；[shadcn Toast](https://ui.shadcn.com/docs/components/base/toast) 的浮层与操作；[Radix Toast](https://www.radix-ui.com/primitives/docs/components/toast) 的 swipe/关闭/键盘交互。仍使用 Nuxt UI store 和按钮，不引入其他 UI 框架。

关闭生命周期：@dismiss 优先清除对应产品消息；复用同一位置展示另一条消息时，以消息 ID 作为 Vue key 或清除后重新挂载，避免沿用已关闭实例。
