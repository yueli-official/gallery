# 可撤销操作

`UndoActionNotice` 从 `@yueli/ui/feedback/pattern` 导入，Nuxt自动注册YUndoActionNotice。适合可逆的归档/移除：消费者先完成实际操作，再为此次操作挂载一个提示。

```vue
<UndoActionNotice v-if="operation" :key="operation.id" :message="operation.message"
  :undo="operation.restore" :messages="messages" @undone="operation=null"
  @expired="operation=null" @dismissed="operation=null" @undo-error="reportError" />
```

message为成功操作摘要，messages包含undo/pending/dismiss/failed；undo为该次操作的同步或异步恢复函数。默认durationMs=8000，0保持直到关闭；悬停或键盘焦点暂停剩余时间，移出后继续。pending阻止重复撤销/关闭，失败保留按钮和提示，不自动到期，原地重试；成功仅发一次undone。size直接使用Nuxt UI。

expired/dismissed只表示提示结束，不执行删除或提交事务；永久删除、权限检查、冲突解决、服务器回收站及恢复幂等由消费者拥有。异步恢复结果由消费者确认，不能未成功就返回resolve。多个操作分别保留实例/恢复快照，不将后一次恢复覆盖前一次。卸载会清除计时并停止组件事件，不取消已执行的业务函数；如需取消，在Adapter使用AbortSignal。计时不是安全期限，后台标签页调度可能延迟。
