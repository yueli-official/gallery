/** Inclusive ISO calendar dates; no implicit timezone or instant conversion. */
export interface CalendarDateRange { start?: string; end?: string }
export interface CalendarDatePreset { id: string; label: string; value: CalendarDateRange; disabled?: boolean }
export function calendarDate(value?: string): string | undefined {
  if (!value) return undefined;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || value < "0001-01-01") throw new Error("请输入有效日期");
  const date = new Date(`${value}T00:00:00Z`);
  if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0,10) !== value) throw new Error("请输入有效日期");
  return value;
}
export function parseCalendarDateRange(start?: string, end?: string): CalendarDateRange {
  const value = {start:calendarDate(start),end:calendarDate(end)};
  if (value.start && value.end && value.start > value.end) throw new Error("开始日期不能晚于结束日期");
  return value;
}
/** Reference day is supplied by consumer in their business timezone. Includes today. */
export function recentCalendarDays(today: string, days: number): CalendarDateRange {
  calendarDate(today);
  if (!today || !Number.isSafeInteger(days) || days < 1) throw new Error("天数必须为正整数");
  const date = new Date(`${today}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() - days + 1);
  return parseCalendarDateRange(date.toISOString().slice(0,10),today);
}
