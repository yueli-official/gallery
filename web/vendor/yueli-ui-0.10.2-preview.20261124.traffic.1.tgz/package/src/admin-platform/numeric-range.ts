export interface NumericRange {
  min?: number;
  max?: number;
}
export interface NumericRangePreset {
  readonly id: string;
  readonly label: string;
  readonly value: NumericRange;
  readonly disabled?: boolean;
}
export function parseNumericRange(
  min: string | number | undefined,
  max: string | number | undefined,
  options: { floor?: number; ceiling?: number; integer?: boolean } = {},
): NumericRange {
  const parse = (text: string | number | undefined) => {
    if (text === undefined || String(text).trim() === "") return undefined;
    const value = Number(text);
    if (
      !Number.isFinite(value) ||
      Math.abs(value) > Number.MAX_SAFE_INTEGER ||
      (options.floor !== undefined && value < options.floor) ||
      (options.ceiling !== undefined && value > options.ceiling) ||
      (options.integer && !Number.isInteger(value))
    ) {
      throw new Error("请输入有效范围");
    }
    return value;
  };
  const range = { min: parse(min), max: parse(max) };
  if (
    range.min !== undefined &&
    range.max !== undefined &&
    range.min > range.max
  )
    throw new Error("下限不能大于上限");
  return range;
}
