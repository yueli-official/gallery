# CollectionMultiSelect

适用于集合的多项条件筛选。基于 Nuxt UI USelectMenu，复用键盘、弹层、选中状态和虚拟列表；无需安装其他库。入口 `@yueli/ui/collection/pattern`，Nuxt Module 自动注册 `YCollectionMultiSelect`。

```vue
<script setup lang="ts">
import { ref } from 'vue';
import { CollectionMultiSelect } from '@yueli/ui/collection/pattern';
const values = ref<(string | number)[]>([]);
const options = [{ value: 'guide', label: '使用指南', description: '文档 / 入门', icon: 'i-tabler-book' }];
const messages = {
  search: '搜索标题或路径…', empty: '没有匹配项', clear: '清空选择', showLess: '收起已选',
  summary: (count: number) => `已选 ${count} 项`, showMore: (count: number) => `还有 ${count} 项`,
  remove: (label: string) => `移除 ${label}`, missing: (value: string | number) => `未加载选项 ${value}`,
};
</script>
<template>
  <CollectionMultiSelect v-model="values" :options="options" label="板块" placeholder="选择板块" :messages="messages" />
</template>
```

`v-model` 为稳定 ID 数组，更新生成新数组并去重。选项 `label` 只放当前层级标题，`description` 放路径；`keywords` 提供附加搜索词。`icon` 和装饰性 `trailingIcon` 沿用原选项合同。消息由消费者负责翻译。

- `selectedFirst=true`：重新打开时已选靠前；打开期间新增选择不重排，避免目标跳动。
- `visibleLimit=2`：已选项显示上限，可展开查看、逐项移除和清空；不会把整串标题塞入按钮。移除保留合理键盘焦点。
- `searchFields=['label','description','keywords']`：连续选择保留查询词。
- `virtualize=false`：需要长列表时传原生 `virtualize`。`size`、`ui` 直接使用 Nuxt UI 配置，不另造尺寸主题。
- `disabled=false`：禁止改变选择，仍允许展开查看已选项。
- 未加载的已选 ID 使用 `messages.missing` 回显并保留；不会静默清除。

没有默认“全选”：筛选中全部和零项常都表示不限，由消费者明确查询语义。层级路径只作为辅助信息，不隐含父子级联。组件不负责远程加载、URL 编码、保存筛选方案或请求提交。旧 CollectionControl 保持单值；interaction.9 起可通过 HeaderTools/Panel 的独立 multiControls 与 filterApply 接入，[数组查询指南](multi-filter-query.md)说明 URL 和一次性应用合同。

AI 升级时按安装制品版本查询 inspect/search，再读组件 usage/api/readme/migration。默认值来自源码 withDefaults；组件没有另一个运行时版本属性。新增入口属于增量采用，不要求旧单选迁移。

interaction.11 提供可组合的 searchTerm model、open/searchComposition 事件、loading/ignoreFilter、selectedOptions 和 empty 插槽，供远程包装复用。selectedOptions 仅供已选名称回显，不混入菜单搜索结果；普通本地选择无需配置。远程使用 [RemoteMultiSelect](../remote-select/multi-select.md)。

interaction.12 增加 content-top/item-label 插槽及公开 focusSearch()，供层级包装使用原生输入框公开 inputRef 恢复焦点。层级导航直接采用 [CollectionHierarchySelect](hierarchy-select.md)，不需要复制选择摘要。
