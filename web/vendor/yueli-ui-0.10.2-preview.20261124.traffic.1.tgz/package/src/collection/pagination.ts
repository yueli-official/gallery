export type CollectionPaginationLayout = "auto" | "compact" | "full";
