<script setup lang="ts">
import { computed, nextTick, ref } from "vue";
import USelectMenu from "@nuxt/ui/components/SelectMenu.vue";
import UButton from "@nuxt/ui/components/Button.vue";
import UIcon from "@nuxt/ui/components/Icon.vue";
import type { SelectMenuProps } from "@nuxt/ui";
import type { CollectionControlValue } from "../panel";
import type {
  CollectionMultiSelectMessages,
  CollectionMultiSelectOption,
} from "../multi-select";

const props = withDefaults(
  defineProps<{
    options: readonly CollectionMultiSelectOption[];
    label: string;
    placeholder: string;
    messages: CollectionMultiSelectMessages;
    disabled?: boolean;
    loading?: boolean;
    ignoreFilter?: boolean;
    selectedOptions?: readonly CollectionMultiSelectOption[];
    selectedFirst?: boolean;
    /** Return an accessible action label; undefined hides the action. */
    locate?: (option: CollectionMultiSelectOption) => string | undefined;
    visibleLimit?: number;
    searchFields?: string[];
    virtualize?: SelectMenuProps["virtualize"];
    size?: SelectMenuProps["size"];
    ui?: SelectMenuProps["ui"];
  }>(),
  {
    disabled: false,
    loading: false,
    ignoreFilter: false,
    selectedOptions: () => [],
    selectedFirst: true,
    visibleLimit: 2,
    searchFields: () => ["label", "description", "keywords"],
    virtualize: false,
  },
);
const searchTerm = defineModel<string>("searchTerm", { default: "" });
const emit = defineEmits<{
  open: [value: boolean];
  searchComposition: [active: boolean];
  locate: [value: CollectionControlValue];
}>();
const model = defineModel<CollectionControlValue[]>({ default: () => [] });
const opened = ref(false);
const menu = ref<{ triggerRef?: HTMLElement } | null>(null);
const root = ref<HTMLElement | null>(null);
const expanded = ref(false);
let searchInputInstance: { inputRef?: HTMLInputElement } | null = null;
const searchInput = computed(() => ({
  ref: (instance: unknown) => {
    searchInputInstance = instance as { inputRef?: HTMLInputElement } | null;
  },
  placeholder: props.messages.search,
  loading: props.loading,
  onCompositionstart: () => emit("searchComposition", true),
  onCompositionend: () => emit("searchComposition", false),
}));
const openingSelection = ref(new Set<CollectionControlValue>());
const values = computed(() => [...new Set(model.value)]);
const items = computed(() => {
  const copied = props.options.map((option) => ({ ...option }));
  return props.selectedFirst
    ? copied.sort(
        (a, b) =>
          Number(openingSelection.value.has(b.value)) -
          Number(openingSelection.value.has(a.value)),
      )
    : copied;
});
const selected = computed(() =>
  values.value.map(
    (value) =>
      props.options.find((option) => option.value === value) ??
      props.selectedOptions.find((option) => option.value === value) ?? {
        value,
        label: props.messages.missing(value),
      },
  ),
);
const limit = computed(() => Math.max(0, Math.trunc(props.visibleLimit) || 0));
const visible = computed(() =>
  expanded.value ? selected.value : selected.value.slice(0, limit.value),
);
const hiddenCount = computed(() =>
  Math.max(0, selected.value.length - limit.value),
);
const summary = computed(() =>
  selected.value.length === 0
    ? props.placeholder
    : selected.value.length === 1
      ? selected.value[0]!.label
      : props.messages.summary(selected.value.length),
);
function focus() {
  menu.value?.triggerRef?.focus();
}
function opening(open: boolean) {
  emit("open", open);
  if (open) openingSelection.value = new Set(values.value);
}
function update(value: CollectionControlValue[]) {
  model.value = [...new Set(value)];
}
async function remove(value: CollectionControlValue, event: MouseEvent) {
  const buttons = [
    ...(root.value?.querySelectorAll<HTMLButtonElement>(
      "[data-selected-option]",
    ) ?? []),
  ];
  const index = buttons.indexOf(event.currentTarget as HTMLButtonElement);
  const restore = event.currentTarget === document.activeElement;
  update(values.value.filter((item) => item !== value));
  await nextTick();
  if (restore) {
    const remaining = root.value?.querySelectorAll<HTMLButtonElement>(
      "[data-selected-option]",
    );
    const target = remaining?.[Math.min(index, remaining.length - 1)];
    if (target) target.focus();
    else focus();
  }
}
async function clear() {
  update([]);
  expanded.value = false;
  await nextTick();
  focus();
}
function focusSearch() {
  searchInputInstance?.inputRef?.focus();
}
async function openSearch() {
  opened.value = true;
  await nextTick();
  focusSearch();
}
defineExpose({ focus, focusSearch, openSearch });
</script>

<template>
  <div ref="root" class="min-w-0 space-y-2" data-collection-multi-select>
    <USelectMenu
      ref="menu"
      v-model:search-term="searchTerm"
      v-model:open="opened"
      :ignore-filter="ignoreFilter"
      :model-value="values"
      :items="items"
      multiple
      value-key="value"
      :aria-label="label"
      :placeholder="placeholder"
      :disabled="disabled"
      :size="size"
      :ui="ui"
      :filter-fields="searchFields"
      :virtualize="virtualize"
      :reset-search-term-on-select="false"
      :search-input="searchInput"
      class="w-full"
      @update:model-value="update"
      @update:open="opening"
    >
      <span class="truncate">{{ summary }}</span>
      <template #content-top><slot name="content-top" /></template>
      <template #content-bottom><slot name="content-bottom" /></template>
      <template v-if="$slots['item-label']" #item-label="{ item }"
        ><slot name="item-label" :item="item"
      /></template>
      <template #empty
        ><slot name="empty">{{ messages.empty }}</slot></template
      >
      <template #item-trailing="{ item, ui: itemUi }">
        <UIcon
          v-if="item.trailingIcon"
          :name="item.trailingIcon"
          :class="itemUi.itemTrailingIcon()"
        />
      </template>
    </USelectMenu>
    <div
      v-if="selected.length"
      class="flex flex-wrap items-center gap-2"
      data-selected-options
    >
      <div v-for="option in visible" :key="option.value" class="inline-flex max-w-full items-center gap-1">
      <UButton
        data-selected-option
        :label="option.label"
        :icon="option.icon"
        trailing-icon="i-tabler-x"
        color="neutral"
        variant="soft"
        :size="size"
        :disabled="disabled"
        :title="option.description"
        :aria-label="
          messages.remove(
            option.description
              ? `${option.label} (${option.description})`
              : option.label,
          )
        "
        :ui="{ label: 'truncate' }"
        class="max-w-full"
        @click="remove(option.value, $event)"
      />
      <UButton v-if="locate?.(option)" :aria-label="locate(option)" :title="option.description" icon="i-tabler-folder-search" variant="ghost" color="neutral" :size="size" :disabled="disabled" @click="emit('locate', option.value)" />
      </div>
      <UButton
        v-if="hiddenCount"
        data-selected-expand
        color="neutral"
        variant="link"
        :size="size"
        :aria-expanded="expanded"
        :label="expanded ? messages.showLess : messages.showMore(hiddenCount)"
        @click="() => { expanded = !expanded }"
      />
      <UButton
        data-selected-clear
        color="neutral"
        variant="link"
        :size="size"
        :disabled="disabled"
        :label="messages.clear"
        @click="clear"
      />
    </div>
  </div>
</template>
