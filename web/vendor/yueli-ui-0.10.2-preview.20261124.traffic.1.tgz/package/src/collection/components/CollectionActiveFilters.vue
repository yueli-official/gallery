<script setup lang="ts">
import MotionCollectionActiveFilters from "../../interaction/components/MotionCollectionActiveFilters.vue";
import type { ButtonProps } from "@nuxt/ui";
export interface CollectionActiveFilter {
  key: string;
  label: string;
}
defineOptions({ inheritAttrs: false });
const props = withDefaults(
  defineProps<{
    enhanced?: boolean;
    motion?: boolean;
    label?: string;
    clearLabel?: string;
    items: readonly CollectionActiveFilter[];
    size?: ButtonProps["size"];
  }>(),
  { enhanced: false, motion: true, label: "已筛选", clearLabel: "清除全部" },
);
const emit = defineEmits<{ remove: [key: string]; clear: [] }>();
</script>
<template>
  <MotionCollectionActiveFilters
    v-if="enhanced"
    v-bind="{ ...$attrs, items, size, label, clearLabel, motion }"
    @remove="emit('remove', $event)"
    @clear="emit('clear')"
  />
  <div
    v-else-if="items.length"
    v-bind="$attrs"
    aria-label="已应用筛选"
    class="flex flex-wrap items-center gap-2 text-xs"
  >
    <span class="text-muted">{{ label }}</span
    ><UButton
      v-for="item in items"
      :key="item.key"
      color="neutral"
      variant="soft"
      :size="size"
      trailing-icon="i-tabler-x"
      :label="item.label"
      @click="emit('remove', item.key)"
    /><UButton
      color="neutral"
      variant="link"
      :size="size"
      :label="clearLabel"
      @click="emit('clear')"
    />
  </div>
</template>
