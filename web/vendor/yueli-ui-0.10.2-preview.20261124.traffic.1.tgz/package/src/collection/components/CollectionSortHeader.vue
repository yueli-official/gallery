<script setup lang="ts">
import { computed } from "vue";

const props = withDefaults(
  defineProps<{
    label: string;
    active: boolean;
    sortOrder: "asc" | "desc";
    alignLabel?: boolean;
  }>(),
  {
    alignLabel: false,
  },
);

const emit = defineEmits<{ sort: [] }>();
const icon = computed(() =>
  props.active
    ? props.sortOrder === "asc"
      ? "i-tabler-arrow-up"
      : "i-tabler-arrow-down"
    : "i-tabler-arrows-sort",
);
const actionLabel = computed(() =>
  props.active
    ? `${props.label}，当前${props.sortOrder === "asc" ? "正序" : "倒序"}，点击切换为${props.sortOrder === "asc" ? "倒序" : "正序"}`
    : `按${props.label}排序`,
);
</script>

<template>
  <UButton
    :label="label"
    :icon="icon"
    :aria-label="actionLabel"
    :aria-pressed="active"
    color="neutral"
    variant="ghost"
    :class="
      alignLabel
        ? 'relative mx-0 justify-start px-0'
        : '-mx-2 justify-start px-2'
    "
    :ui="
      alignLabel
        ? {
            base: 'gap-0 px-0',
            leadingIcon: 'absolute right-[calc(100%+0.25rem)]',
          }
        : undefined
    "
    @click="emit('sort')"
  />
</template>
