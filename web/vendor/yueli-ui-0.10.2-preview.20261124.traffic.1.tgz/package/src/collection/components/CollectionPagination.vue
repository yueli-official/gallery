<script setup lang="ts">
import type { PaginationProps } from "@nuxt/ui";
import { computed } from "vue";
import type { CollectionPaginationLayout } from "../pagination";
defineOptions({ inheritAttrs: false });
const props = withDefaults(
  defineProps<{
    totalPages: number;
    compact?: boolean;
    layout?: CollectionPaginationLayout;
    size?: PaginationProps["size"];
    ui?: PaginationProps["ui"];
    disabled?: boolean;
  }>(),
  { layout: "auto" },
);
const page = defineModel<number>({ required: true });
const pageCount = computed(() =>
  Number.isFinite(props.totalPages)
    ? Math.max(1, Math.ceil(props.totalPages))
    : 1,
);
const currentPage = computed(() =>
  Math.min(pageCount.value, Math.max(1, page.value || 1)),
);
const paginationUi = computed(() => {
  const list = props.ui?.list;
  return {
    ...(props.compact ? { first: "inline-flex", last: "inline-flex" } : {}),
    ...props.ui,
    list:
      typeof list === "function"
        ? (defaults: string) => ["flex-wrap justify-end", list(defaults)]
        : ["flex-wrap justify-end", list],
  };
});
function go(value: number) {
  if (!props.disabled && value >= 1 && value <= pageCount.value)
    page.value = value;
}
</script>

<template>
  <div
    v-if="compact || totalPages > 1"
    v-bind="$attrs"
    role="group"
    class="collection-pagination w-full min-w-0"
    data-collection-pagination
    :data-pagination-layout="layout"
  >
    <div
      data-pagination-compact
      role="group"
      class="flex min-w-0 items-center justify-end gap-2"
    >
      <UButton
        type="button"
        aria-label="上一页"
        title="上一页"
        icon="i-tabler-chevron-left"
        color="neutral"
        variant="outline"
        :size="size"
        :disabled="disabled || currentPage <= 1"
        @click="go(currentPage - 1)"
      />
      <span
        data-pagination-status
        aria-live="polite"
        aria-atomic="true"
        class="min-w-0 truncate text-xs tabular-nums"
        :title="`${currentPage} / ${pageCount}`"
        >{{ currentPage }} / {{ pageCount }}</span
      >
      <UButton
        type="button"
        aria-label="下一页"
        title="下一页"
        icon="i-tabler-chevron-right"
        color="neutral"
        variant="outline"
        :size="size"
        :disabled="disabled || currentPage >= pageCount"
        @click="go(currentPage + 1)"
      />
    </div>
    <UPagination
      data-pagination-full
      :page="currentPage"
      :total="pageCount"
      :items-per-page="1"
      :show-edges="compact"
      :disabled="disabled"
      :ui="paginationUi"
      :data-compact-page-buttons="compact || undefined"
      :sibling-count="1"
      :size="size"
      @update:page="go"
    >
      <template #first
        ><UButton
          aria-label="第一页"
          title="第一页"
          icon="i-tabler-chevrons-left"
          color="neutral"
          variant="outline"
          :size="size"
      /></template>
      <template #prev
        ><UButton
          aria-label="上一页"
          title="上一页"
          icon="i-tabler-chevron-left"
          color="neutral"
          variant="outline"
          :size="size"
      /></template>
      <template #next
        ><UButton
          aria-label="下一页"
          title="下一页"
          icon="i-tabler-chevron-right"
          color="neutral"
          variant="outline"
          :size="size"
      /></template>
      <template #last
        ><UButton
          aria-label="最后一页"
          title="最后一页"
          icon="i-tabler-chevrons-right"
          color="neutral"
          variant="outline"
          :size="size"
      /></template>
    </UPagination>
  </div>
</template>

<style scoped>
.collection-pagination {
  container: collection-pagination / inline-size;
  contain-intrinsic-inline-size: 24rem;
}
[data-pagination-compact] {
  display: none;
}
[data-pagination-layout="compact"] > [data-pagination-compact] {
  display: flex;
}
[data-pagination-layout="compact"] > [data-pagination-full] {
  display: none;
}
@container collection-pagination (max-width: 24rem) {
  [data-pagination-layout="auto"] > [data-pagination-compact] {
    display: flex;
  }
  [data-pagination-layout="auto"] > [data-pagination-full] {
    display: none;
  }
}
</style>
