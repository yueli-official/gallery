<script setup lang="ts">
import CollectionSelectionBarBase from "../CollectionSelectionBarBase.vue";
import MotionCollectionSelectionBar from "../../interaction/components/MotionCollectionSelectionBar.vue";
import type { ButtonProps } from "@nuxt/ui";
import type { CollectionPanelMessages } from "../panel";

defineOptions({ inheritAttrs: false });
const props = withDefaults(
  defineProps<{
    enhanced?: boolean;
    motion?: boolean;
    reserveSpace?: boolean;
    returnFocusTo?: HTMLElement | null;
    count: number;
    size?: ButtonProps["size"];
    mode?: "keys" | "query";
    messages: CollectionPanelMessages;
    canSelectAllResults?: boolean;
  }>(),
  {
    enhanced: false,
    motion: true,
    reserveSpace: true,
    mode: "keys",
    canSelectAllResults: false,
  },
);

const emit = defineEmits<{
  selectAllResults: [];
  clearSelection: [];
}>();
</script>

<template>
  <MotionCollectionSelectionBar
    v-if="enhanced"
    v-bind="{
      ...$attrs,
      count,
      size,
      mode,
      messages,
      canSelectAllResults,
      motion,
      reserveSpace,
      returnFocusTo,
    }"
    @select-all-results="emit('selectAllResults')"
    @clear-selection="emit('clearSelection')"
    ><slot
  /></MotionCollectionSelectionBar>
  <CollectionSelectionBarBase
    v-else
    v-bind="$attrs"
    :count="count"
    :size="size"
    :mode="mode"
    :messages="messages"
    :can-select-all-results="canSelectAllResults"
    @select-all-results="emit('selectAllResults')"
    @clear-selection="emit('clearSelection')"
    ><slot
  /></CollectionSelectionBarBase>
</template>
