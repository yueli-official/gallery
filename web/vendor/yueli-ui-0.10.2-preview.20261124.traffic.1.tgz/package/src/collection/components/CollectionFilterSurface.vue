<script setup lang="ts">
import {
  computed,
  onMounted,
  onBeforeUnmount,
  ref,
  watch,
  useId,
  nextTick,
} from "vue";
import UPopover from "@nuxt/ui/components/Popover.vue";
import UDrawer from "@nuxt/ui/components/Drawer.vue";
import UModal from "@nuxt/ui/components/Modal.vue";
import UButton from "@nuxt/ui/components/Button.vue";
import type { ButtonProps } from "@nuxt/ui";

export type CollectionFilterPresentation =
  "auto" | "popover" | "drawer" | "modal";
const props = withDefaults(
  defineProps<{
    presentation?: CollectionFilterPresentation;
    title: string;
    label: string;
    size?: ButtonProps["size"];
  }>(),
  { presentation: "auto" },
);
const open = defineModel<boolean>("open", { default: false });
const ready = ref(false);
const trigger = ref<{ $el?: HTMLElement } | null>(null);
const wide = ref(false);
const titleId = useId();
const desired = computed(() =>
  props.presentation === "auto"
    ? wide.value
      ? "popover"
      : "drawer"
    : props.presentation,
);
const openingMode = ref<"popover" | "drawer" | "modal">("drawer");
const mode = openingMode;
const surface = computed(() =>
  mode.value === "popover"
    ? UPopover
    : mode.value === "drawer"
      ? UDrawer
      : UModal,
);
const surfaceProps = computed(() =>
  mode.value === "popover"
    ? {
        content: { align: "end" as const, "aria-labelledby": titleId },
        ui: {
          content:
            "flex max-h-[var(--reka-popover-content-available-height)] w-80 max-w-[var(--reka-popover-content-available-width)] flex-col overflow-hidden",
        },
      }
    : mode.value === "drawer"
      ? {
          title: props.title,
          direction: "bottom" as const,
          handleOnly: true,
          ui: {
            content: "max-h-dvh",
            container: "min-h-0 overflow-hidden",
            header: "shrink-0",
            body: "min-h-0 overflow-y-auto",
            footer:
              "shrink-0 flex-row justify-end pb-[max(1rem,env(safe-area-inset-bottom))]",
          },
        }
      : {
          title: props.title,
          ui: { content: "max-w-sm", footer: "justify-end" },
        },
);
let media: MediaQueryList | undefined;
function updateMedia() {
  wide.value = media?.matches ?? false;
  if (open.value && mode.value === "popover") {
    void nextTick(() => {
      const element = trigger.value?.$el;
      if (!element) return;
      const rect = element.getBoundingClientRect();
      if (
        rect.top < 0 ||
        rect.bottom > window.innerHeight ||
        rect.left < 0 ||
        rect.right > window.innerWidth
      ) {
        element.scrollIntoView({ block: "nearest", inline: "nearest" });
      }
    });
  }
}
onMounted(() => {
  media = window.matchMedia("(min-width: 48rem)");
  updateMedia();
  media.addEventListener("change", updateMedia);
  openingMode.value = desired.value;
  ready.value = true;
});
onBeforeUnmount(() => media?.removeEventListener("change", updateMedia));
watch(
  open,
  (value) => {
    if (value) openingMode.value = desired.value;
  },
  { flush: "sync" },
);
</script>
<template>
  <component
    v-if="ready"
    :is="surface"
    v-model:open="open"
    v-bind="surfaceProps"
  >
    <UButton
      ref="trigger"
      :size="size"
      color="neutral"
      variant="outline"
      icon="i-tabler-adjustments-horizontal"
      :label="label"
    />
    <template v-if="mode === 'popover'" #content>
      <div class="shrink-0 border-b border-default p-4">
        <h2 :id="titleId" class="text-sm font-semibold">{{ title }}</h2>
      </div>
      <div class="min-h-0 overflow-y-auto p-4" data-filter-surface="popover">
        <slot name="body" />
      </div>
      <div class="flex shrink-0 justify-end gap-2 border-t border-default p-4">
        <slot name="footer" />
      </div>
    </template>
    <template v-if="mode !== 'popover'" #body
      ><div :data-filter-surface="mode"><slot name="body" /></div
    ></template>
    <template v-if="mode !== 'popover'" #footer
      ><slot name="footer"
    /></template>
  </component>
  <UButton
    v-else
    :size="size"
    color="neutral"
    variant="outline"
    icon="i-tabler-adjustments-horizontal"
    :label="label"
    @click="() => { open = true }"
  />
</template>
