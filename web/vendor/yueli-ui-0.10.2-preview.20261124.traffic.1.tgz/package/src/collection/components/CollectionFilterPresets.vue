<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, ref, useTemplateRef } from "vue";
import type { ButtonProps, InputProps } from "@nuxt/ui";
import type { CollectionFilterPreset, CollectionFilterPresetActions } from "../filter-presets";

export interface CollectionFilterPresetMessages {
  label: string;
  placeholder: string;
  save: string;
  edit: string;
  name: string;
  required: string;
  submit: string;
  saving: string;
  cancel: string;
  remove: string;
  confirmRemove: (label: string) => string;
  modified: string;
  error: (error: unknown) => string;
}
const props = withDefaults(defineProps<{
  items: readonly CollectionFilterPreset[];
  actions: CollectionFilterPresetActions;
  messages: CollectionFilterPresetMessages;
  activeId?: string;
  modified?: boolean;
  disabled?: boolean;
  canSave?: boolean;
  canEdit?: boolean;
  canRemove?: boolean;
  size?: ButtonProps["size"];
  ui?: InputProps["ui"];
}>(), { modified: false, disabled: false, canSave: true, canEdit: true, canRemove: true, size: "sm" });
const open = ref(false);
const mode = ref<"save" | "edit" | "remove">("save");
const name = ref("");
const editingId = ref<string>();
const editingLabel = ref("");
const busy = ref(false);
const error = ref("");
const fieldError = ref("");
const input = useTemplateRef<{ inputRef: HTMLInputElement | null }>("nameInput");
let disposed = false;
onBeforeUnmount(() => { disposed = true; });
const active = computed(() => props.items.find(item => item.id === props.activeId));
// Native update:modelValue skips unchanged values; item selection also handles restoring an active preset.
const options = computed(() => props.items.map(item => ({ value: item.id, label: item.label, description: item.description, onSelect: () => select(item.id) })));
function begin(next: "save" | "edit" | "remove") {
  if (busy.value || props.disabled || (next !== "save" && !active.value)) return;
  mode.value = next;
  editingId.value = next === "save" ? undefined : active.value?.id;
  editingLabel.value = active.value?.label ?? "";
  name.value = next === "save" ? "" : editingLabel.value;
  fieldError.value = "";
  error.value = "";
  open.value = true;
}
async function run(action: () => Promise<void>, close = false) {
  if (busy.value || props.disabled) return;
  busy.value = true;
  error.value = "";
  try {
    await action();
    if (!disposed && close) open.value = false;
  } catch (cause) {
    if (!disposed) error.value = props.messages.error(cause);
  } finally {
    if (!disposed) busy.value = false;
  }
}
async function submit() {
  if (mode.value !== "remove" && !name.value.trim()) {
    fieldError.value = props.messages.required;
    await nextTick();
    input.value?.inputRef?.focus();
    return;
  }
  const id = editingId.value;
  // Revalidate externally changed permissions and membership at submission time.
  if (mode.value === "save" && props.canSave) await run(() => props.actions.save(name.value.trim()), true);
  else if (id && props.items.some(item => item.id === id)) {
    if (mode.value === "edit" && props.canEdit) await run(() => props.actions.update(id, name.value.trim()), true);
    if (mode.value === "remove" && props.canRemove) await run(() => props.actions.remove(id), true);
  }
}
function select(value: unknown) {
  if (typeof value === "string" && props.items.some(item => item.id === value)) {
    void run(() => props.actions.apply(value));
  }
}
</script>

<template>
  <div class="space-y-2">
    <div class="flex flex-wrap items-center gap-2">
      <USelectMenu :model-value="activeId" :items="options" :loading="busy && !open" value-key="value" :aria-label="messages.label" :placeholder="messages.placeholder" :size="size" :disabled="disabled || busy || items.length === 0" :filter-fields="['label', 'description']" class="min-w-0 w-full sm:w-56" />
      <UBadge v-if="active && modified" color="neutral" variant="soft" :label="messages.modified" />
      <UButton v-if="canSave" :label="messages.save" icon="i-tabler-bookmark-plus" color="neutral" variant="soft" :size="size" :disabled="disabled || busy" @click="begin('save')" />
      <UButton v-if="active && canEdit" :label="messages.edit" icon="i-tabler-edit" color="neutral" variant="soft" :size="size" :disabled="disabled || busy" @click="begin('edit')" />
      <UButton v-if="active && canRemove" :label="messages.remove" icon="i-tabler-trash" color="neutral" variant="ghost" :size="size" :disabled="disabled || busy" @click="begin('remove')" />
    </div>
    <p v-if="error && !open" role="alert" class="text-sm text-error">{{ error }}</p>
    <UModal v-model:open="open" :dismissible="!busy" :close="!busy" :title="mode === 'remove' ? messages.remove : mode === 'edit' ? messages.edit : messages.save">
      <template #body>
        <form class="space-y-3" @submit.prevent="submit">
          <p v-if="mode === 'remove'" class="text-sm">{{ messages.confirmRemove(editingLabel) }}</p>
          <UFormField v-else :label="messages.name" :error="fieldError">
            <UInput ref="nameInput" v-model="name" :aria-label="messages.name" :size="size" :ui="ui" :disabled="busy || disabled" autofocus class="w-full" @update:model-value="fieldError = ''" />
          </UFormField>
          <p v-if="error" role="alert" class="text-sm text-error">{{ error }}</p>
          <div class="flex justify-end gap-2">
            <UButton :label="messages.cancel" color="neutral" variant="soft" :size="size" :disabled="busy" @click="() => { open = false }" />
            <UButton type="submit" :label="busy ? messages.saving : mode === 'remove' ? messages.remove : messages.submit" :color="mode === 'remove' ? 'error' : 'primary'" :size="size" :loading="busy" :disabled="disabled" />
          </div>
        </form>
      </template>
    </UModal>
  </div>
</template>
