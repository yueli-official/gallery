<script setup lang="ts">
import { computed } from "vue";
import CollectionSortHeader from "./CollectionSortHeader.vue";
import type { CollectionPrimaryMediaSize } from "./CollectionPrimaryCell.vue";

const props = withDefaults(
  defineProps<{
    label: string;
    mediaSize?: CollectionPrimaryMediaSize;
    collapseMedia?: boolean;
    sortable?: boolean;
    active?: boolean;
    sortOrder?: "asc" | "desc";
  }>(),
  {
    mediaSize: "lg",
    collapseMedia: true,
    sortable: false,
    active: false,
    sortOrder: "asc",
  },
);

const emit = defineEmits<{ sort: [] }>();
const mediaClass = computed(
  () =>
    ({
      sm: "w-10",
      md: "w-11",
      lg: "w-12",
    })[props.mediaSize],
);
</script>

<template>
  <div data-collection-primary-header class="flex min-w-0 items-center gap-3">
    <span
      data-collection-primary-media
      :data-collapse-media="collapseMedia ? 'true' : 'false'"
      aria-hidden="true"
      class="collection-primary-media h-0 shrink-0"
      :class="mediaClass"
    />
    <CollectionSortHeader
      v-if="sortable"
      data-collection-primary-sort
      :label="label"
      :active="active"
      :sort-order="sortOrder"
      align-label
      @sort="emit('sort')"
    />
    <span v-else class="min-w-0 truncate">
      <slot>{{ label }}</slot>
    </span>
  </div>
</template>

<style scoped>
@container collection (max-width: 40rem) {
  .collection-primary-media[data-collapse-media="true"] {
    display: none;
  }

  [data-collection-primary-sort] :deep([data-slot="leadingIcon"]) {
    display: none;
  }
}
</style>
