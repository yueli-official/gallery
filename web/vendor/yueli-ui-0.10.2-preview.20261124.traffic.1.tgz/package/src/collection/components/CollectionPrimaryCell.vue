<script setup lang="ts">
import { computed } from "vue";

export type CollectionPrimaryMediaSize = "sm" | "md" | "lg";

const props = withDefaults(
  defineProps<{
    mediaSize?: CollectionPrimaryMediaSize;
    collapseMedia?: boolean;
  }>(),
  {
    mediaSize: "lg",
    collapseMedia: true,
  },
);

const mediaClass = computed(() => ({
  sm: "size-10",
  md: "size-11",
  lg: "size-12",
})[props.mediaSize]);
</script>

<template>
  <div data-collection-primary-cell class="flex min-w-0 items-center gap-3">
    <span
      v-if="$slots.media"
      data-collection-primary-media
      :data-collapse-media="collapseMedia ? 'true' : 'false'"
      class="collection-primary-media shrink-0"
      :class="mediaClass"
    >
      <slot name="media" />
    </span>
    <div data-collection-primary-content class="min-w-0 flex-1">
      <slot />
    </div>
  </div>
</template>

<style scoped>
@container collection (max-width: 40rem) {
  .collection-primary-media[data-collapse-media="true"] {
    display: none;
  }
}
</style>
