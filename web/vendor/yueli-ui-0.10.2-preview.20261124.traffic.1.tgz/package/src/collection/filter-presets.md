# 常用筛选方案

CollectionFilterPresets 提供命名保存、搜索选择、恢复、覆盖及确认删除。多项条件复用比重选更快，普通少量筛选不必使用。通过 `@yueli/ui/collection/pattern` 导入，Nuxt Module 自动注册 `YCollectionFilterPresets`。

## 合同

`items` 是消费者拥有的方案列表（稳定 id、label、可选 description、query）。`actions` 提供 apply(id)、save(label)、update(id,label)、remove(id) 四个 Promise 方法。操作成功后消费者更新 items/activeId；拒绝时保持弹窗和名称，通过 messages.error 原地显示可重试错误。执行期间禁用重复操作与关闭，组件不会请求 HTTP、写 localStorage 或访问账户。异步动作的业务副作用及取消归消费者负责；卸载后组件不继续改变自身状态。

`activeId` 由消费者传入；`modified` 表示当前已应用条件与选中方案不同。canSave/canEdit/canRemove 控制操作入口；disabled 禁用操作，后台仍须验证权限。size 沿用 Nuxt UI，ui 配置名称输入框，所有文案由 messages 提供。删除成功只移除方案，不自动清空当前条件。相同方案可重新应用以恢复修改过的条件。

## 集成

从 `@yueli/ui/collection` 导入 snapshotCollectionFilters 和 equalCollectionFilters。为筛选定义独立 RouteQueryCodec，**不包含页码、选中行和无关 URL 参数**。snapshotCollectionFilters(codec,current) 经 serialize/parse 规范化，复制并冻结数组，只提取 ownedKeys。恢复用 codec.parse(preset.query)，显式复位分页，走一个提交入口。不要同时监听选择事件与查询变化重复请求。

save/update 必须在开始操作时捕获当前已应用条件，不能保存尚未应用的弹层草稿。保存成功不应重新请求列表；apply 完整替换筛选、重置分页并只请求一次；remove 保留当前筛选。用户/产品/筛选合同版本由存储 Adapter 隔离，名称限制、重名规则、容量和持久化校验由消费者声明。旧版本方案不能无条件当作新合同；加载前迁移或明确提示不可用。组件不添加第二份运行时版本，包版本与 AI catalog 同版。

## 迁移

interaction.13 为可选增量入口，已有 HeaderTools 草稿/应用及 URL codec 不变。没有真实存储 Adapter 的示例只证明交互，不能声称持久化完成；UI Lab 使用会话内存演示。父子选择传播、远程分页与懒加载不属于本组件。
