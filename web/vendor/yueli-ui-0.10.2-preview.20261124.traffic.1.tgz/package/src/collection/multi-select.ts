import type { CollectionControlOption, CollectionControlValue } from "./panel";

/** Search metadata is local to the option; values stay stable across label changes. */
export interface CollectionMultiSelectOption extends CollectionControlOption {
  keywords?: string;
}

export interface CollectionMultiSelectMessages {
  search: string;
  empty: string;
  clear: string;
  showLess: string;
  summary: (count: number) => string;
  showMore: (count: number) => string;
  remove: (label: string) => string;
  missing: (value: CollectionControlValue) => string;
}

/** Additive filter contract; does not widen existing single-value controls. */
export interface CollectionMultiSelectControl {
  readonly id: string;
  readonly label: string;
  readonly value: readonly CollectionControlValue[];
  readonly options: readonly CollectionMultiSelectOption[];
  readonly placeholder: string;
  readonly messages: CollectionMultiSelectMessages;
  readonly disabled?: boolean;
  readonly visibleLimit?: number;
  readonly selectedFirst?: boolean;
  readonly searchFields?: string[];
  readonly virtualize?: boolean;
}

export interface CollectionFilterApply {
  readonly values: Record<string, CollectionControlValue>;
  readonly multiValues: Record<string, CollectionControlValue[]>;
}
