export type RouteQueryValue = string | readonly string[] | null | undefined;
export type RouteQuery = Readonly<Record<string, RouteQueryValue>>;

export interface RouteQueryCodec<TQuery> {
  readonly ownedKeys: readonly string[];
  parse(query: RouteQuery): TQuery;
  serialize(query: TQuery): RouteQuery;
}

export interface CollectionRouteStringField {
  readonly kind: "string";
  readonly default: string;
  readonly maxLength?: number;
  readonly trim?: boolean;
}

export interface CollectionRouteEnumField<TValue extends string = string> {
  readonly kind: "enum";
  readonly values: readonly TValue[];
  readonly default: TValue;
}

/** Repeated query keys form a set, normalized in the declared values order. */
export interface CollectionRouteEnumSetField<TValue extends string = string> {
  readonly kind: "enum-set";
  readonly values: readonly TValue[];
  readonly default: readonly TValue[];
}

export interface CollectionRoutePositiveIntegerField<
  TValue extends number = number,
> {
  readonly kind: "positive-integer";
  readonly values?: readonly TValue[];
  readonly default: TValue;
}

export type CollectionRouteField =
  | CollectionRouteStringField
  | CollectionRouteEnumField
  | CollectionRouteEnumSetField
  | CollectionRoutePositiveIntegerField;

type CollectionRouteFieldValue<TField extends CollectionRouteField> =
  TField extends CollectionRouteStringField
    ? string
    : TField extends CollectionRouteEnumField<infer TValue>
      ? TValue
      : TField extends CollectionRouteEnumSetField<infer TValue>
        ? readonly TValue[]
        : TField extends CollectionRoutePositiveIntegerField
          ? number
          : never;

export type CollectionRouteQueryFromFields<
  TFields extends Readonly<Record<string, CollectionRouteField>>,
> = {
  readonly [TKey in keyof TFields]: CollectionRouteFieldValue<TFields[TKey]>;
};

function firstString(value: unknown): string {
  return Array.isArray(value) ? String(value[0] ?? "") : String(value ?? "");
}

function validateField(key: string, field: CollectionRouteField) {
  if (field.kind === "string") {
    if (
      field.maxLength !== undefined &&
      (!Number.isSafeInteger(field.maxLength) || field.maxLength < 1)
    ) {
      throw new RangeError(
        `Collection route field ${key} maxLength must be a positive safe integer.`,
      );
    }
    return;
  }
  if (field.kind === "enum") {
    if (!field.values.includes(field.default)) {
      throw new RangeError(
        `Collection route field ${key} default must be included in values.`,
      );
    }
    return;
  }
  if (field.kind === "enum-set") {
    if (
      field.values.some((value) => !value) ||
      new Set(field.values).size !== field.values.length ||
      field.default.some((value) => !field.values.includes(value))
    ) {
      throw new RangeError(
        `Collection route field ${key} requires unique nonempty values and a default subset.`,
      );
    }
    return;
  }
  if (!Number.isSafeInteger(field.default) || field.default < 1) {
    throw new RangeError(
      `Collection route field ${key} default must be a positive safe integer.`,
    );
  }
  if (field.values && !field.values.includes(field.default)) {
    throw new RangeError(
      `Collection route field ${key} default must be included in values.`,
    );
  }
}

function normalizeField(
  field: CollectionRouteField,
  value: unknown,
): string | number | readonly string[] {
  if (field.kind === "string") {
    const normalized =
      field.trim === false ? firstString(value) : firstString(value).trim();
    if (!normalized) return field.default;
    return field.maxLength === undefined
      ? normalized
      : normalized.slice(0, field.maxLength);
  }
  if (field.kind === "enum") {
    const normalized = firstString(value);
    return field.values.includes(normalized) ? normalized : field.default;
  }
  if (field.kind === "enum-set") {
    const input =
      value === undefined || value === null
        ? field.default
        : Array.isArray(value)
          ? value
          : [value];
    const selected = new Set(input);
    return Object.freeze(field.values.filter((item) => selected.has(item)));
  }
  const normalized = Number.parseInt(firstString(value), 10);
  if (!Number.isSafeInteger(normalized) || normalized < 1) return field.default;
  return !field.values || field.values.includes(normalized)
    ? normalized
    : field.default;
}

export function createCollectionRouteQueryCodec<
  const TFields extends Readonly<Record<string, CollectionRouteField>>,
>(fields: TFields): RouteQueryCodec<CollectionRouteQueryFromFields<TFields>> {
  const entries = Object.entries(fields);
  for (const [key, field] of entries) validateField(key, field);

  return {
    ownedKeys: Object.freeze(entries.map(([key]) => key)),
    parse(query) {
      return Object.freeze(
        Object.fromEntries(
          entries.map(([key, field]) => [
            key,
            normalizeField(field, query[key]),
          ]),
        ),
      ) as CollectionRouteQueryFromFields<TFields>;
    },
    serialize(query) {
      const serialized: Record<string, string | readonly string[]> = {};
      for (const [key, field] of entries) {
        const value = normalizeField(field, query[key]);
        if (field.kind === "enum-set") {
          const items = value as readonly string[];
          const defaults = normalizeField(
            field,
            field.default,
          ) as readonly string[];
          if (
            items.length !== defaults.length ||
            items.some((item, index) => item !== defaults[index])
          ) {
            // Empty arrays are omitted by routers; an empty string preserves an explicit empty set.
            serialized[key] = items.length ? [...items] : [""];
          }
          continue;
        }
        if (!Object.is(value, field.default)) serialized[key] = String(value);
      }
      return serialized;
    },
  };
}
