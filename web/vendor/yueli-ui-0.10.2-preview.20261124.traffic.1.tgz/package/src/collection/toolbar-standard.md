# Collection toolbar standard

This standard governs searchable, filterable and selectable collections used by Yueli websites,
applications and other Nuxt UI surfaces. It applies to tables, lists and grids; it does not replace
their data model or rendering primitive.

## Evidence

- [Nuxt UI Dashboard customers](https://github.com/nuxt-ui-templates/dashboard/blob/main/app/pages/customers.vue)
  demonstrates direct `UTable` composition, column-owned sorting, row selection and a compact toolbar.
  It is a simple one-filter example, not a specification for complex filtering.
- [Carbon data table](https://carbondesignsystem.com/components/data-table/usage/) reserves the table
  toolbar for global controls, places sorting in column headers and replaces normal controls with a
  batch action bar when rows are selected.
- [Cloudscape collection select filter](https://cloudscape.design/components/collection-select-filter/)
  recommends no more than two ordinary select filters. More properties or operators belong in a
  property filter.
- [PatternFly toolbar](https://v4-archive.patternfly.org/v4/components/toolbar/design-guidelines/)
  collapses filters behind a toggle and actions behind overflow at compact widths instead of relying
  on arbitrary wrapping.
- [Shopify Polaris index table](https://polaris-react.shopify.com/components/tables/index-table)
  treats filtering, sorting, pagination, selection and bulk actions as one collection workflow and
  permits condensed small-screen behavior when bulk selection is not essential.

## Required anatomy

1. The data surface and its controls share one visual container.
2. Default mode has one primary toolbar. From the standard Tailwind `@xl` container size (36rem /
   576px), search, one filter trigger and a compact utility group share one row.
3. At compact component widths search owns the first row. The same filter trigger and utilities own
   a deterministic second row. Filter fields live in a shared dialog and never expand the toolbar or wrap
   into accidental rows.
4. Selection mode replaces the default toolbar with selected count, no more than two promoted bulk
   actions, overflow for additional actions and an explicit exit. It does not append another bar.
5. Applied-filter chips use a separate optional region that exists only while filters are active.
6. Pagination and result range belong in the collection footer. Back-to-top and page actions do not.

## Filter complexity

- No useful filter: do not render an empty filter control.
- Finite properties use a flat labelled field stack inside the shared filter dialog.
- Add sections only when the fields have a genuine semantic distinction, not merely because a count
  threshold was crossed. Multi-value conditions or operators may use a property-filter control.
- Do not change the outer toolbar anatomy based on filter count.
- Filtering always applies to the full remote collection, not only the loaded page.
- Active filters must be countable, individually removable when practical, and clearable as a group.

## Sorting and view controls

- A strict table puts sortable fields in the corresponding column headers.
- A list or grid without sortable headers may use one toolbar sort control.
- A list/table/grid view switch is a utility, not a filter.
- Column visibility is a utility and should collapse into an overflow menu when space is constrained.

## Responsive and action priority

- Responsiveness follows component width, because a collection can live in a main panel, split panel
  or embedded application shell.
- Search and the filter disclosure remain available at every supported width.
- Show at most two promoted global or bulk actions. Put the rest in an overflow menu.
- If bulk selection is essential on small screens, keep selection mode usable with compact labels or
  an overflow menu. If it is not essential, a product may deliberately enter a documented condensed
  mode; it must not disappear accidentally because controls wrapped or overflowed.

## Accessibility and internationalization

- The toolbar has a caller-owned accessible label. Visible product copy remains caller-owned and can
  come from any i18n solution.
- Search uses a real search form when explicit submission exists.
- The Nuxt UI popover trigger exposes its open state and content relationship to assistive technology.
- Selection count is textual; selection is never communicated by row color alone.
- Icon-only utilities and overflow triggers require accessible labels.

## Public Module seam

`CollectionTableToolbar` owns responsive placement, the filter popover and default/selection mode
switching. Callers own filter controls, query semantics, business actions, translated copy, table
columns, data loading and pagination. `UTable` remains the table implementation.

The Module intentionally does not expose arbitrary row-layout classes, breakpoint props or a generic
array schema for actions and filters. Those would make the Interface as complex as each product. Slots
preserve domain controls while the shared implementation pays for the difficult responsive behavior.

## 2026-10-10 header layout correction

`presentation="header"` uses the same anatomy for articles, documents and comments:
search remains on the left (bounded to 30rem), and filter/sort/view utilities align
to the right edge of the full collection. Below a 36rem collection width, search
uses the first row and controls use the second. Native Nuxt UI `size="sm"` is the
default; an explicit size still overrides it.

The `data-admin-collection-tools` wrapper must not add another padding layer,
control alignment or width limit. `CommentModerationToolbar` fills its collection
instead of imposing a 34rem container. Product CSS must not assign media height
to `CollectionPrimaryHeader`'s zero-height alignment placeholder. Pair the public
primary header/cell components and let them own media geometry.

These are visual behavior corrections in
`0.8.0-preview.20261010.collection-layout.3`; exports and product query adapters
are unchanged. Consumers must adopt the new fixed tarball and remove old deep
layout overrides; changing the package version alone cannot remove product CSS.

## Rejected patterns

- A permanent search band, permanent filter band and permanent context band.
- Unbounded `flex-wrap` as the responsive strategy.
- Direct filter selects in the outer toolbar, even when there are only one or two.
- A sticky or fixed batch bar that covers rows or pagination.
- A second table implementation or shallow `UTable` wrapper.
- Sorting both in the toolbar and the corresponding table header.

集合工具栏搜索提交、筛选与排序直接使用共享中性 outline 按钮变体，保留其正常 1px 内侧边界；外围 CSS outline 与按钮变体名称不是同一含义。额外 focus outline 由共享 createUiPreset 禁用，焦点只切换原有边界为 primary；产品页面及集合组件不追加焦点样式、不改成 ghost。

## 普通集合统一迁移

CollectionPanel 默认与 CommentModerationToolbar 均委托 CollectionHeaderTools，单个/多个筛选共用 draft/apply/cancel 状态与提交规则。interaction.10 起 filterPresentation 默认 auto（宽屏 Popover、窄屏底部 Drawer），可明确选择 popover/drawer/modal；复杂筛选可以用 modal，不根据字段数量猜测容器。排序保持现有排序弹窗。搜索在左、操作在右，不因字段数切换为内联下拉。filtersOpen 保留受控能力，选择模式与 active-filters/view 插槽共享转发。搜索型筛选保留 searchPlaceholder。controlChange 的 id/value 合同保留，sort/direction 控件单独传 sortControls；组件只拥有交互，不拥有业务查询。消费者的必要日期/范围/树编辑工作台可保留专门交互，不能将普通评论/列表列为例外。
