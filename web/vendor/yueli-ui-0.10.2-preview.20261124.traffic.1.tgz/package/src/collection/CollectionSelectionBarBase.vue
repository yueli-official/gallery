<script setup lang="ts">
import type { ButtonProps } from "@nuxt/ui";
import type { CollectionPanelMessages } from "./panel";

withDefaults(
  defineProps<{
    count: number;
    size?: ButtonProps["size"];
    mode?: "keys" | "query";
    messages: CollectionPanelMessages;
    canSelectAllResults?: boolean;
  }>(),
  {
    mode: "keys",
    canSelectAllResults: false,
  },
);

const emit = defineEmits<{
  selectAllResults: [];
  clearSelection: [];
}>();
</script>

<template>
  <UTheme :props="{ button: { size } }">
    <div
      data-collection-selection
      role="region"
      :aria-label="messages.bulkRegion"
      class="flex w-full min-w-0 flex-col items-stretch gap-2 sm:flex-row sm:items-center sm:justify-between sm:gap-3"
    >
      <div class="flex min-w-0 items-center gap-1.5 text-sm">
        <span class="truncate font-medium text-toned">
          {{ messages.selected(count, mode) }}
        </span>
      </div>

      <div
        data-collection-selection-actions
        class="flex min-w-0 flex-wrap items-center justify-start gap-2 sm:shrink-0 sm:flex-nowrap sm:justify-end"
      >
        <UButton
          v-if="canSelectAllResults"
          :label="messages.selectAllResults"
          color="neutral"
          variant="ghost"
          @click="emit('selectAllResults')"
        />
        <slot />
        <UButton
          :label="messages.clearSelection"
          color="neutral"
          variant="ghost"
          @click="emit('clearSelection')"
        />
      </div>
    </div>
  </UTheme>
</template>
