# 未保存离开保护

`UnsavedChangesPrompt` 从 `@yueli/ui/settings/pattern` 导入，Nuxt自动注册YUnsavedChangesPrompt。dirty由消费者的真实保存基线比较得出，busy表示保存中，默认false；messages提供title/description/stay/leave。组件只确认是否允许离开，不保存或丢弃业务数据。

```ts
const prompt=ref<{requestLeave:()=>Promise<boolean>}|null>(null)
async function back() {
  if(await prompt.value?.requestLeave()) { workflow.discard(); showList() }
}
// 在路由页面setup中复用已有Adapter：
useSettingsLeaveGuard({
  isDirty:()=>dirty.value || saving.value,
  confirm:()=>prompt.value?.requestLeave() ?? false,
})
```

组件ref暴露requestLeave：干净时true，dirty时打开原生Modal；继续编辑、关闭、Escape或卸载返回false，明确放弃返回true。并发请求合并到同一确认结果；busy时返回false，不能在请求未完成时离开。确认期间dirty变false可放行；开始保存则关闭确认并拒绝本次离开。调用方只在true后执行切页/丢弃，不用它代替权限检查。

复用现有bindSettingsBeforeUnload，dirty或busy时保护浏览器刷新/关闭，SSR安全、卸载移除监听；系统离开提示的文字和是否显示由浏览器决定，需要用户已交互。应用内路由、同路由参数切换、标签切换和返回按钮须显式接入requestLeave，组件不会自动拦截所有Router事件。已有设置页的useSettingsLeaveGuard/bindSettingsBeforeUnload继续可用，不必另加重复守卫。

可复用useVueSettingsWorkflow比较/捕获基线：真实保存成功后capture，失败保留输入与dirty，离开获同意后discard。共享Prompt不拥有存储、请求或自动保存。异步数据初次加载后按消费者实际数据重新capture，避免初始空值误报。不要把保存按钮点击当作保存成功。
