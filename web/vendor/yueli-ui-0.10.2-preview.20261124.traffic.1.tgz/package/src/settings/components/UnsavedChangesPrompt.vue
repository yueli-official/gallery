<script setup lang="ts">
import {onMounted,onBeforeUnmount,ref,watch} from 'vue';
import UModal from '@nuxt/ui/components/Modal.vue';
import UButton from '@nuxt/ui/components/Button.vue';
import {bindSettingsBeforeUnload} from '../browser';
const props=withDefaults(defineProps<{
 dirty:boolean;
 busy?:boolean;
 messages:{title:string;description:string;stay:string;leave:string};
}>(),{busy:false});
const open=ref(false);
let pending:Promise<boolean>|undefined, resolve:((value:boolean)=>void)|undefined;
let unbind=()=>{};
function settle(value:boolean){open.value=false;const done=resolve;resolve=undefined;pending=undefined;done?.(value);}
function requestLeave():Promise<boolean>{
 if(props.busy)return Promise.resolve(false);
 if(!props.dirty)return Promise.resolve(true);
 if(pending)return pending;
 open.value=true;pending=new Promise<boolean>(done=>{resolve=done;});return pending;
}
watch(()=>props.dirty,value=>{if(!value&&!props.busy)settle(true);});
watch(()=>props.busy,value=>{if(value)settle(false);});
onMounted(()=>{unbind=bindSettingsBeforeUnload({isDirty:()=>props.dirty||props.busy});});
onBeforeUnmount(()=>{unbind();settle(false);});
defineExpose({requestLeave});
</script>
<template>
 <UModal :open="open" :title="messages.title" :description="messages.description" @update:open="value=>{if(!value)settle(false)}">
  <template #body><div class="flex flex-wrap justify-end gap-2"><UButton :label="messages.stay" color="neutral" variant="soft" autofocus @click="settle(false)"/><UButton :label="messages.leave" color="warning" @click="settle(true)"/></div></template>
 </UModal>
</template>
