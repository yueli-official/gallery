<script setup lang="ts">
import { computed, ref } from "vue";
import type {
  AccountMenuAction,
  AccountMenuAppearance,
} from "../components/AccountMenu.vue";
import InlineStatus from "../../feedback/components/InlineStatus.vue";
export interface AccountMobilePanelMessages {
  currentUser: string;
  currentSite: string;
  role: string;
  siteFeatures: string;
  generalFeatures: string;
  logout: string;
  actionFailed: string;
}
export interface AccountMobileSite {
  label: string;
  role?: string;
  switchAction?: AccountMenuAction;
}
const props = withDefaults(
  defineProps<{
    name?: string;
    email?: string;
    avatarUrl?: string;
    site?: AccountMobileSite;
    contextActions?: readonly AccountMenuAction[];
    utilityActions?: readonly AccountMenuAction[];
    appearance?: AccountMenuAppearance;
    logout: () => unknown | Promise<unknown>;
    messages: AccountMobilePanelMessages;
  }>(),
  {
    name: "",
    email: "",
    avatarUrl: "",
    contextActions: () => [],
    utilityActions: () => [],
  },
);
const displayName = computed(
  () => props.name || props.email || props.messages.currentUser,
);
const busy = ref(false);
const failed = ref(false);
async function perform(callback: () => unknown | Promise<unknown>) {
  if (busy.value) return;
  busy.value = true;
  failed.value = false;
  try {
    await callback();
  } catch {
    failed.value = true;
  } finally {
    busy.value = false;
  }
}
async function select(action: AccountMenuAction, event: Event) {
  if (action.disabled || busy.value) {
    event.preventDefault();
    return;
  }
  if (action.onSelect) {
    event.preventDefault();
    await perform(() => action.onSelect?.(event));
  }
}
function changeAppearance(value: unknown) {
  if (value === "system" || value === "light" || value === "dark")
    void perform(() => props.appearance?.onChange(value));
}
const appearanceOptions = computed(() =>
  props.appearance
    ? [
        { label: props.appearance.messages.system, value: "system" },
        { label: props.appearance.messages.light, value: "light" },
        { label: props.appearance.messages.dark, value: "dark" },
      ]
    : [],
);
</script>
<template>
  <div class="account-mobile-panel">
    <section class="account-mobile-card" :aria-label="messages.currentUser">
      <div class="account-mobile-person">
        <UAvatar
          :src="avatarUrl || undefined"
          :text="displayName.charAt(0)"
          :alt="displayName"
          size="3xl"
        />
        <div class="min-w-0">
          <h1>{{ displayName }}</h1>
          <p v-if="email" class="account-mobile-email">{{ email }}</p>
        </div>
      </div>
      <div v-if="site" class="account-mobile-site">
        <span class="account-mobile-icon"
          ><UIcon name="i-tabler-server"
        /></span>
        <div class="min-w-0 flex-1">
          <p>
            {{ messages.currentSite }}<strong>{{ site.label }}</strong>
          </p>
          <p v-if="site.role" class="text-muted">
            {{ messages.role }}{{ site.role }}
          </p>
        </div>
        <UButton
          v-if="site.switchAction"
          :to="site.switchAction.to"
          :icon="site.switchAction.icon"
          color="primary"
          variant="soft"
          size="sm"
          :disabled="busy || site.switchAction.disabled"
          @click="select(site.switchAction, $event)"
          >{{ site.switchAction.label }}</UButton
        >
      </div>
    </section>
    <section
      v-if="contextActions.length"
      class="account-mobile-card"
      :aria-label="messages.siteFeatures"
    >
      <h2>{{ messages.siteFeatures }}</h2>
      <div class="account-mobile-rows">
        <UButton
          v-for="action in contextActions"
          :key="action.label"
          :to="action.to"
          color="neutral"
          variant="link"
          class="account-mobile-row"
          :disabled="busy || action.disabled"
          @click="select(action, $event)"
          ><span class="account-mobile-icon"
            ><UIcon :name="action.icon || 'i-tabler-apps'" /></span
          ><span class="account-mobile-copy"
            ><strong>{{ action.label }}</strong
            ><span v-if="action.description">{{
              action.description
            }}</span></span
          ><UIcon name="i-tabler-chevron-right" class="account-mobile-chevron"
        /></UButton>
      </div>
    </section>
    <section
      v-if="utilityActions.length || appearance"
      class="account-mobile-card"
      :aria-label="messages.generalFeatures"
    >
      <h2>{{ messages.generalFeatures }}</h2>
      <div class="account-mobile-rows">
        <UButton
          v-for="action in utilityActions"
          :key="action.label"
          :to="action.to"
          color="neutral"
          variant="link"
          class="account-mobile-row"
          :disabled="busy || action.disabled"
          @click="select(action, $event)"
          ><span class="account-mobile-icon"
            ><UIcon :name="action.icon || 'i-tabler-settings'" /></span
          ><span class="account-mobile-copy"
            ><strong>{{ action.label }}</strong
            ><span v-if="action.description">{{
              action.description
            }}</span></span
          ><UIcon name="i-tabler-chevron-right" class="account-mobile-chevron"
        /></UButton>
        <UCollapsible v-if="appearance"
          ><UButton color="neutral" variant="link" class="account-mobile-row"
            ><span class="account-mobile-icon"
              ><UIcon name="i-tabler-palette" /></span
            ><span class="account-mobile-copy"
              ><strong>{{ appearance.messages.label }}</strong
              ><span>{{
                appearanceOptions.find(
                  (option) => option.value === appearance?.value,
                )?.label
              }}</span></span
            ><UIcon
              name="i-tabler-chevron-down"
              class="account-mobile-chevron" /></UButton
          ><template #content
            ><URadioGroup
              :model-value="appearance.value"
              :items="appearanceOptions"
              :legend="appearance.messages.label"
              :disabled="busy"
              class="account-mobile-appearance"
              @update:model-value="changeAppearance" /></template
        ></UCollapsible>
      </div>
    </section>
    <InlineStatus v-if="failed" tone="error" :title="messages.actionFailed" />
    <UButton
      color="error"
      variant="link"
      class="account-mobile-logout"
      :loading="busy"
      :disabled="busy"
      @click="perform(logout)"
      ><span class="account-mobile-icon"><UIcon name="i-tabler-logout" /></span
      ><span>{{ messages.logout }}</span
      ><UIcon name="i-tabler-chevron-right" class="ml-auto size-4"
    /></UButton>
  </div>
</template>
<style scoped>
.account-mobile-panel {
  display: grid;
  gap: calc(var(--spacing) * 3);
  max-width: var(--container-2xl);
  margin-inline: auto;
}
.account-mobile-card {
  padding: calc(var(--spacing) * 4);
  border-radius: var(--radius-xl);
  background: var(--ui-bg);
  box-shadow: var(--shadow-sm);
}
.account-mobile-person {
  display: flex;
  align-items: center;
  gap: calc(var(--spacing) * 3.5);
}
.account-mobile-person h1 {
  color: var(--ui-text-highlighted);
  font-size: var(--text-xl);
  line-height: var(--text-xl--line-height);
  font-weight: var(--font-weight-semibold);
  overflow-wrap: anywhere;
}
.account-mobile-email {
  margin-top: calc(var(--spacing) * 0.75);
  color: var(--ui-text-muted);
  font-size: var(--text-sm);
  overflow-wrap: anywhere;
}
.account-mobile-site {
  display: flex;
  align-items: center;
  gap: calc(var(--spacing) * 3);
  margin-top: calc(var(--spacing) * 4);
  padding-top: calc(var(--spacing) * 3.5);
  border-top: 1px solid var(--ui-border);
  font-size: var(--text-xs);
  line-height: var(--text-xs--line-height);
}
.account-mobile-site strong {
  color: var(--ui-primary);
  font-weight: var(--font-weight-semibold);
}
.account-mobile-card h2 {
  margin-bottom: calc(var(--spacing) * 2);
  font-size: var(--text-sm);
  font-weight: var(--font-weight-semibold);
  color: var(--ui-text-highlighted);
}
.account-mobile-row {
  display: flex;
  width: 100%;
  gap: calc(var(--spacing) * 3);
  padding: calc(var(--spacing) * 3) 0;
  text-align: start;
  text-decoration: none;
  white-space: normal;
  border-radius: 0;
}
.account-mobile-rows > :not(:first-child) {
  border-top: 1px solid var(--ui-border);
}
.account-mobile-icon {
  display: grid;
  place-items: center;
  flex-shrink: 0;
  width: calc(var(--spacing) * 10);
  height: calc(var(--spacing) * 10);
  border-radius: var(--radius-lg);
  background: color-mix(in srgb, var(--ui-primary) 9%, var(--ui-bg));
  color: var(--ui-primary);
}
.account-mobile-icon :deep(.iconify) {
  width: calc(var(--spacing) * 5.75);
  height: calc(var(--spacing) * 5.75);
}
.account-mobile-copy {
  display: grid;
  min-width: 0;
  gap: calc(var(--spacing) * 0.75);
  flex: 1;
}
.account-mobile-copy strong {
  font-size: var(--text-sm);
  color: var(--ui-text-highlighted);
  font-weight: var(--font-weight-semibold);
}
.account-mobile-copy > span {
  font-size: var(--text-xs);
  font-weight: var(--font-weight-normal);
  color: var(--ui-text-muted);
  line-height: var(--text-xs--line-height);
}
.account-mobile-chevron {
  width: calc(var(--spacing) * 4);
  height: calc(var(--spacing) * 4);
  color: var(--ui-text-muted);
  flex-shrink: 0;
}
.account-mobile-appearance {
  padding: calc(var(--spacing) * 1) 0 calc(var(--spacing) * 3.5)
    calc(var(--spacing) * 13);
}
.account-mobile-logout {
  display: flex;
  align-items: center;
  gap: calc(var(--spacing) * 3);
  width: 100%;
  padding: calc(var(--spacing) * 2.5) calc(var(--spacing) * 4);
  background: var(--ui-bg);
  border-radius: var(--radius-xl);
  font-size: var(--text-sm);
}
.account-mobile-logout .account-mobile-icon {
  color: var(--ui-error);
  background: color-mix(in srgb, var(--ui-error) 7%, var(--ui-bg));
}
</style>
