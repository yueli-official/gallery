<script setup lang="ts">
import AdminTabs, {
  type AdminTabItem,
} from "../../admin/components/AdminTabs.vue";

const active = defineModel<string>({ required: true });
defineProps<{
  items: readonly AdminTabItem[];
  navigationLabel: string;
}>();
</script>

<template>
  <section
    class="yueli-card min-w-0 overflow-hidden"
    data-manage-tabbed-surface
  >
    <div class="flex min-w-0 flex-wrap items-center border-b border-default">
      <AdminTabs
        v-model="active"
        :items="items"
        :navigation-label="navigationLabel"
        class="min-w-0 basis-64 grow sm:px-5"
      />
      <div v-if="$slots.actions" class="ml-auto flex min-w-0 max-w-full shrink-0 flex-wrap items-center gap-2 px-3 py-2 sm:px-5">
        <slot name="actions" />
      </div>
    </div>
    <slot />
  </section>
</template>
