# 远程多选

从 `@yueli/ui/remote-select` 导入 `RemoteMultiSelect`，或 Nuxt module 自动注册 `YRemoteMultiSelect`。

数组 v-model（string/number ID），load 使用既有 RemoteSelectLoader，接收 query 与 AbortSignal，返回 {items}。label、placeholder、messages 必填；messages 包含共享多选的 search/empty/clear/showLess/summary/showMore/remove/missing，加 loading/error/retry/minimumQuery。

```vue
<RemoteMultiSelect v-model="ids" :load="loadTags" label="标签" placeholder="选择标签" :messages="messages" :initial-items="savedTags" />
```

默认 debounceMs=250、minimumQueryLength=0、cache=true、visibleLimit=2。请求只在菜单打开且未禁用时执行；新查询立刻取消并使旧请求失效，不等待防抖结束。关闭、禁用和卸载取消请求；即使 loader 忽略 AbortSignal，旧响应也不能覆盖当前结果。搜索监听原生输入的 compositionstart/end，组合期间不发送查询，组合结束后防抖查询。

已选元数据跨搜索保留，且不混入当前结果；initialItems 用于恢复已保存名称，缺失名称由 missing 提供。未选元数据不永久累积。每个实例最多缓存 50 个查询，卸载释放；refresh() 清空缓存重新加载，loader 身份变化亦清空缓存。失败有重试，空结果与加载中独立反馈，不自动删除已选 ID。

size/ui/disabled 沿用原生组件。无需修改单值 RemoteSelect；本组件直接复用 CollectionMultiSelect 的摘要、折叠、移除、清空与焦点恢复。保持远程结果顺序，不做本地过滤。

消费者负责鉴权、HTTP 客户端、游标生成、搜索排序、业务错误文案和删除权限。未配置 pagination 时返回值为当前查询完整结果，不提供“全选远程全部结果”。筛选 URL 使用消费者 ID codec；不要把开放式 ID 强塞进 enum-set 白名单。加载反馈不等同业务筛选应用：应用按钮仍由消费者明确提交。

## 可选游标分页（interaction.16）

`pagination={loadMore,loadingMore}` 显式启用追加加载。load 首次收到 `{query,signal}`，追加收到 `{query,cursor,signal}`；返回 `{items,nextCursor?:string|null}`。游标是后端提供的不透明字符串，组件不计算页码，不更改HTTP合同。缺省/null表示结束，空白或重复游标拒绝并反馈loadError，保留已有结果和原游标供重试。单值 RemoteSelect 不消费分页合同。

追加结果按value去重，新元数据更新同ID，原顺序稳定。追加不修改选择值，不触发业务应用；失败显示在现有结果下方，可原地重试。追加加载防重入；搜索/组合态/关闭/禁用/卸载取消，忽略Signal的旧响应也不能追加到新搜索。最后一页结束时焦点返回搜索框。没有自动滚动加载，也不承诺“已加载”等于远程全部。

缓存仅保留每查询首批和下一游标（最多50查询）；重新打开从首批开始，跨页已选名称保留。refresh清除缓存。选择结果会累计到当前打开查询，消费者应控制页大小/总量；要大规模虚拟化或无限滚动应另明确合同。

CollectionMultiSelect 同步透传原生 content-bottom 插槽以放分页控制，已有用法不受影响。为AI查询提供“远程分页／加载更多／cursor pagination”别名。同版类型、指南与测试一同打包。
