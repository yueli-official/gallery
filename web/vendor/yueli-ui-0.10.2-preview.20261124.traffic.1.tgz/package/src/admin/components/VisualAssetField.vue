<script setup lang="ts">
import { computed, ref, useId, watch } from "vue";
import type { TabsProps } from "@nuxt/ui";
import AdminIconPicker from "./AdminIconPicker.vue";
import type { AdminIconGroup, AdminIconOption } from "../types";

const props = withDefaults(defineProps<{
  icon?: string;
  imageUrl?: string;
  title?: string;
  description?: string;
  name?: string;
  iconLabel?: string;
  imageLabel?: string;
  showIcon?: boolean;
  showImage?: boolean;
  required?: boolean;
  error?: string;
  disabled?: boolean;
  readonly?: boolean;
  busy?: boolean;
  progress?: number;
  imageAspectRatio?: number;
  imageSpec?: string;
  iconOptions?: readonly AdminIconOption[];
  iconGroups?: readonly AdminIconGroup[];
  size?: TabsProps["size"];
}>(), {
  icon: "", imageUrl: "", title: "视觉资产", description: "", name: undefined,
  iconLabel: "图标", imageLabel: "封面", showIcon: true, showImage: true,
  required: false, error: "", disabled: false, readonly: false, busy: false,
  progress: undefined, imageAspectRatio: 1, imageSpec: "",
  iconOptions: () => [], iconGroups: () => [], size: "sm",
});
const emit = defineEmits<{
  "update:icon": [value: string];
  "pick-image": [];
  "clear-image": [];
}>();
defineSlots<{
  "icon-filters"?(props: { groups: readonly AdminIconGroup[]; activeGroup: string; selectGroup: (value: string) => void }): unknown;
  "image-actions"?(): unknown;
}>();
const id = useId();
const tab = ref(props.showIcon ? "icon" : "image");
const tabs = computed(() => [
  ...(props.showIcon ? [{ label: props.iconLabel, icon: "i-tabler-shapes", value: "icon" }] : []),
  ...(props.showImage ? [{ label: props.imageLabel, icon: "i-tabler-photo", value: "image" }] : []),
]);
watch(tabs, items => {
  if (!items.some(item => item.value === tab.value)) tab.value = items[0]?.value || "";
});
const locked = computed(() => props.disabled || props.readonly || props.busy);
const selectedLabel = computed(() => props.iconOptions.find(item => item.value === props.icon)?.label || props.icon);
</script>

<template>
  <UFormField :name="name" :label="title" :description="description || undefined" :required="required" :error="error || undefined" class="w-full">
    <section class="@container overflow-hidden rounded-lg border bg-default" :class="error ? 'border-error' : 'border-default'" role="group" :aria-label="title" :aria-invalid="Boolean(error)" :aria-describedby="error ? `${id}-error` : undefined" data-visual-asset-field>
      <div v-if="tabs.length > 1" class="border-b border-default p-2">
        <UTabs v-model="tab" :items="tabs" :content="false" :size="size" :ui="{ list: 'w-full' }" :aria-label="`${title}编辑区域`" />
      </div>
      <div v-show="tab === 'icon' && showIcon" class="grid gap-3 p-3" data-visual-asset-icon>
        <div class="flex min-w-0 items-center gap-3 rounded-lg bg-elevated/50 p-3">
          <span class="grid size-12 shrink-0 place-items-center rounded-lg border border-default bg-default text-primary">
            <UIcon :name="icon || 'i-tabler-shapes'" class="size-7" />
          </span>
          <div class="min-w-0">
            <p class="text-xs text-muted">当前{{ iconLabel }}</p>
            <p class="truncate text-sm text-highlighted" :title="selectedLabel">{{ selectedLabel || '尚未选择' }}</p>
          </div>
        </div>
        <AdminIconPicker :model-value="icon" :options="iconOptions" :groups="iconGroups" :disabled="locked" hide-label @update:model-value="emit('update:icon', $event)">
          <template v-if="$slots['icon-filters']" #filters="scope"><slot name="icon-filters" v-bind="scope" /></template>
        </AdminIconPicker>
      </div>
      <div v-show="tab === 'image' && showImage" class="grid gap-3 p-3" data-visual-asset-image>
        <div class="relative mx-auto w-full max-w-sm overflow-hidden rounded-lg border border-default bg-elevated/50" :style="{ aspectRatio: imageAspectRatio }">
          <img v-if="imageUrl" :src="imageUrl" :alt="`${imageLabel}预览`" class="size-full object-contain">
          <div v-else class="grid size-full place-items-center p-4 text-center">
            <div class="grid justify-items-center gap-2 text-muted"><UIcon :name="icon || 'i-tabler-photo'" class="size-10 text-primary" /><span class="text-xs">尚未设置{{ imageLabel }}</span></div>
          </div>
          <div v-if="busy" class="absolute inset-0 grid place-items-center bg-default/80 p-4" role="status" aria-live="polite">
            <div class="w-full space-y-2"><UProgress :model-value="progress" /><p class="text-center text-xs text-muted">{{ progress === undefined ? '正在处理…' : `正在上传 ${progress}%` }}</p></div>
          </div>
        </div>
        <div v-if="!readonly" class="flex flex-wrap justify-center gap-2">
          <UButton icon="i-tabler-upload" :label="imageUrl ? `更换${imageLabel}` : `选择${imageLabel}`" :size="size" color="neutral" variant="outline" :disabled="locked" @click="emit('pick-image')" />
          <slot name="image-actions" />
          <UButton v-if="imageUrl" icon="i-tabler-x" :label="`移除${imageLabel}`" :size="size" color="neutral" variant="ghost" :disabled="locked" @click="emit('clear-image')" />
        </div>
        <p v-if="imageSpec" class="text-center text-xs text-muted">{{ imageSpec }}</p>
      </div>
    </section>
    <span v-if="error" :id="`${id}-error`" class="sr-only">{{ error }}</span>
  </UFormField>
</template>
