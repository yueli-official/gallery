<script setup lang="ts">
import type { ButtonProps } from "@nuxt/ui";
import { computed } from "vue";
import type { AdminRowActionItem } from "../types";

const props = withDefaults(
  defineProps<{
    items:
      | readonly AdminRowActionItem[]
      | readonly (readonly AdminRowActionItem[])[];
    label: string;
    size?: ButtonProps["size"];
    presentation?: "auto" | "inline" | "overflow";
    overflowIcon?: string;
  }>(),
  { presentation: "auto" },
);

function isGroup(
  value: AdminRowActionItem | readonly AdminRowActionItem[],
): value is readonly AdminRowActionItem[] {
  return Array.isArray(value);
}

const groups = computed<readonly (readonly AdminRowActionItem[])[]>(() => {
  const source = props.items ?? [];
  if (!source.length) return [];
  const normalized = isGroup(
    source[0] as AdminRowActionItem | readonly AdminRowActionItem[],
  )
    ? (source as readonly (readonly AdminRowActionItem[])[])
    : [source as readonly AdminRowActionItem[]];
  return normalized
    .map((group) => group.filter((item) => !item.hidden))
    .filter((group) => group.length > 0);
});

const inlineItems = computed(() => groups.value.flat());
const menuItems = computed(() =>
  groups.value.map((group) =>
    group.map((item) => ({
      label: item.label,
      icon: item.icon,
      to: item.to,
      target: item.target,
      rel: item.rel,
      disabled: item.disabled || item.loading,
      color: item.tone === "danger" ? ("error" as const) : undefined,
      onSelect: item.onSelect,
    })),
  ),
);

function activate(item: AdminRowActionItem, event: MouseEvent) {
  if (item.disabled || item.loading) {
    event.preventDefault();
    return;
  }
  item.onSelect?.();
}
</script>

<template>
  <div
    v-if="groups.length"
    class="admin-row-actions w-full min-w-0"
    role="group"
    :aria-label="label"
    data-admin-row-actions
    :data-presentation="presentation"
    :data-many-actions="inlineItems.length > 3 || undefined"
    :data-single-action="inlineItems.length === 1 || undefined"
  >
    <div
      data-row-actions-inline
      class="flex flex-wrap items-center justify-end gap-1"
    >
      <UTooltip v-for="item in inlineItems" :key="item.id" :text="item.label">
        <UButton
          :to="item.to"
          :target="item.target"
          :rel="item.rel"
          color="neutral"
          variant="ghost"
          :size="size"
          :icon="item.icon"
          square
          :disabled="item.disabled"
          :loading="item.loading"
          class="shrink-0"
          :class="
            item.tone === 'danger'
              ? 'text-muted hover:text-error focus-visible:text-error'
              : ''
          "
          :aria-label="item.label"
          data-admin-row-action
          @click="activate(item, $event)"
        />
      </UTooltip>
    </div>

    <div data-row-actions-menu class="flex justify-end">
      <UDropdownMenu :items="menuItems" :size="size" :external-icon="false">
        <UButton
          color="neutral"
          variant="ghost"
          :size="size"
          :icon="overflowIcon || 'i-tabler-dots-vertical'"
          square
          class="shrink-0"
          :aria-label="label"
          data-admin-row-action-overflow
        />
      </UDropdownMenu>
    </div>
  </div>
</template>

<style scoped>
.admin-row-actions {
  container: admin-row-actions / inline-size;
  contain-intrinsic-inline-size: 10rem;
}
[data-row-actions-menu] {
  display: none;
}
[data-presentation="overflow"] > [data-row-actions-inline],
[data-presentation="auto"][data-many-actions] > [data-row-actions-inline] {
  display: none;
}
[data-presentation="overflow"] > [data-row-actions-menu],
[data-presentation="auto"][data-many-actions] > [data-row-actions-menu] {
  display: flex;
}
@container admin-row-actions (max-width: 10rem) {
  [data-presentation="auto"]:not([data-single-action])
    > [data-row-actions-inline] {
    display: none;
  }
  [data-presentation="auto"]:not([data-single-action])
    > [data-row-actions-menu] {
    display: flex;
  }
}
</style>
