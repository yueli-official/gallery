# VisualAssetField

从 `@yueli/ui/admin` 导入 `VisualAssetField`。组件拥有图标/图片编辑 Tabs、预览、只读/禁用/处理状态与字段错误，消费者拥有数据和业务保存。图片操作通过事件或插槽接入；Foundation 不依赖 Asset。

`icon` + `update:icon` 控制图标；`imageUrl` 是展示地址，`pick-image` 和 `clear-image` 由消费者处理。切换 Tabs 不清空任何值。`showIcon/showImage` 决定可用能力，`iconLabel/imageLabel/title/description` 为消费者文案。

`iconGroups` 的元素为 `{ value, label, icons: string[] }`，不传则仅显示搜索和网格。可用 `icon-filters` 插槽定制分类栏，通过提供的 `activeGroup/selectGroup` 保留共享筛选行为。图标结果默认最多96个，完整目录按需异步加载，不在此组件加入业务分类规则。

`name/required/error` 接入 UFormField；`error` 为消费者提交/触碰策略决定的错误文字。组件统一红色边框、错误提示与ARIA关联。`required` 只表达字段语义，不自行判断某个业务对象的合法性。

`imageAspectRatio` 只控制预览比例，`imageSpec` 是消费者提供的规格文案。使用 Asset 的消费者应采用 `AssetVisualAssetField`，由它复用图片采集工作台执行真正的图片约束，而不是把预览比例当作校验。

`disabled/readonly/busy/progress` 统一交互状态，`image-actions` 可补充消费者图片动作。主题与尺寸沿用 Nuxt UI，`size` 使用原生 Tabs/Button 尺度。

## 安装与选型

Nuxt 应用启用 `modules: ['@yueli/ui']`，根组件由 `UApp` 提供上下文。组件样式由模块提供，不手动导入共享CSS。先在消费者目录运行 `yueli-ui inspect --project . --json`，再查询 `yueli-ui docs component:VisualAssetField --section api --project . --json`；API和默认值由当前制品生成，不用源码文档补作旧版合同。

只需要图标时直接使用本组件；需要图片采集、处理和规格校验时使用 `@yueli/asset-nuxt/components` 的 `AssetVisualAssetField`。两层的 `imageUrl` 都只用于展示，业务持久化使用Asset引用或mediaKey。

## 可直接使用的图标字段

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { VisualAssetField } from '@yueli/ui/admin'
import type { AdminIconGroup } from '@yueli/ui/admin'

const icon = ref('i-tabler-star')
const groups: AdminIconGroup[] = [
  { value: 'shapes', label: '形状', icons: ['i-tabler-star', 'i-tabler-circle', 'i-tabler-square'] },
]
</script>

<template>
  <VisualAssetField v-model:icon="icon" title="图标" :show-image="false" :icon-groups="groups" />
</template>
```

图标分类由消费者传入，`value`必须非空且唯一。不传`iconGroups`就不显示分类栏。搜索与当前分类取交集，切换视觉资产Tab不会清空查询、分类或选择。图标标识仍采用本地Tabler交付合同。

## 插槽

```vue
<VisualAssetField v-model:icon="icon" :icon-groups="groups" :show-image="false">
  <template #icon-filters="{ groups: choices, activeGroup, selectGroup }">
    <div class="flex flex-wrap gap-2" role="group" aria-label="图标分类">
      <UButton label="全部" :aria-pressed="activeGroup === ''" @click="selectGroup('')" />
      <UButton v-for="choice in choices" :key="choice.value" :label="choice.label"
        :aria-pressed="activeGroup === choice.value" @click="selectGroup(choice.value)" />
    </div>
  </template>
</VisualAssetField>
```

`icon-filters`替换分类栏的表现，继续调用共享的`selectGroup`执行筛选。消费者自定义按钮时负责传递自身disabled状态及可访问名称。`image-actions`在图片操作区补充动作，不改变共享的选择/移除行为。

## 表单与操作

| 配置/事件 | 使用方式 |
| --- | --- |
| `icon` / `update:icon` | 受控图标值，可用`v-model:icon`；选择只改变表单草稿 |
| `imageUrl` | 受控图片展示地址，不上传、不保存、不推导资源URL |
| `pick-image` / `clear-image` | 消费者打开采集器或清除当前对象的草稿引用；不自动删除Asset对象 |
| `showIcon` / `showImage` | 至少启用一项；仅启用一项时不显示顶层Tabs |
| `title/description/iconLabel/imageLabel` | 标题、必要提示和消费者名称；没有站点预设或产品分支 |
| `name/required/error` | 接入表单字段；父表单决定何时校验，传入可恢复的错误文字 |
| `disabled/readonly/busy/progress` | 禁用、只读、处理和可选百分比；只读隐藏图片写操作 |
| `imageAspectRatio/imageSpec` | 预览比例与提示文字；不执行真实图片约束 |
| `iconOptions/iconGroups` | 图标候选和可选分类；默认候选及结果上限由`AdminIconPicker`拥有 |
| `size` | Nuxt UI原生尺寸，不重新定义尺寸体系 |

字段必填示例：父表单提交时判断业务值，向`error`传入“请选择封面”；不要在新建空表单首次打开时立即标红。`required`只提供必填标识；它不代表图标可以满足图片必填条件。

键盘使用Nuxt UI Tabs的方向键及Enter/Space激活、原生图标按钮的焦点和选择语义。错误由`UFormField`及ARIA关联呈现；调用方不要重复追加成功Toast或第二条同义错误。初次加载的目录、空结果与目录加载失败沿用图标选择器的状态。

## 迁移与边界

这是新增入口，不替换既有`AdminIconPicker`。后者新增可选`groups/allLabel/hideLabel`与`filters`插槽；不传新配置时保留既有搜索和选择行为，默认结果上限仍为96。

Foundation不提供上传、持久化、业务权限、资源删除或服务端校验；这些留给Asset组合及产品Adapter。源码联调通过不代表正式制品已升级；采用新入口前须同步批准制品并完成真实消费者验证。
