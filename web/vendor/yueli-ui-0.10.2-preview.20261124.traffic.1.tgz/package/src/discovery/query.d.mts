import type { PublicUiManifestEntry } from "../manifest.js";

export interface QueryOptions {
  project?: string;
  target?: string;
  query?: string;
  id?: string;
  section?: "usage" | "api" | "readme" | "migration";
  kind?: "module" | "component";
  lifecycle?: "active" | "deprecated" | "removed" | "all";
  capability?: string;
  limit?: number | string;
  offset?: number | string;
}
export interface PackageIdentity {
  name: "@yueli/ui";
  version: string;
  peerDependencies?: Readonly<Record<string, string>>;
  exports?: Readonly<Record<string, string | Readonly<Record<string, string>>>>;
}
export interface Inspection {
  project: string;
  declared: string | null;
  locked: {
    status: "known" | "unknown";
    path?: string;
    importer?: string;
    specifier?: string;
    resolution?: string;
    version?: string;
    reason?: string;
    artifact?: { path: string; sha256: string };
    integrity?: "verified" | "conflict";
  };
  resolved: null | {
    name: "@yueli/ui";
    version: string;
    packageRoot: string;
    logicalRoot: string;
    linked: boolean;
    verification: "source" | "artifact" | "installed";
    artifactContent: "verified" | "conflict" | "unverified";
    source: null | { commit: string | null; dirty: boolean | null };
  };
  sourceOverrides: readonly {
    kind: "source-link" | "source-checkout";
    path: string;
  }[];
  runtimeResolution: "unknown" | "node-package" | "unverified";
  configEvidence?: readonly string[];
  warnings: readonly string[];
}
export interface Capability {
  id: string;
  supported: boolean;
  contract?: string;
  reason?: string;
  introducedIn?: string;
}
export interface Lifecycle {
  state: "active" | "deprecated" | "removed";
  recommendation: "use" | "migrate" | "do-not-import";
  reason: string | null;
  deprecatedIn: string | null;
  removedIn: string | null;
  replacement: { entrypoint: string; symbol?: string } | null;
  migration: string | null;
  plannedRemovalVersion: string | null;
  removalOverdue: boolean;
}
export interface CatalogComponent {
  id: string;
  name: string;
  source: string | null;
  entrypoint: string;
  available: boolean;
  lifecycle: Lifecycle;
  exports: readonly { entrypoint: string; symbol: string }[];
  aliases: readonly string[];
  responsibility?: string;
  api: readonly { kind: string; declaration: string; source: string }[];
  sections: Readonly<Record<string, { content: string; source: string }>>;
}
export interface CatalogEntry extends Omit<
  PublicUiManifestEntry,
  "discovery" | "lifecycle" | "symbols"
> {
  lifecycle: Lifecycle;
  symbols: readonly Pick<
    CatalogComponent,
    "id" | "name" | "source" | "entrypoint" | "lifecycle"
  >[];
  aliases: readonly string[];
  capabilities: readonly Capability[];
  api: readonly { kind: string; declaration: string; source: string }[];
  sections: Readonly<Record<string, { content: string; source: string }>>;
}
export interface PublicCatalog {
  schemaVersion: 1;
  package: PackageIdentity;
  contentSha256: string;
  entries: readonly CatalogEntry[];
  components?: readonly CatalogComponent[];
  sourceHashes: Readonly<Record<string, string>>;
}
export interface Binding {
  package: PackageIdentity;
  contentSha256?: string;
  verification: "source" | "artifact" | "installed";
  warnings: readonly string[];
  catalogAvailable?: false;
}
export interface SearchResult extends Binding {
  total: number;
  offset: number;
  nextOffset: number | null;
  results: readonly {
    id: string;
    entrypoint: string;
    kind: "module" | "component";
    lifecycle: Lifecycle;
    available: boolean;
    name?: string;
    source?: string | null;
    exports?: CatalogComponent["exports"];
    symbols?: CatalogEntry["symbols"];
    status: string;
    purpose: string;
    matchReason: readonly string[];
    capabilities: readonly Capability[];
  }[];
}
export interface DocsResult extends Binding {
  id: string;
  entrypoint: string;
  lifecycle: Lifecycle;
  available: boolean;
  section: string;
  source: string;
  totalCharacters: number;
  content: string;
  offset: number;
  nextOffset: number | null;
}
export interface UpgradePlan {
  dryRun: true;
  applied: false;
  decision:
    | "review-required"
    | "no-change"
    | "integrity-conflict"
    | "downgrade-review"
    | "baseline-required"
    | "manual-baseline-required";
  current: Binding;
  target: PackageIdentity & {
    packageRoot: string;
    contentSha256: string;
    verification: "candidate-directory" | "local-tarball";
    artifactSha256: string | null;
  };
  versionChange: string | null;
  channelChange: boolean;
  comparisonsAvailable: boolean;
  changes: readonly {
    id: string;
    kind:
      | "added"
      | "removed"
      | "entrypoint-changed"
      | "api-changed"
      | "capabilities-changed"
      | "lifecycle-changed"
      | "component-lifecycle-changed";
    lifecycle?: Lifecycle;
    breaking?: boolean | "review";
    from?: string;
    to?: string;
    migration?: string | null;
    capabilities?: readonly Capability[];
  }[];
  dependencyChecks: readonly {
    dependency: string;
    required: string;
    declared: string | null;
    kind: "module" | "component";
    lifecycle: Lifecycle;
    available: boolean;
    name?: string;
    source?: string | null;
    exports?: CatalogComponent["exports"];
    symbols?: CatalogEntry["symbols"];
    status: string;
  }[];
  proposedActions: readonly string[];
  checks: readonly string[];
}
export class DiscoveryError extends Error {
  code: string;
  constructor(code: string, message: string);
}
export function inspect(options?: QueryOptions): Promise<Inspection>;
export function search(options?: QueryOptions): Promise<SearchResult>;
export function docs(options?: QueryOptions): Promise<DocsResult>;
export function upgradePlan(options?: QueryOptions): Promise<UpgradePlan>;
export function loadCatalog(root: string): Promise<PublicCatalog>;
export function query(
  command: "inspect",
  options?: QueryOptions,
): Promise<Inspection>;
export function query(
  command: "search",
  options?: QueryOptions,
): Promise<SearchResult>;
export function query(
  command: "docs",
  options?: QueryOptions,
): Promise<DocsResult>;
export function query(
  command: "upgrade-plan",
  options?: QueryOptions,
): Promise<UpgradePlan>;
