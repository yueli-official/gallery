import { createInterface } from "node:readline";
import { readFileSync } from "node:fs";
import { query } from "./query.mjs";
const packageVersion = JSON.parse(
  readFileSync(new URL("../../package.json", import.meta.url), "utf8"),
).version;

const string = { type: "string" };
const page = {
  limit: { type: "integer", minimum: 0, maximum: 12000 },
  offset: { type: "integer", minimum: 0, maximum: 10000000 },
};
export const tools = [
  {
    name: "inspect",
    description:
      "Read actual package, lock and source override identity. Runtime aliases may remain unknown.",
    fields: { project: string },
    required: ["project"],
  },
  {
    name: "search",
    description:
      "Find public modules in the actual package catalog; unsupported capabilities stay explicit.",
    fields: {
      project: string,
      query: string,
      capability: string,
      kind: { type: "string", enum: ["module", "component"] },
      lifecycle: {
        type: "string",
        enum: ["active", "deprecated", "removed", "all"],
      },
      ...page,
      limit: { type: "integer", minimum: 0, maximum: 20 },
    },
    required: ["project", "query"],
  },
  {
    name: "docs",
    description:
      "Read a bounded section from the actual package edition; never fall back to latest docs.",
    fields: {
      project: string,
      id: string,
      section: {
        type: "string",
        enum: ["usage", "api", "readme", "migration"],
      },
      ...page,
    },
    required: ["project", "id"],
  },
  {
    name: "upgrade-plan",
    description:
      "Produce a read-only candidate upgrade plan for an explicit target package directory.",
    fields: { project: string, target: string },
    required: ["project", "target"],
  },
].map(({ fields, required, ...tool }) => ({
  ...tool,
  inputSchema: {
    type: "object",
    properties: fields,
    required,
    additionalProperties: false,
  },
  annotations: {
    readOnlyHint: true,
    destructiveHint: false,
    idempotentHint: true,
    openWorldHint: false,
  },
}));

const protocolError = (code, message) => ({ error: { code, message } });
export function createHandler() {
  let initialized = false;
  return async (request) => {
    if (
      !request ||
      request.jsonrpc !== "2.0" ||
      typeof request.method !== "string"
    )
      return protocolError(-32600, "Invalid JSON-RPC request.");
    if (request.method === "initialize") {
      initialized = false;
      const requested = request.params?.protocolVersion;
      const protocolVersion = ["2025-11-25", "2025-06-18"].includes(requested)
        ? requested
        : "2025-11-25";
      return {
        result: {
          protocolVersion,
          capabilities: { tools: {} },
          serverInfo: { name: "yueli-ui-discovery", version: packageVersion },
        },
      };
    }
    if (request.method === "notifications/initialized") {
      initialized = true;
      return null;
    }
    if (!Object.hasOwn(request, "id")) return null;
    if (request.method === "ping") return { result: {} };
    if (!initialized)
      return protocolError(-32000, "Initialize the MCP session first.");
    if (request.method === "tools/list") return { result: { tools } };
    if (request.method !== "tools/call")
      return protocolError(-32601, "Method not found.");
    const tool = tools.find((t) => t.name === request.params?.name);
    if (!tool) return protocolError(-32602, "Unknown tool.");
    const args = request.params.arguments ?? {};
    if (!args || typeof args !== "object" || Array.isArray(args))
      return protocolError(-32602, "Expected tool argument object.");
    if (tool.inputSchema.required.some((key) => !Object.hasOwn(args, key)))
      return protocolError(-32602, "Missing required tool argument.");
    for (const [key, value] of Object.entries(args)) {
      if (!Object.hasOwn(tool.inputSchema.properties, key))
        return protocolError(-32602, `Unknown tool argument: ${key}`);
      const field = tool.inputSchema.properties[key];
      if (
        !field ||
        (field.type === "string"
          ? typeof value !== "string" || value.length > 4096
          : !Number.isInteger(value) ||
            value < field.minimum ||
            value > field.maximum) ||
        (field.enum && !field.enum.includes(value))
      )
        return protocolError(-32602, `Invalid tool argument: ${key}`);
    }
    try {
      const result = await query(tool.name, args);
      return {
        result: {
          content: [{ type: "text", text: JSON.stringify(result) }],
          structuredContent: result,
          isError: false,
        },
      };
    } catch (error) {
      const result = {
        error: { code: error.code ?? "query_failed", message: error.message },
      };
      return {
        result: {
          content: [{ type: "text", text: JSON.stringify(result) }],
          structuredContent: result,
          isError: true,
        },
      };
    }
  };
}

export async function serve(input = process.stdin, output = process.stdout) {
  const handle = createHandler();
  const lines = createInterface({ input, crlfDelay: Infinity });
  for await (const line of lines) {
    if (!line.trim()) continue;
    let request, response;
    try {
      if (line.length > 16384) throw new Error("Request exceeds size limit.");
      request = JSON.parse(line);
      response = await handle(request);
    } catch {
      response = protocolError(-32700, "Invalid JSON request.");
    }
    if (
      response &&
      (!request || Object.hasOwn(request, "id") || response.error)
    )
      output.write(
        `${JSON.stringify({ jsonrpc: "2.0", id: request?.id ?? null, ...response })}\n`,
      );
  }
}
