<script setup lang="ts">
import { computed } from "vue";
import CollectionHeaderTools from "../../../collection/components/CollectionHeaderTools.vue";
import type { CollectionControl, CollectionControlValue } from "../../../collection/panel";
import type {
  CommentModerationCollectionActions,
  CommentModerationCollectionModel,
  CommentModerationLifecycle,
} from "../types";

const props = defineProps<{
  model: CommentModerationCollectionModel;
  actions: CommentModerationCollectionActions;
}>();
const search = computed({
  get: () => props.model.search,
  set: (value) => props.actions.updateSearch(value),
});
const statuses: { label: string; value: CommentModerationLifecycle }[] = [
  { label: "全部评论", value: "all" },
  { label: "待审核", value: "pending" },
  { label: "已通过", value: "approved" },
  { label: "垃圾评论", value: "spam" },
  { label: "回收站", value: "trash" },
];
const controls = computed<CollectionControl[]>(() => [{
  kind: "select", id: "lifecycle", label: "评论状态", value: props.model.lifecycle, options: statuses,
}]);
function applyFilters(values: Record<string, CollectionControlValue>) {
  const value = statuses.find(item => item.value === values.lifecycle)?.value;
  if (value && value !== props.model.lifecycle) props.actions.lifecycleChange(value);
}
function applySort(_by: string, order: "asc" | "desc") {
  if (order !== props.model.sortOrder) props.actions.sort();
}
</script>

<template>
  <CollectionHeaderTools
    v-model:search="search"
    label="评论搜索与筛选"
    :search-placeholder="model.searchPlaceholder"
    :controls="controls"
    :filter-count="model.lifecycle === 'all' ? 0 : 1"
    sort-by="created"
    :sort-order="model.sortOrder"
    :sort-options="[{ label: '评论时间', value: 'created' }]"
    @search="actions.search"
    @filters="applyFilters"
    @sort="applySort"
  />
</template>
