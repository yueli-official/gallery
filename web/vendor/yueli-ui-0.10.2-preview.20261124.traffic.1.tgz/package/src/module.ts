import {
  addComponent,
  addComponentsDir,
  addImports,
  createResolver,
  defineNuxtModule,
} from "@nuxt/kit";
import { createTablerIconDelivery } from "./icon-delivery";
import { installComponentStyles } from "./styles";

export interface YueliUiModuleOptions {
  /** Prefix for auto-imported public components. */
  prefix?: string;
  /**
   * Finite Tabler icon names supplied by persisted data or APIs. Literal icon
   * names in source files are discovered automatically.
   */
  tablerIcons?: string[];
}

const yueliUiModule = defineNuxtModule<YueliUiModuleOptions>({
  meta: {
    name: "@yueli/ui",
    configKey: "yueliUi",
  },
  defaults: {
    prefix: "Y",
    tablerIcons: [],
  },
  moduleDependencies(nuxt): {
    "@nuxt/ui": Record<string, never>;
    "@nuxt/icon": {
      defaults: ReturnType<typeof createTablerIconDelivery>;
    };
  } {
    const configured: string[] | undefined = (
      nuxt.options as unknown as { yueliUi?: YueliUiModuleOptions }
    ).yueliUi?.tablerIcons;

    return {
      "@nuxt/ui": {},
      "@nuxt/icon": {
        defaults: createTablerIconDelivery(configured),
      },
    };
  },
  setup(options, nuxt) {
    installComponentStyles(nuxt);
    const resolver = createResolver(import.meta.url);
    if (nuxt.options.dev) {
      // Workspace source overlays can live outside the consumer's Vite root.
      // Permit this package only, retaining the consumer's existing boundary.
      const packageRoot = resolver.resolve("..");
      nuxt.hook("vite:extendConfig", (config) => {
        if (!config.server) return;
        config.server.fs ??= {};
        const allow = config.server.fs.allow ?? [nuxt.options.workspaceDir];
        config.server.fs.allow = [...new Set([...allow, packageRoot])];
      });
    }
    const packageManifest = resolver.resolve("../package.json");
    if (!nuxt.options.watch.includes(packageManifest)) {
      // Vite caches package export maps. Local-source consumers must restart
      // their Nuxt resolver when Foundation adds a new public subpath.
      nuxt.options.watch.push(packageManifest);
    }

    addImports([
      {
        name: "useActionFeedback",
        from: resolver.resolve("./feedback/index"),
      },
      {
        name: "useMinimumLoading",
        from: resolver.resolve("./feedback/index"),
      },
      {
        name: "useFeedbackConfirm",
        from: resolver.resolve("./feedback/index"),
      },
    ]);
    addComponent({
      name: `${options.prefix ?? "Y"}NumericRangeFilter`,
      filePath: resolver.resolve(
        "./admin-platform/components/NumericRangeFilter.vue",
      ),
    });

    addComponent({
      name: `${options.prefix ?? "Y"}CalendarDateRangeFilter`,
      filePath: resolver.resolve(
        "./admin-platform/components/CalendarDateRangeFilter.vue",
      ),
    });

    for (const directory of [
      "interaction",
      "account-menu",
      "admin",
      "collection",
      "comments",
      "dashboard",
      "feedback",
      "navigation",
      "remote-select",
      "sharing",
      "settings",
    ]) {
      addComponentsDir({
        path: resolver.resolve(`./${directory}/components`),
        pathPrefix: false,
        prefix: options.prefix,
      });
    }
  },
});

export default yueliUiModule;
