export declare function verifyConsumerStyles(
  project: string,
  options?: { cssEntries?: readonly string[] },
): Promise<void>;
