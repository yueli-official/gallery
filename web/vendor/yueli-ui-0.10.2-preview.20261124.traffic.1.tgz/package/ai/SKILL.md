---
name: yueli-ui-discovery
description: Discover version-matched Yueli UI components and upgrade guidance.
---

Read ../AGENTS.md for package instructions. Follow its inspect/search/docs workflow using the actual consumer package directory. Detailed tool reference: ../docs/ai-discovery.md.
